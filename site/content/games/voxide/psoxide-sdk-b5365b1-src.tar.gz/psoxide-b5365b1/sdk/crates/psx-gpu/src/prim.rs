//! Primitive packet types for DMA-based GPU submission.
//!
//! Each struct is `#[repr(C)]` with the tag word first -- that's the
//! shape the DMA linked-list walker expects. The field names match
//! the on-wire GP0 word order so a reader can cross-reference
//! PSX-SPX without redundant decoding.
//!
//! Builders (`new` constructors) zero the tag; [`crate::frame::OtFrame::add`]
//! fills it in during insertion with `(words_after_tag << 24) | next`.

use crate::material::{
    BlendMode, TextureMaterial, TexturedGouraudPacketMaterial, TexturedPacketMaterial,
};
use psx_hw::gpu::packet::{self, SEMI_TRANSPARENT};
use psx_hw::gpu::{gp0, pack_color, pack_texcoord, pack_vertex, pack_xy};

/// Flat-shaded triangle. 5 words (tag + 4 data).
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[repr(C, align(4))]
pub struct TriFlat {
    /// DMA / OT linkage word. Written by the OT at insert time.
    pub tag: u32,
    /// `0x20000000 | rgb24` header.
    pub color_cmd: u32,
    /// Vertex 0 packed via [`pack_vertex`].
    pub v0: u32,
    /// Vertex 1.
    pub v1: u32,
    /// Vertex 2.
    pub v2: u32,
}

impl TriFlat {
    /// Data-word count after the tag. Passed to `ot::add`.
    pub const WORDS: u8 = 4;

    /// Build a flat triangle ready for OT insertion.
    pub const fn new(verts: [(i16, i16); 3], r: u8, g: u8, b: u8) -> Self {
        Self {
            tag: 0,
            color_cmd: gp0::polygon_opcode(false, false, false, false, false) | pack_color(r, g, b),
            v0: pack_vertex(verts[0].0, verts[0].1),
            v1: pack_vertex(verts[1].0, verts[1].1),
            v2: pack_vertex(verts[2].0, verts[2].1),
        }
    }

    /// The same triangle drawn with the semi-transparency equation set by the
    /// last GP0(E1h) ([`crate::Gpu::set_draw_mode`]).
    pub const fn translucent(mut self) -> Self {
        self.color_cmd |= SEMI_TRANSPARENT;
        self
    }
}

/// Gouraud-shaded triangle. 7 words (tag + 6 data).
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[repr(C, align(4))]
pub struct TriGouraud {
    /// OT linkage.
    pub tag: u32,
    /// Vertex 0: `opcode | color0`.
    pub color0_cmd: u32,
    /// Vertex 0 position.
    pub v0: u32,
    /// Vertex 1 color.
    pub color1: u32,
    /// Vertex 1 position.
    pub v1: u32,
    /// Vertex 2 color.
    pub color2: u32,
    /// Vertex 2 position.
    pub v2: u32,
}

impl TriGouraud {
    /// Data-word count after the tag.
    pub const WORDS: u8 = 6;

    /// Build a Gouraud-shaded triangle.
    pub const fn new(verts: [(i16, i16); 3], colors: [(u8, u8, u8); 3]) -> Self {
        let (r0, g0, b0) = colors[0];
        let (r1, g1, b1) = colors[1];
        let (r2, g2, b2) = colors[2];
        Self {
            tag: 0,
            color0_cmd: gp0::polygon_opcode(true, false, false, false, false)
                | pack_color(r0, g0, b0),
            v0: pack_vertex(verts[0].0, verts[0].1),
            color1: pack_color(r1, g1, b1),
            v1: pack_vertex(verts[1].0, verts[1].1),
            color2: pack_color(r2, g2, b2),
            v2: pack_vertex(verts[2].0, verts[2].1),
        }
    }

    /// The same triangle drawn with the semi-transparency equation set by the
    /// last GP0(E1h) ([`crate::Gpu::set_draw_mode`]).
    pub const fn translucent(mut self) -> Self {
        self.color0_cmd |= SEMI_TRANSPARENT;
        self
    }
}

/// Flat-shaded quad. 6 words (tag + 5 data).
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[repr(C, align(4))]
pub struct QuadFlat {
    /// OT linkage.
    pub tag: u32,
    /// `opcode | color`.
    pub color_cmd: u32,
    /// Vertex 0.
    pub v0: u32,
    /// Vertex 1.
    pub v1: u32,
    /// Vertex 2.
    pub v2: u32,
    /// Vertex 3.
    pub v3: u32,
}

impl QuadFlat {
    /// Data-word count.
    pub const WORDS: u8 = 5;

    /// Build a flat quad.
    pub const fn new(verts: [(i16, i16); 4], r: u8, g: u8, b: u8) -> Self {
        Self {
            tag: 0,
            color_cmd: gp0::polygon_opcode(false, true, false, false, false) | pack_color(r, g, b),
            v0: pack_vertex(verts[0].0, verts[0].1),
            v1: pack_vertex(verts[1].0, verts[1].1),
            v2: pack_vertex(verts[2].0, verts[2].1),
            v3: pack_vertex(verts[3].0, verts[3].1),
        }
    }

    /// The same quad drawn with the semi-transparency equation set by the
    /// last GP0(E1h) ([`crate::Gpu::set_draw_mode`]).
    pub const fn translucent(mut self) -> Self {
        self.color_cmd |= SEMI_TRANSPARENT;
        self
    }

    /// An axis-aligned rectangle: `size` pixels from `origin`, in `color`.
    ///
    /// Unlike [`FillRect`] it goes through the rasteriser, so it clips to
    /// the draw area and follows the draw offset: the right shape for UI
    /// panels and HUD backgrounds.
    pub const fn rect(origin: (i16, i16), size: (u16, u16), color: (u8, u8, u8)) -> Self {
        let (x0, y0) = origin;
        let x1 = x0.wrapping_add(size.0 as i16);
        let y1 = y0.wrapping_add(size.1 as i16);
        Self::new(
            [(x0, y0), (x1, y0), (x0, y1), (x1, y1)],
            color.0,
            color.1,
            color.2,
        )
    }
}

/// Untextured variable-size rectangle. 4 words (tag + 3 data).
/// Ignores draw-area clip on some GPU revisions; prefer `QuadFlat`
/// when you need clipping.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[repr(C, align(4))]
pub struct RectFlat {
    /// OT linkage.
    pub tag: u32,
    /// `0x60000000 | color` (monochrome rect opcode).
    pub color_cmd: u32,
    /// Top-left `xy`.
    pub xy: u32,
    /// Size `wh`.
    pub wh: u32,
}

impl RectFlat {
    /// Data-word count.
    pub const WORDS: u8 = 3;

    /// Build a rect.
    pub const fn new(x: i16, y: i16, w: u16, h: u16, r: u8, g: u8, b: u8) -> Self {
        Self {
            tag: 0,
            color_cmd: packet::FLAT_RECT | pack_color(r, g, b),
            xy: pack_vertex(x, y),
            wh: pack_xy(w, h),
        }
    }
}

/// VRAM fill (GP0 02h). 4 words (tag + 3 data).
///
/// Writes VRAM directly: it ignores the draw area, the draw offset and the
/// mask bits, and the GPU rounds the X range to 16-pixel steps (psx-spx,
/// GP0(02h)). Use it to clear a buffer; use [`QuadFlat::rect`] for a
/// panel that should clip and follow the draw offset.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[repr(C, align(4))]
pub struct FillRect {
    /// OT linkage.
    pub tag: u32,
    /// `0x02000000 | color`.
    pub color_command: u32,
    /// Top-left corner in VRAM.
    pub origin: u32,
    /// Width and height.
    pub size: u32,
}

impl FillRect {
    /// Data-word count.
    pub const WORDS: u8 = 3;

    /// Fill `size` pixels of VRAM at `origin` with `color`.
    pub const fn new(origin: (u16, u16), size: (u16, u16), color: (u8, u8, u8)) -> Self {
        Self {
            tag: 0,
            color_command: gp0::fill_rect(color.0, color.1, color.2),
            origin: pack_xy(origin.0, origin.1),
            size: pack_xy(size.0, size.1),
        }
    }
}

/// Gouraud-shaded quad. 9 words (tag + 8 data).
///
/// Same vertex order as [`QuadFlat`] (V0=TL, V1=TR, V2=BL, V3=BR
/// by convention, though the GPU actually draws (V0,V1,V2) then
/// (V1,V2,V3)). Each vertex carries its own RGB; the GPU
/// gouraud-interpolates across the primitive.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[repr(C, align(4))]
pub struct QuadGouraud {
    /// OT linkage.
    pub tag: u32,
    /// Vertex 0 colour + polygon opcode.
    pub color0_cmd: u32,
    /// Vertex 0 position.
    pub v0: u32,
    /// Vertex 1 colour.
    pub color1: u32,
    /// Vertex 1 position.
    pub v1: u32,
    /// Vertex 2 colour.
    pub color2: u32,
    /// Vertex 2 position.
    pub v2: u32,
    /// Vertex 3 colour.
    pub color3: u32,
    /// Vertex 3 position.
    pub v3: u32,
}

impl QuadGouraud {
    /// Data-word count after the tag.
    pub const WORDS: u8 = 8;

    /// Build a Gouraud quad. `colors[i]` corresponds to `verts[i]`.
    pub const fn new(verts: [(i16, i16); 4], colors: [(u8, u8, u8); 4]) -> Self {
        let (r0, g0, b0) = colors[0];
        let (r1, g1, b1) = colors[1];
        let (r2, g2, b2) = colors[2];
        let (r3, g3, b3) = colors[3];
        Self {
            tag: 0,
            color0_cmd: gp0::polygon_opcode(true, true, false, false, false)
                | pack_color(r0, g0, b0),
            v0: pack_vertex(verts[0].0, verts[0].1),
            color1: pack_color(r1, g1, b1),
            v1: pack_vertex(verts[1].0, verts[1].1),
            color2: pack_color(r2, g2, b2),
            v2: pack_vertex(verts[2].0, verts[2].1),
            color3: pack_color(r3, g3, b3),
            v3: pack_vertex(verts[3].0, verts[3].1),
        }
    }

    /// The same quad drawn with the semi-transparency equation set by the
    /// last GP0(E1h) ([`crate::Gpu::set_draw_mode`]).
    pub const fn translucent(mut self) -> Self {
        self.color0_cmd |= SEMI_TRANSPARENT;
        self
    }
}

/// Semi-transparent Gouraud quad with its GP0(E1) blend state embedded in
/// the same DMA packet.
///
/// Untextured translucent polygons do not carry blend bits of their own: they
/// read them from the current draw mode. Keeping the state word and polygon in
/// one OT packet makes the result independent of whichever textured surface
/// happened to draw immediately before it.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[repr(C, align(4))]
pub struct QuadGouraudBlended {
    /// OT linkage.
    pub tag: u32,
    /// GP0(E1) draw mode selecting the native semi-transparency equation.
    pub draw_mode: u32,
    /// Vertex 0 colour + semi-transparent Gouraud-quad opcode.
    pub color0_cmd: u32,
    /// Vertex 0 position.
    pub v0: u32,
    /// Vertex 1 colour.
    pub color1: u32,
    /// Vertex 1 position.
    pub v1: u32,
    /// Vertex 2 colour.
    pub color2: u32,
    /// Vertex 2 position.
    pub v2: u32,
    /// Vertex 3 colour.
    pub color3: u32,
    /// Vertex 3 position.
    pub v3: u32,
}

impl QuadGouraudBlended {
    /// Data-word count after the tag.
    pub const WORDS: u8 = 9;

    /// Build a native semi-transparent Gouraud ribbon segment.
    pub const fn new(
        verts: [(i16, i16); 4],
        colors: [(u8, u8, u8); 4],
        blend_mode: BlendMode,
    ) -> Self {
        let (r0, g0, b0) = colors[0];
        let (r1, g1, b1) = colors[1];
        let (r2, g2, b2) = colors[2];
        let (r3, g3, b3) = colors[3];
        Self {
            tag: 0,
            draw_mode: TextureMaterial::blended(0, 0, (0, 0, 0), blend_mode).draw_mode_word(),
            color0_cmd: gp0::polygon_opcode(true, true, false, true, false)
                | pack_color(r0, g0, b0),
            v0: pack_vertex(verts[0].0, verts[0].1),
            color1: pack_color(r1, g1, b1),
            v1: pack_vertex(verts[1].0, verts[1].1),
            color2: pack_color(r2, g2, b2),
            v2: pack_vertex(verts[2].0, verts[2].1),
            color3: pack_color(r3, g3, b3),
            v3: pack_vertex(verts[3].0, verts[3].1),
        }
    }
}

/// Monochrome single line. 4 words (tag + 3 data). GP0 0x40 -- the
/// real diagonal-capable line rasteriser (unlike `RectFlat`, which
/// the GPU snaps to 16-pixel X boundaries in its GP0 0x02 fill).
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[repr(C, align(4))]
pub struct LineMono {
    /// OT linkage.
    pub tag: u32,
    /// `0x40000000 | color` header.
    pub color_cmd: u32,
    /// First endpoint.
    pub v0: u32,
    /// Second endpoint.
    pub v1: u32,
}

impl LineMono {
    /// Data-word count.
    pub const WORDS: u8 = 3;

    /// Build a mono line.
    pub const fn new(x0: i16, y0: i16, x1: i16, y1: i16, r: u8, g: u8, b: u8) -> Self {
        Self {
            tag: 0,
            color_cmd: packet::FLAT_LINE | pack_color(r, g, b),
            v0: pack_vertex(x0, y0),
            v1: pack_vertex(x1, y1),
        }
    }

    /// The same line drawn with the semi-transparency equation set by the
    /// last GP0(E1h) ([`crate::Gpu::set_draw_mode`]).
    pub const fn translucent(mut self) -> Self {
        self.color_cmd |= SEMI_TRANSPARENT;
        self
    }
}

/// Gouraud-shaded single line (GP0 50h). 5 words (tag + 4 data).
///
/// The GPU interpolates the colour from one endpoint to the other.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[repr(C, align(4))]
pub struct LineGouraud {
    /// OT linkage.
    pub tag: u32,
    /// `0x50000000 | start color`.
    pub color0_command: u32,
    /// Start point.
    pub v0: u32,
    /// End color.
    pub color1: u32,
    /// End point.
    pub v1: u32,
}

impl LineGouraud {
    /// Data-word count.
    pub const WORDS: u8 = 4;

    /// A line from `from` to `to`, shaded from `from_color` to `to_color`.
    pub const fn new(
        from: (i16, i16),
        from_color: (u8, u8, u8),
        to: (i16, i16),
        to_color: (u8, u8, u8),
    ) -> Self {
        Self {
            tag: 0,
            color0_command: packet::SHADED_LINE
                | pack_color(from_color.0, from_color.1, from_color.2),
            v0: pack_vertex(from.0, from.1),
            color1: pack_color(to_color.0, to_color.1, to_color.2),
            v1: pack_vertex(to.0, to.1),
        }
    }

    /// The same line drawn with the semi-transparency equation set by the
    /// last GP0(E1h) ([`crate::Gpu::set_draw_mode`]).
    pub const fn translucent(mut self) -> Self {
        self.color0_command |= SEMI_TRANSPARENT;
        self
    }
}

/// Textured triangle with a single flat tint. 9 words (tag + 8 data).
///
/// The first data word is GP0(E2) texture-window state, followed by
/// vertex + UV pairs; CLUT rides in vertex 0's UV high word, tpage in
/// vertex 1's UV high word (PSX-SPX convention for GP0 0x24). Emitting
/// E2 per triangle keeps windowed world materials from leaking state to
/// model triangles when the ordering table interleaves both.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[repr(C, align(4))]
pub struct TriTextured {
    /// OT linkage.
    pub tag: u32,
    /// GP0(E2) texture-window command.
    pub tex_window: u32,
    /// `0x24000000 | tint` header.
    pub color_cmd: u32,
    /// Vertex 0 position.
    pub v0: u32,
    /// `(u0, v0, clut)` packed.
    pub uv0_clut: u32,
    /// Vertex 1 position.
    pub v1: u32,
    /// `(u1, v1, tpage)` packed.
    pub uv1_tpage: u32,
    /// Vertex 2 position.
    pub v2: u32,
    /// `(u2, v2, 0)` packed.
    pub uv2: u32,
}

impl TriTextured {
    /// Data-word count.
    pub const WORDS: u8 = 8;

    /// Build a textured triangle. `tint = (128, 128, 128)` leaves
    /// texels unmodulated.
    pub const fn new(
        verts: [(i16, i16); 3],
        uvs: [(u8, u8); 3],
        clut: u16,
        tpage: u16,
        tint: (u8, u8, u8),
    ) -> Self {
        Self::with_material(verts, uvs, TextureMaterial::opaque(clut, tpage, tint))
    }

    /// Build a textured triangle using a [`TextureMaterial`].
    pub const fn with_material(
        verts: [(i16, i16); 3],
        uvs: [(u8, u8); 3],
        material: TextureMaterial,
    ) -> Self {
        let (u0, v0) = uvs[0];
        let (u1, v1) = uvs[1];
        let (u2, v2) = uvs[2];
        let clut = material.clut_word();
        let tpage = material.texture_page_word();
        Self {
            tag: 0,
            tex_window: material.texture_window_word(),
            color_cmd: material.flat_textured_polygon_header(false),
            v0: pack_vertex(verts[0].0, verts[0].1),
            uv0_clut: pack_texcoord(u0, v0, clut),
            v1: pack_vertex(verts[1].0, verts[1].1),
            uv1_tpage: pack_texcoord(u1, v1, tpage),
            v2: pack_vertex(verts[2].0, verts[2].1),
            uv2: pack_texcoord(u2, v2, 0),
        }
    }

    /// The same packet as [`Self::with_material`], which it forwards to.
    #[deprecated(note = "identical to `with_material`")]
    #[inline(always)]
    pub const fn with_material_packet_texcoords(
        verts: [(i16, i16); 3],
        uvs: [(u8, u8); 3],
        material: TextureMaterial,
    ) -> Self {
        Self::with_material(verts, uvs, material)
    }

    /// Build a textured triangle from UV words that already contain
    /// the low `(u, v)` bytes in packet layout. The material still
    /// supplies CLUT, tpage, tint, blend, and texture-window state.
    pub const fn with_material_packed_uv_words(
        verts: [(i16, i16); 3],
        uv_words: [u16; 3],
        material: TextureMaterial,
    ) -> Self {
        let clut = material.clut_word();
        let tpage = material.texture_page_word();
        Self {
            tag: 0,
            tex_window: material.texture_window_word(),
            color_cmd: material.flat_textured_polygon_header(false),
            v0: pack_vertex(verts[0].0, verts[0].1),
            uv0_clut: (uv_words[0] as u32) | ((clut as u32) << 16),
            v1: pack_vertex(verts[1].0, verts[1].1),
            uv1_tpage: (uv_words[1] as u32) | ((tpage as u32) << 16),
            v2: pack_vertex(verts[2].0, verts[2].1),
            uv2: uv_words[2] as u32,
        }
    }

    /// Build a textured triangle from UV words and prepacked material words.
    pub const fn with_packet_material_packed_uv_words(
        verts: [(i16, i16); 3],
        uv_words: [u16; 3],
        material: TexturedPacketMaterial,
    ) -> Self {
        Self {
            tag: 0,
            tex_window: material.tex_window_word,
            color_cmd: material.color_command_word,
            v0: pack_vertex(verts[0].0, verts[0].1),
            uv0_clut: (uv_words[0] as u32) | material.clut_high_word,
            v1: pack_vertex(verts[1].0, verts[1].1),
            uv1_tpage: (uv_words[1] as u32) | material.tpage_high_word,
            v2: pack_vertex(verts[2].0, verts[2].1),
            uv2: uv_words[2] as u32,
        }
    }
}

/// Classic flat-tinted textured triangle without an inline GP0(E2)
/// texture-window command. Renderers that keep one texture-window state for
/// the whole pass can use this compact GP0(24h) packet. 8 words (tag + 7
/// data).
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[repr(C, align(4))]
pub struct ClassicTriTextured {
    /// Staged OT tag or final DMA linkage.
    pub tag: u32,
    /// GP0(24h) plus the flat tint.
    pub color_cmd: u32,
    /// Vertex-zero screen coordinate.
    pub v0: u32,
    /// Vertex-zero UV and CLUT.
    pub uv0_clut: u32,
    /// Vertex-one screen coordinate.
    pub v1: u32,
    /// Vertex-one UV and tpage.
    pub uv1_tpage: u32,
    /// Vertex-two screen coordinate.
    pub v2: u32,
    /// Vertex-two UV.
    pub uv2: u32,
}

impl ClassicTriTextured {
    /// Data-word count after the tag.
    pub const WORDS: u8 = 7;

    /// Build a compact packet whose tag temporarily carries `ot_slot` for a
    /// later tagged-stream OT linking pass.
    pub const fn with_staged_slot(
        verts: [(i16, i16); 3],
        uv_words: [u16; 3],
        tint: u32,
        clut: u16,
        tpage: u16,
        ot_slot: u16,
    ) -> Self {
        Self {
            tag: ((Self::WORDS as u32) << 24) | ot_slot as u32,
            color_cmd: packet::FLAT_TEXTURED_TRIANGLE | (tint & 0x00ff_ffff),
            v0: pack_vertex(verts[0].0, verts[0].1),
            uv0_clut: uv_words[0] as u32 | ((clut as u32) << 16),
            v1: pack_vertex(verts[1].0, verts[1].1),
            uv1_tpage: uv_words[1] as u32 | ((tpage as u32) << 16),
            v2: pack_vertex(verts[2].0, verts[2].1),
            uv2: uv_words[2] as u32,
        }
    }
}

/// Textured **Gouraud-shaded** triangle. 11 words (tag + 10 data).
///
/// Per-vertex tint: the GPU multiplies each texel by the
/// interpolated vertex colour, so GTE-lit-and-fogged per-vertex
/// colours drive the final shade smoothly across the triangle.
/// The first data word is GP0(E2) texture-window state, matching
/// [`TriTextured`] so windowed/tiled world materials do not leak
/// state across ordering-table interleaving. CLUT rides in v0's
/// UV high word, tpage in v1's UV high word (PSX-SPX convention
/// for GP0 0x34).
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[repr(C, align(4))]
pub struct TriTexturedGouraud {
    /// OT linkage.
    pub tag: u32,
    /// GP0(E2) texture-window command.
    pub tex_window: u32,
    /// `0x34000000 | color0` header -- v0's RGB is packed into the
    /// same word as the polygon opcode.
    pub color0_cmd: u32,
    /// Vertex 0 position.
    pub v0: u32,
    /// `(u0, v0, clut)` packed.
    pub uv0_clut: u32,
    /// Vertex 1 colour (RGB in low 24 bits; top byte ignored).
    pub color1: u32,
    /// Vertex 1 position.
    pub v1: u32,
    /// `(u1, v1, tpage)` packed.
    pub uv1_tpage: u32,
    /// Vertex 2 colour.
    pub color2: u32,
    /// Vertex 2 position.
    pub v2: u32,
    /// `(u2, v2, 0)` packed.
    pub uv2: u32,
}

impl TriTexturedGouraud {
    /// Data-word count.
    pub const WORDS: u8 = 10;

    /// Build a textured Gouraud triangle. Each vertex carries its
    /// own RGB (the NCDT-lit-and-fogged colour in the typical
    /// commercial-game path) which modulates the sampled texel.
    pub const fn new(
        verts: [(i16, i16); 3],
        uvs: [(u8, u8); 3],
        colors: [(u8, u8, u8); 3],
        clut: u16,
        tpage: u16,
    ) -> Self {
        Self::with_material(verts, uvs, colors, TextureMaterial::new(clut, tpage))
    }

    /// Build a textured Gouraud triangle using a [`TextureMaterial`].
    pub const fn with_material(
        verts: [(i16, i16); 3],
        uvs: [(u8, u8); 3],
        colors: [(u8, u8, u8); 3],
        material: TextureMaterial,
    ) -> Self {
        let (r0, g0, b0) = colors[0];
        let (r1, g1, b1) = colors[1];
        let (r2, g2, b2) = colors[2];
        let (u0, v0) = uvs[0];
        let (u1, v1) = uvs[1];
        let (u2, v2) = uvs[2];
        let clut = material.clut_word();
        let tpage = material.texture_page_word();
        Self {
            tag: 0,
            tex_window: material.texture_window_word(),
            color0_cmd: material.textured_polygon_command(true, false) | pack_color(r0, g0, b0),
            v0: pack_vertex(verts[0].0, verts[0].1),
            uv0_clut: pack_texcoord(u0, v0, clut),
            color1: pack_color(r1, g1, b1),
            v1: pack_vertex(verts[1].0, verts[1].1),
            uv1_tpage: pack_texcoord(u1, v1, tpage),
            color2: pack_color(r2, g2, b2),
            v2: pack_vertex(verts[2].0, verts[2].1),
            uv2: pack_texcoord(u2, v2, 0),
        }
    }

    /// The same packet as [`Self::with_material`], which it forwards to.
    #[deprecated(note = "identical to `with_material`")]
    #[inline(always)]
    pub const fn with_material_packet_texcoords(
        verts: [(i16, i16); 3],
        uvs: [(u8, u8); 3],
        colors: [(u8, u8, u8); 3],
        material: TextureMaterial,
    ) -> Self {
        Self::with_material(verts, uvs, colors, material)
    }

    /// Build a textured Gouraud triangle from UV words that already
    /// contain the low `(u, v)` packet bytes.
    pub const fn with_material_packed_uv_words(
        verts: [(i16, i16); 3],
        uv_words: [u16; 3],
        colors: [(u8, u8, u8); 3],
        material: TextureMaterial,
    ) -> Self {
        let (r0, g0, b0) = colors[0];
        let (r1, g1, b1) = colors[1];
        let (r2, g2, b2) = colors[2];
        let clut = material.clut_word();
        let tpage = material.texture_page_word();
        Self {
            tag: 0,
            tex_window: material.texture_window_word(),
            color0_cmd: material.textured_polygon_command(true, false) | pack_color(r0, g0, b0),
            v0: pack_vertex(verts[0].0, verts[0].1),
            uv0_clut: (uv_words[0] as u32) | ((clut as u32) << 16),
            color1: pack_color(r1, g1, b1),
            v1: pack_vertex(verts[1].0, verts[1].1),
            uv1_tpage: (uv_words[1] as u32) | ((tpage as u32) << 16),
            color2: pack_color(r2, g2, b2),
            v2: pack_vertex(verts[2].0, verts[2].1),
            uv2: uv_words[2] as u32,
        }
    }

    /// Build a textured Gouraud triangle from UV words and material
    /// packet words that were precomputed once for a hot material.
    pub const fn with_packet_material_packed_uv_words(
        verts: [(i16, i16); 3],
        uv_words: [u16; 3],
        colors: [(u8, u8, u8); 3],
        material: TexturedGouraudPacketMaterial,
    ) -> Self {
        let (r0, g0, b0) = colors[0];
        let (r1, g1, b1) = colors[1];
        let (r2, g2, b2) = colors[2];
        Self {
            tag: 0,
            tex_window: material.tex_window_word,
            color0_cmd: material.color0_command_word | pack_color(r0, g0, b0),
            v0: pack_vertex(verts[0].0, verts[0].1),
            uv0_clut: (uv_words[0] as u32) | material.clut_high_word,
            color1: pack_color(r1, g1, b1),
            v1: pack_vertex(verts[1].0, verts[1].1),
            uv1_tpage: (uv_words[1] as u32) | material.tpage_high_word,
            color2: pack_color(r2, g2, b2),
            v2: pack_vertex(verts[2].0, verts[2].1),
            uv2: uv_words[2] as u32,
        }
    }

    /// Build a self-contained texture-window packet whose tag temporarily
    /// carries `ot_slot` for a later tagged-stream OT linking pass.
    ///
    /// This is the windowed counterpart to
    /// [`ClassicTriTexturedGouraud::with_staged_slot_prepacked_colors`].
    /// It is intended for classic affine renderers whose tiled materials can
    /// interleave in the ordering table, so every polygon restores its own
    /// GP0(E2) state instead of relying on a global draw-mode side effect.
    ///
    /// Every color word must have its high byte clear, and `clut_high_word`
    /// and `tpage_high_word` must hold only their high halfwords; debug builds
    /// assert both. A word that breaks this changes what the GPU draws, not
    /// memory, so the constructor is safe.
    pub const fn with_staged_slot_prepacked_colors(
        verts: [(i16, i16); 3],
        uv_words: [u16; 3],
        colors: [u32; 3],
        clut_high_word: u32,
        tpage_high_word: u32,
        texture_window_word: u32,
        ot_slot: u16,
    ) -> Self {
        debug_assert!((colors[0] | colors[1] | colors[2]) >> 24 == 0);
        debug_assert!((clut_high_word | tpage_high_word) & 0xFFFF == 0);
        Self {
            tag: ((Self::WORDS as u32) << 24) | ot_slot as u32,
            tex_window: texture_window_word,
            color0_cmd: packet::SHADED_TEXTURED_TRIANGLE | colors[0],
            v0: pack_vertex(verts[0].0, verts[0].1),
            uv0_clut: uv_words[0] as u32 | clut_high_word,
            color1: colors[1],
            v1: pack_vertex(verts[1].0, verts[1].1),
            uv1_tpage: uv_words[1] as u32 | tpage_high_word,
            color2: colors[2],
            v2: pack_vertex(verts[2].0, verts[2].1),
            uv2: uv_words[2] as u32,
        }
    }

    /// Renamed to [`Self::with_staged_slot_prepacked_colors`], which is safe.
    ///
    /// # Safety
    ///
    /// Nothing beyond that function's preconditions; it stays `unsafe` so
    /// existing `unsafe` blocks keep compiling without a warning.
    #[deprecated(note = "renamed to `with_staged_slot_prepacked_colors`, which is safe")]
    #[inline(always)]
    pub const unsafe fn with_staged_slot_prepacked_unchecked(
        verts: [(i16, i16); 3],
        uv_words: [u16; 3],
        colors: [u32; 3],
        clut_high_word: u32,
        tpage_high_word: u32,
        texture_window_word: u32,
        ot_slot: u16,
    ) -> Self {
        Self::with_staged_slot_prepacked_colors(
            verts,
            uv_words,
            colors,
            clut_high_word,
            tpage_high_word,
            texture_window_word,
            ot_slot,
        )
    }

    /// Zeroed packet for static prebuilt-pool initialisation. Real
    /// content is written before the packet is ever linked into an
    /// ordering table.
    pub const EMPTY: Self = Self {
        tag: 0,
        tex_window: 0,
        color0_cmd: 0,
        v0: 0,
        uv0_clut: 0,
        color1: 0,
        v1: 0,
        uv1_tpage: 0,
        color2: 0,
        v2: 0,
        uv2: 0,
    };

    /// Rewrite the three vertex words of a prebuilt packet, leaving
    /// material, UV, and colour words untouched.
    #[inline(always)]
    pub fn set_positions(&mut self, verts: [(i16, i16); 3]) {
        self.v0 = pack_vertex(verts[0].0, verts[0].1);
        self.v1 = pack_vertex(verts[1].0, verts[1].1);
        self.v2 = pack_vertex(verts[2].0, verts[2].1);
    }

    /// Copy every packet word except the OT tag from a prebuilt
    /// skeleton. The destination can then patch positions and link
    /// into an ordering table without inheriting a stale DMA link.
    #[inline(always)]
    pub fn copy_payload_from(&mut self, source: &Self) {
        self.tex_window = source.tex_window;
        self.color0_cmd = source.color0_cmd;
        self.v0 = source.v0;
        self.uv0_clut = source.uv0_clut;
        self.color1 = source.color1;
        self.v1 = source.v1;
        self.uv1_tpage = source.uv1_tpage;
        self.color2 = source.color2;
        self.v2 = source.v2;
        self.uv2 = source.uv2;
    }

    /// Rewrite the three colour words of a prebuilt packet, preserving
    /// the opcode byte that shares v0's colour word.
    #[inline(always)]
    pub fn set_colors(&mut self, colors: [(u8, u8, u8); 3]) {
        let (r0, g0, b0) = colors[0];
        let (r1, g1, b1) = colors[1];
        let (r2, g2, b2) = colors[2];
        self.color0_cmd = (self.color0_cmd & 0xFF00_0000) | pack_color(r0, g0, b0);
        self.color1 = pack_color(r1, g1, b1);
        self.color2 = pack_color(r2, g2, b2);
    }
}

/// Classic textured Gouraud triangle without an inline GP0(E2) texture-window
/// command. This is the compact GP0(34h) packet used by renderers that keep a
/// single texture-window state for the whole pass. 10 words (tag + 9 data).
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[repr(C, align(4))]
pub struct ClassicTriTexturedGouraud {
    /// Staged OT tag or final DMA linkage.
    pub tag: u32,
    /// GP0(34h) plus vertex-zero RGB.
    pub color0_cmd: u32,
    /// Vertex-zero screen coordinate.
    pub v0: u32,
    /// Vertex-zero UV and CLUT.
    pub uv0_clut: u32,
    /// Vertex-one RGB.
    pub color1: u32,
    /// Vertex-one screen coordinate.
    pub v1: u32,
    /// Vertex-one UV and tpage.
    pub uv1_tpage: u32,
    /// Vertex-two RGB.
    pub color2: u32,
    /// Vertex-two screen coordinate.
    pub v2: u32,
    /// Vertex-two UV.
    pub uv2: u32,
}

impl ClassicTriTexturedGouraud {
    /// Data-word count after the tag.
    pub const WORDS: u8 = 9;

    /// Build a compact packet whose tag temporarily carries `ot_slot` for a
    /// later [`crate::ot::OrderingTable::insert_tagged_packet_stream_unchecked`]
    /// pass.
    pub const fn with_staged_slot(
        verts: [(i16, i16); 3],
        uv_words: [u16; 3],
        colors: [u32; 3],
        clut: u16,
        tpage: u16,
        ot_slot: u16,
    ) -> Self {
        Self::with_staged_slot_prepacked_material(
            verts,
            uv_words,
            colors,
            (clut as u32) << 16,
            (tpage as u32) << 16,
            ot_slot,
        )
    }

    /// Build a staged compact packet from CLUT and tpage words that have
    /// already been shifted into their GP0 high-halfword positions.
    pub const fn with_staged_slot_prepacked_material(
        verts: [(i16, i16); 3],
        uv_words: [u16; 3],
        colors: [u32; 3],
        clut_high_word: u32,
        tpage_high_word: u32,
        ot_slot: u16,
    ) -> Self {
        Self {
            tag: ((Self::WORDS as u32) << 24) | ot_slot as u32,
            color0_cmd: packet::SHADED_TEXTURED_TRIANGLE | (colors[0] & 0x00ff_ffff),
            v0: pack_vertex(verts[0].0, verts[0].1),
            uv0_clut: uv_words[0] as u32 | clut_high_word,
            color1: colors[1] & 0x00ff_ffff,
            v1: pack_vertex(verts[1].0, verts[1].1),
            uv1_tpage: uv_words[1] as u32 | tpage_high_word,
            color2: colors[2] & 0x00ff_ffff,
            v2: pack_vertex(verts[2].0, verts[2].1),
            uv2: uv_words[2] as u32,
        }
    }

    /// Build a staged packet without masking the supplied packet RGB words.
    ///
    /// Every color word must have its high byte clear, and `clut_high_word`
    /// and `tpage_high_word` must hold only their high halfwords; debug builds
    /// assert both. A word that breaks this changes what the GPU draws, not
    /// memory, so the constructor is safe.
    pub const fn with_staged_slot_prepacked_colors(
        verts: [(i16, i16); 3],
        uv_words: [u16; 3],
        colors: [u32; 3],
        clut_high_word: u32,
        tpage_high_word: u32,
        ot_slot: u16,
    ) -> Self {
        debug_assert!((colors[0] | colors[1] | colors[2]) >> 24 == 0);
        debug_assert!((clut_high_word | tpage_high_word) & 0xFFFF == 0);
        Self {
            tag: ((Self::WORDS as u32) << 24) | ot_slot as u32,
            color0_cmd: packet::SHADED_TEXTURED_TRIANGLE | colors[0],
            v0: pack_vertex(verts[0].0, verts[0].1),
            uv0_clut: uv_words[0] as u32 | clut_high_word,
            color1: colors[1],
            v1: pack_vertex(verts[1].0, verts[1].1),
            uv1_tpage: uv_words[1] as u32 | tpage_high_word,
            color2: colors[2],
            v2: pack_vertex(verts[2].0, verts[2].1),
            uv2: uv_words[2] as u32,
        }
    }

    /// Renamed to [`Self::with_staged_slot_prepacked_colors`], which is safe.
    ///
    /// # Safety
    ///
    /// Nothing beyond that function's preconditions; it stays `unsafe` so
    /// existing `unsafe` blocks keep compiling without a warning.
    #[deprecated(note = "renamed to `with_staged_slot_prepacked_colors`, which is safe")]
    #[inline(always)]
    pub const unsafe fn with_staged_slot_prepacked_unchecked(
        verts: [(i16, i16); 3],
        uv_words: [u16; 3],
        colors: [u32; 3],
        clut_high_word: u32,
        tpage_high_word: u32,
        ot_slot: u16,
    ) -> Self {
        Self::with_staged_slot_prepacked_colors(
            verts,
            uv_words,
            colors,
            clut_high_word,
            tpage_high_word,
            ot_slot,
        )
    }
}

/// Classic textured Gouraud quad without inline texture-window state. This
/// is the compact GP0(3Ch) packet paired with
/// [`ClassicTriTexturedGouraud`]. 13 words (tag + 12 data).
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[repr(C, align(4))]
pub struct ClassicQuadTexturedGouraud {
    /// Staged OT tag or final DMA linkage.
    pub tag: u32,
    /// GP0(3Ch) plus vertex-zero RGB.
    pub color0_cmd: u32,
    /// Vertex-zero screen coordinate.
    pub v0: u32,
    /// Vertex-zero UV and CLUT.
    pub uv0_clut: u32,
    /// Vertex-one RGB.
    pub color1: u32,
    /// Vertex-one screen coordinate.
    pub v1: u32,
    /// Vertex-one UV and tpage.
    pub uv1_tpage: u32,
    /// Vertex-two RGB.
    pub color2: u32,
    /// Vertex-two screen coordinate.
    pub v2: u32,
    /// Vertex-two UV.
    pub uv2: u32,
    /// Vertex-three RGB.
    pub color3: u32,
    /// Vertex-three screen coordinate.
    pub v3: u32,
    /// Vertex-three UV.
    pub uv3: u32,
}

impl ClassicQuadTexturedGouraud {
    /// Data-word count after the tag.
    pub const WORDS: u8 = 12;

    /// Build a compact packet with a staged OT slot.
    pub const fn with_staged_slot(
        verts: [(i16, i16); 4],
        uv_words: [u16; 4],
        colors: [u32; 4],
        clut: u16,
        tpage: u16,
        ot_slot: u16,
    ) -> Self {
        Self::with_staged_slot_prepacked_material(
            verts,
            uv_words,
            colors,
            (clut as u32) << 16,
            (tpage as u32) << 16,
            ot_slot,
        )
    }

    /// Build a staged compact packet from CLUT and tpage words that have
    /// already been shifted into their GP0 high-halfword positions.
    pub const fn with_staged_slot_prepacked_material(
        verts: [(i16, i16); 4],
        uv_words: [u16; 4],
        colors: [u32; 4],
        clut_high_word: u32,
        tpage_high_word: u32,
        ot_slot: u16,
    ) -> Self {
        Self {
            tag: ((Self::WORDS as u32) << 24) | ot_slot as u32,
            color0_cmd: packet::SHADED_TEXTURED_QUAD | (colors[0] & 0x00ff_ffff),
            v0: pack_vertex(verts[0].0, verts[0].1),
            uv0_clut: uv_words[0] as u32 | clut_high_word,
            color1: colors[1] & 0x00ff_ffff,
            v1: pack_vertex(verts[1].0, verts[1].1),
            uv1_tpage: uv_words[1] as u32 | tpage_high_word,
            color2: colors[2] & 0x00ff_ffff,
            v2: pack_vertex(verts[2].0, verts[2].1),
            uv2: uv_words[2] as u32,
            color3: colors[3] & 0x00ff_ffff,
            v3: pack_vertex(verts[3].0, verts[3].1),
            uv3: uv_words[3] as u32,
        }
    }

    /// Build a staged packet without masking the supplied packet RGB words.
    ///
    /// Every color word must have its high byte clear, and `clut_high_word`
    /// and `tpage_high_word` must hold only their high halfwords; debug builds
    /// assert both. A word that breaks this changes what the GPU draws, not
    /// memory, so the constructor is safe.
    pub const fn with_staged_slot_prepacked_colors(
        verts: [(i16, i16); 4],
        uv_words: [u16; 4],
        colors: [u32; 4],
        clut_high_word: u32,
        tpage_high_word: u32,
        ot_slot: u16,
    ) -> Self {
        debug_assert!((colors[0] | colors[1] | colors[2] | colors[3]) >> 24 == 0);
        debug_assert!((clut_high_word | tpage_high_word) & 0xFFFF == 0);
        Self {
            tag: ((Self::WORDS as u32) << 24) | ot_slot as u32,
            color0_cmd: packet::SHADED_TEXTURED_QUAD | colors[0],
            v0: pack_vertex(verts[0].0, verts[0].1),
            uv0_clut: uv_words[0] as u32 | clut_high_word,
            color1: colors[1],
            v1: pack_vertex(verts[1].0, verts[1].1),
            uv1_tpage: uv_words[1] as u32 | tpage_high_word,
            color2: colors[2],
            v2: pack_vertex(verts[2].0, verts[2].1),
            uv2: uv_words[2] as u32,
            color3: colors[3],
            v3: pack_vertex(verts[3].0, verts[3].1),
            uv3: uv_words[3] as u32,
        }
    }

    /// Renamed to [`Self::with_staged_slot_prepacked_colors`], which is safe.
    ///
    /// # Safety
    ///
    /// Nothing beyond that function's preconditions; it stays `unsafe` so
    /// existing `unsafe` blocks keep compiling without a warning.
    #[deprecated(note = "renamed to `with_staged_slot_prepacked_colors`, which is safe")]
    #[inline(always)]
    pub const unsafe fn with_staged_slot_prepacked_unchecked(
        verts: [(i16, i16); 4],
        uv_words: [u16; 4],
        colors: [u32; 4],
        clut_high_word: u32,
        tpage_high_word: u32,
        ot_slot: u16,
    ) -> Self {
        Self::with_staged_slot_prepacked_colors(
            verts,
            uv_words,
            colors,
            clut_high_word,
            tpage_high_word,
            ot_slot,
        )
    }
}

/// Textured Gouraud quad with inline texture-window state. Mirrors
/// [`TriTexturedGouraud`] extended to four vertices: GP0(E2)
/// texture-window state immediately followed by the GP0(3Ch)
/// Gouraud-textured-quad command. Per-vertex RGB modulates the sampled
/// texel exactly like the triangle. 14 words (tag + 13 data).
///
/// The PS1 GPU rasterizes this quad as the two triangles `(v0,v1,v2)`
/// and `(v1,v2,v3)` -- the `1`-`2` diagonal. A caller whose engine
/// splits quads on the `0`-`2` diagonal as `tri(a,b,c)+tri(a,c,d)` must
/// reorder its perimeter `[a,b,c,d]` to `[b,a,c,d]` before building the
/// packet so the hardware split lands on the same edge; that yields
/// pixel-identical output (proved by
/// `textured_gouraud_quad_matches_two_triangle_split_bitexact` in the
/// emulator GPU tests).
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[repr(C, align(4))]
pub struct QuadTexturedGouraud {
    /// OT linkage.
    pub tag: u32,
    /// GP0(E2) texture-window command.
    pub tex_window: u32,
    /// `0x3C000000 | color0` header -- v0's RGB shares the opcode word.
    pub color0_cmd: u32,
    /// Vertex 0 position.
    pub v0: u32,
    /// `(u0, v0, clut)` packed.
    pub uv0_clut: u32,
    /// Vertex 1 colour.
    pub color1: u32,
    /// Vertex 1 position.
    pub v1: u32,
    /// `(u1, v1, tpage)` packed.
    pub uv1_tpage: u32,
    /// Vertex 2 colour.
    pub color2: u32,
    /// Vertex 2 position.
    pub v2: u32,
    /// `(u2, v2, 0)` packed.
    pub uv2: u32,
    /// Vertex 3 colour.
    pub color3: u32,
    /// Vertex 3 position.
    pub v3: u32,
    /// `(u3, v3, 0)` packed.
    pub uv3: u32,
}

impl QuadTexturedGouraud {
    /// Data-word count (tag excluded).
    pub const WORDS: u8 = 13;

    /// Opcode bit promoting the Gouraud-textured-triangle header
    /// (`0x34`) to the Gouraud-textured-quad header (`0x3C`).
    const QUAD_OPCODE_BIT: u32 = packet::QUAD;

    /// Build a textured Gouraud quad from per-vertex UVs and a
    /// [`TextureMaterial`]. Vertex order is TL, TR, BL, BR; each colour
    /// tints its vertex (`(128, 128, 128)` leaves texels unmodulated).
    pub const fn with_material(
        verts: [(i16, i16); 4],
        uvs: [(u8, u8); 4],
        colors: [(u8, u8, u8); 4],
        material: TextureMaterial,
    ) -> Self {
        let mut uv_words = [0u16; 4];
        let mut i = 0;
        while i < 4 {
            uv_words[i] = uvs[i].0 as u16 | (uvs[i].1 as u16) << 8;
            i += 1;
        }
        Self::with_packet_material_packed_uv_words(
            verts,
            uv_words,
            colors,
            material.textured_gouraud_packet_material(),
        )
    }

    /// Build a textured Gouraud quad from UV words and a packet material
    /// precomputed for a hot material, mirroring
    /// [`TriTexturedGouraud::with_packet_material_packed_uv_words`].
    pub const fn with_packet_material_packed_uv_words(
        verts: [(i16, i16); 4],
        uv_words: [u16; 4],
        colors: [(u8, u8, u8); 4],
        material: TexturedGouraudPacketMaterial,
    ) -> Self {
        let (r0, g0, b0) = colors[0];
        let (r1, g1, b1) = colors[1];
        let (r2, g2, b2) = colors[2];
        let (r3, g3, b3) = colors[3];
        Self {
            tag: 0,
            tex_window: material.tex_window_word,
            color0_cmd: (material.color0_command_word | Self::QUAD_OPCODE_BIT)
                | pack_color(r0, g0, b0),
            v0: pack_vertex(verts[0].0, verts[0].1),
            uv0_clut: (uv_words[0] as u32) | material.clut_high_word,
            color1: pack_color(r1, g1, b1),
            v1: pack_vertex(verts[1].0, verts[1].1),
            uv1_tpage: (uv_words[1] as u32) | material.tpage_high_word,
            color2: pack_color(r2, g2, b2),
            v2: pack_vertex(verts[2].0, verts[2].1),
            uv2: uv_words[2] as u32,
            color3: pack_color(r3, g3, b3),
            v3: pack_vertex(verts[3].0, verts[3].1),
            uv3: uv_words[3] as u32,
        }
    }

    /// Build a self-contained texture-window packet whose tag temporarily
    /// carries `ot_slot` for a later tagged-stream OT linking pass.
    ///
    /// Every color word must have its high byte clear, and `clut_high_word`
    /// and `tpage_high_word` must hold only their high halfwords; debug builds
    /// assert both. A word that breaks this changes what the GPU draws, not
    /// memory, so the constructor is safe.
    pub const fn with_staged_slot_prepacked_colors(
        verts: [(i16, i16); 4],
        uv_words: [u16; 4],
        colors: [u32; 4],
        clut_high_word: u32,
        tpage_high_word: u32,
        texture_window_word: u32,
        ot_slot: u16,
    ) -> Self {
        debug_assert!((colors[0] | colors[1] | colors[2] | colors[3]) >> 24 == 0);
        debug_assert!((clut_high_word | tpage_high_word) & 0xFFFF == 0);
        Self {
            tag: ((Self::WORDS as u32) << 24) | ot_slot as u32,
            tex_window: texture_window_word,
            color0_cmd: packet::SHADED_TEXTURED_QUAD | colors[0],
            v0: pack_vertex(verts[0].0, verts[0].1),
            uv0_clut: uv_words[0] as u32 | clut_high_word,
            color1: colors[1],
            v1: pack_vertex(verts[1].0, verts[1].1),
            uv1_tpage: uv_words[1] as u32 | tpage_high_word,
            color2: colors[2],
            v2: pack_vertex(verts[2].0, verts[2].1),
            uv2: uv_words[2] as u32,
            color3: colors[3],
            v3: pack_vertex(verts[3].0, verts[3].1),
            uv3: uv_words[3] as u32,
        }
    }

    /// Renamed to [`Self::with_staged_slot_prepacked_colors`], which is safe.
    ///
    /// # Safety
    ///
    /// Nothing beyond that function's preconditions; it stays `unsafe` so
    /// existing `unsafe` blocks keep compiling without a warning.
    #[deprecated(note = "renamed to `with_staged_slot_prepacked_colors`, which is safe")]
    #[inline(always)]
    pub const unsafe fn with_staged_slot_prepacked_unchecked(
        verts: [(i16, i16); 4],
        uv_words: [u16; 4],
        colors: [u32; 4],
        clut_high_word: u32,
        tpage_high_word: u32,
        texture_window_word: u32,
        ot_slot: u16,
    ) -> Self {
        Self::with_staged_slot_prepacked_colors(
            verts,
            uv_words,
            colors,
            clut_high_word,
            tpage_high_word,
            texture_window_word,
            ot_slot,
        )
    }

    /// Zeroed packet for static prebuilt-pool initialisation. Real
    /// content is written by the first draw of each surface before the
    /// packet ever links into an ordering table (per-surface validity
    /// bytes guarantee it).
    pub const EMPTY: Self = Self {
        tag: 0,
        tex_window: 0,
        color0_cmd: 0,
        v0: 0,
        uv0_clut: 0,
        color1: 0,
        v1: 0,
        uv1_tpage: 0,
        color2: 0,
        v2: 0,
        uv2: 0,
        color3: 0,
        v3: 0,
        uv3: 0,
    };

    /// Rewrite the four vertex words of a prebuilt packet, leaving
    /// every material/UV/colour word untouched. This is the per-frame
    /// patch for precompiled static world geometry.
    #[inline(always)]
    pub fn set_positions(&mut self, verts: [(i16, i16); 4]) {
        self.v0 = pack_vertex(verts[0].0, verts[0].1);
        self.v1 = pack_vertex(verts[1].0, verts[1].1);
        self.v2 = pack_vertex(verts[2].0, verts[2].1);
        self.v3 = pack_vertex(verts[3].0, verts[3].1);
    }

    /// Copy every packet word except the OT tag from a prebuilt
    /// skeleton. The destination can then patch positions and link
    /// into an ordering table without inheriting a stale DMA link.
    #[inline(always)]
    pub fn copy_payload_from(&mut self, source: &Self) {
        self.tex_window = source.tex_window;
        self.color0_cmd = source.color0_cmd;
        self.v0 = source.v0;
        self.uv0_clut = source.uv0_clut;
        self.color1 = source.color1;
        self.v1 = source.v1;
        self.uv1_tpage = source.uv1_tpage;
        self.color2 = source.color2;
        self.v2 = source.v2;
        self.uv2 = source.uv2;
        self.color3 = source.color3;
        self.v3 = source.v3;
        self.uv3 = source.uv3;
    }

    /// Rewrite the four colour words of a prebuilt packet, preserving
    /// the opcode byte that shares v0's colour word.
    #[inline(always)]
    pub fn set_colors(&mut self, colors: [(u8, u8, u8); 4]) {
        let (r0, g0, b0) = colors[0];
        let (r1, g1, b1) = colors[1];
        let (r2, g2, b2) = colors[2];
        let (r3, g3, b3) = colors[3];
        self.color0_cmd = (self.color0_cmd & 0xFF00_0000) | pack_color(r0, g0, b0);
        self.color1 = pack_color(r1, g1, b1);
        self.color2 = pack_color(r2, g2, b2);
        self.color3 = pack_color(r3, g3, b3);
    }
}

/// Textured quad with a single flat tint. 10 words (tag + 9 data).
///
/// Same CLUT + tpage embedding as [`TriTextured`], extended by
/// one vertex. Vertex order: TL, TR, BL, BR.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[repr(C, align(4))]
pub struct QuadTextured {
    /// OT linkage.
    pub tag: u32,
    /// `0x2C000000 | tint` header.
    pub color_cmd: u32,
    /// V0 position.
    pub v0: u32,
    /// `(u0, v0, clut)`.
    pub uv0_clut: u32,
    /// V1 position.
    pub v1: u32,
    /// `(u1, v1, tpage)`.
    pub uv1_tpage: u32,
    /// V2 position.
    pub v2: u32,
    /// `(u2, v2, 0)`.
    pub uv2: u32,
    /// V3 position.
    pub v3: u32,
    /// `(u3, v3, 0)`.
    pub uv3: u32,
}

impl QuadTextured {
    /// Data-word count.
    pub const WORDS: u8 = 9;

    /// Build a textured quad.
    pub const fn new(
        verts: [(i16, i16); 4],
        uvs: [(u8, u8); 4],
        clut: u16,
        tpage: u16,
        tint: (u8, u8, u8),
    ) -> Self {
        Self::with_material(verts, uvs, TextureMaterial::opaque(clut, tpage, tint))
    }

    /// Build a textured quad using a [`TextureMaterial`].
    pub const fn with_material(
        verts: [(i16, i16); 4],
        uvs: [(u8, u8); 4],
        material: TextureMaterial,
    ) -> Self {
        let (u0, v0) = uvs[0];
        let (u1, v1) = uvs[1];
        let (u2, v2) = uvs[2];
        let (u3, v3) = uvs[3];
        let clut = material.clut_word();
        let tpage = material.texture_page_word();
        Self {
            tag: 0,
            color_cmd: material.flat_textured_polygon_header(true),
            v0: pack_vertex(verts[0].0, verts[0].1),
            uv0_clut: pack_texcoord(u0, v0, clut),
            v1: pack_vertex(verts[1].0, verts[1].1),
            uv1_tpage: pack_texcoord(u1, v1, tpage),
            v2: pack_vertex(verts[2].0, verts[2].1),
            uv2: pack_texcoord(u2, v2, 0),
            v3: pack_vertex(verts[3].0, verts[3].1),
            uv3: pack_texcoord(u3, v3, 0),
        }
    }
}

/// Textured quad with inline texture-window state. 11 words (tag + 10 data).
///
/// This mirrors [`TriTextured`]'s self-contained OT packet shape for
/// quads: GP0(E2) texture-window state immediately followed by the
/// GP0(2Ch) textured-quad command. Use it when OT interleaving must
/// not leak window state across different textured draws.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[repr(C, align(4))]
pub struct QuadTexturedMaterial {
    /// OT linkage.
    pub tag: u32,
    /// GP0(E2) texture-window command.
    pub tex_window: u32,
    /// `0x2C000000 | tint` header.
    pub color_cmd: u32,
    /// V0 position.
    pub v0: u32,
    /// `(u0, v0, clut)`.
    pub uv0_clut: u32,
    /// V1 position.
    pub v1: u32,
    /// `(u1, v1, tpage)`.
    pub uv1_tpage: u32,
    /// V2 position.
    pub v2: u32,
    /// `(u2, v2, 0)`.
    pub uv2: u32,
    /// V3 position.
    pub v3: u32,
    /// `(u3, v3, 0)`.
    pub uv3: u32,
}

impl QuadTexturedMaterial {
    /// Data-word count.
    pub const WORDS: u8 = 10;

    /// Build a textured quad with self-contained material state.
    pub const fn with_material(
        verts: [(i16, i16); 4],
        uvs: [(u8, u8); 4],
        material: TextureMaterial,
    ) -> Self {
        let (u0, v0) = uvs[0];
        let (u1, v1) = uvs[1];
        let (u2, v2) = uvs[2];
        let (u3, v3) = uvs[3];
        let clut = material.clut_word();
        let tpage = material.texture_page_word();
        Self {
            tag: 0,
            tex_window: material.texture_window_word(),
            color_cmd: material.flat_textured_polygon_header(true),
            v0: pack_vertex(verts[0].0, verts[0].1),
            uv0_clut: pack_texcoord(u0, v0, clut),
            v1: pack_vertex(verts[1].0, verts[1].1),
            uv1_tpage: pack_texcoord(u1, v1, tpage),
            v2: pack_vertex(verts[2].0, verts[2].1),
            uv2: pack_texcoord(u2, v2, 0),
            v3: pack_vertex(verts[3].0, verts[3].1),
            uv3: pack_texcoord(u3, v3, 0),
        }
    }
}

/// Textured sprite (variable size). 5 words (tag + 4 data).
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[repr(C, align(4))]
pub struct Sprite {
    /// OT linkage.
    pub tag: u32,
    /// `0x64000000 | color` header (blend color applied over texture).
    pub color_cmd: u32,
    /// Top-left `xy`.
    pub xy: u32,
    /// `uv | clut` (U/V in low half, CLUT handle in high half).
    pub uv_clut: u32,
    /// Size `wh`.
    pub wh: u32,
}

impl Sprite {
    /// Data-word count.
    pub const WORDS: u8 = 4;

    /// Build a textured sprite. `clut` is the CLUT register handle
    /// (`y << 6 | x >> 4`); `uv` is the 8-bit texcoord within the
    /// texture page.
    pub const fn new(
        x: i16,
        y: i16,
        w: u16,
        h: u16,
        uv: (u8, u8),
        clut: u16,
        r: u8,
        g: u8,
        b: u8,
    ) -> Self {
        let material = TextureMaterial::opaque(clut, 0, (r, g, b));
        Self::with_material(x, y, w, h, uv, material)
    }

    /// Build a textured sprite using a [`TextureMaterial`].
    ///
    /// Sprite packets do not carry a tpage word. The material's CLUT,
    /// tint, raw-texture bit, and semi-transparent command bit are
    /// encoded in the packet; the caller must set the matching draw
    /// mode before OT submission if the sprite samples a non-current
    /// tpage.
    pub const fn with_material(
        x: i16,
        y: i16,
        w: u16,
        h: u16,
        uv: (u8, u8),
        material: TextureMaterial,
    ) -> Self {
        Self {
            tag: 0,
            color_cmd: material.textured_rect_header(),
            xy: pack_vertex(x, y),
            uv_clut: pack_texcoord(uv.0, uv.1, material.clut_word()),
            wh: pack_xy(w, h),
        }
    }
}

/// A GPU packet that can be linked into an ordering table as one DMA node.
///
/// [`crate::frame::OtFrame::add`] uses it to insert a packet without a
/// separate word count.
///
/// # Safety
///
/// The implementing type must be `#[repr(C)]` with 4-byte alignment and a
/// `u32` tag word as its first field, followed by at least `WORDS` more
/// initialised `u32`s that form the packet's GP0 payload. `WORDS` must not
/// exceed [`crate::chain::MAX_NODE_WORDS`]. The type must have no interior
/// mutability, so the payload cannot change while it is borrowed.
pub unsafe trait GpuPacket {
    /// Payload words after the tag.
    const WORDS: u8;
}

macro_rules! impl_gpu_packet {
    ($($ty:ty),+ $(,)?) => {
        $(
            // SAFETY: an SDK packet: `#[repr(C, align(4))]`, tag first, then
            // `WORDS` payload words of plain `u32` data (checked below).
            unsafe impl GpuPacket for $ty {
                const WORDS: u8 = <$ty>::WORDS;
            }
            const _: () = {
                assert!(core::mem::size_of::<$ty>() >= 4 * (1 + <$ty>::WORDS as usize));
                assert!(core::mem::align_of::<$ty>() >= 4);
            };
        )+
    };
}

impl_gpu_packet!(
    TriFlat,
    TriGouraud,
    QuadFlat,
    RectFlat,
    FillRect,
    QuadGouraud,
    QuadGouraudBlended,
    LineMono,
    LineGouraud,
    TriTextured,
    ClassicTriTextured,
    TriTexturedGouraud,
    ClassicTriTexturedGouraud,
    ClassicQuadTexturedGouraud,
    QuadTexturedGouraud,
    QuadTextured,
    QuadTexturedMaterial,
    Sprite,
);

// Every packet here fits one linked-list node (see `crate::chain::MAX_NODE_WORDS`).
const _: () = {
    let words = [
        TriFlat::WORDS,
        TriGouraud::WORDS,
        QuadFlat::WORDS,
        RectFlat::WORDS,
        FillRect::WORDS,
        QuadGouraud::WORDS,
        QuadGouraudBlended::WORDS,
        LineMono::WORDS,
        LineGouraud::WORDS,
        TriTextured::WORDS,
        ClassicTriTextured::WORDS,
        TriTexturedGouraud::WORDS,
        ClassicTriTexturedGouraud::WORDS,
        ClassicQuadTexturedGouraud::WORDS,
        QuadTexturedGouraud::WORDS,
        QuadTextured::WORDS,
        QuadTexturedMaterial::WORDS,
        Sprite::WORDS,
    ];
    let mut i = 0;
    while i < words.len() {
        assert!(words[i] as usize <= crate::chain::MAX_NODE_WORDS);
        i += 1;
    }
};

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn blended_gouraud_quad_keeps_draw_mode_and_polygon_together() {
        let quad = QuadGouraudBlended::new(
            [(1, 2), (3, 4), (5, 6), (7, 8)],
            [
                (0x10, 0x20, 0x30),
                (0x40, 0x50, 0x60),
                (0x70, 0x80, 0x90),
                (0xa0, 0xb0, 0xc0),
            ],
            BlendMode::AddQuarter,
        );
        // SAFETY: QuadGouraudBlended is `repr(C, align(4))` with only u32 fields, so `quad` is
        // aligned and its size_of / 4 words are initialised u32s that outlive the slice.
        let words = unsafe {
            core::slice::from_raw_parts(
                (&quad as *const QuadGouraudBlended).cast::<u32>(),
                core::mem::size_of::<QuadGouraudBlended>() / core::mem::size_of::<u32>(),
            )
        };
        assert_eq!(words.len(), 10);
        assert_eq!(QuadGouraudBlended::WORDS, 9);
        assert_eq!(words[0], 0, "tag zero until OT insert");
        assert_eq!(words[1] >> 24, 0xe1, "draw-mode prefix");
        assert_eq!((words[1] >> 5) & 3, 3, "add-quarter ABR bits");
        assert_eq!(words[2] >> 24, 0x3a, "Gouraud+quad+semi-trans opcode");
    }

    /// The Gouraud-textured quad packet must serialize to the exact GP0
    /// 0x3C word stream: a GP0(E2) texture-window prefix, then
    /// `[0x3C|c0, v0, uv0|clut, c1, v1, uv1|tpage, c2, v2, uv2, c3, v3, uv3]`.
    /// This guards the on-wire layout the DMA walker and emulator decode.
    #[test]
    fn quad_textured_gouraud_serializes_to_gp0_3c_stream() {
        let material =
            TexturedGouraudPacketMaterial::from_texture(TextureMaterial::new(0x1234, 0x0105));
        let uvw = [0x0201u16, 0x3C04, 0x3C42, 0x0240];
        let cols = [
            (0x11u8, 0x22u8, 0x33u8),
            (0x44, 0x55, 0x66),
            (0x77, 0x88, 0x99),
            (0xAA, 0xBB, 0xCC),
        ];
        let verts = [(10i16, 20i16), (110, 20), (110, 90), (10, 90)];
        let quad =
            QuadTexturedGouraud::with_packet_material_packed_uv_words(verts, uvw, cols, material);

        assert_eq!(core::mem::size_of::<QuadTexturedGouraud>(), 14 * 4);
        assert_eq!(QuadTexturedGouraud::WORDS, 13);

        // SAFETY: QuadTexturedGouraud is `repr(C, align(4))` with only u32 fields, and its size was
        // just asserted to be 14 words, so the slice covers exactly `quad`.
        let words = unsafe {
            core::slice::from_raw_parts((&quad as *const QuadTexturedGouraud).cast::<u32>(), 14)
        };
        assert_eq!(words[0], 0, "tag zero until OT insert");
        assert_eq!(words[1], material.tex_window_word, "E2 window prefix");
        assert_eq!(words[2] >> 24, 0x3C, "Gouraud+textured+quad opcode");
        assert_eq!(words[2] & 0x00FF_FFFF, pack_color(0x11, 0x22, 0x33));
        assert_eq!(words[3], pack_vertex(10, 20));
        assert_eq!(words[4], 0x0201 | material.clut_high_word);
        assert_eq!(words[5], pack_color(0x44, 0x55, 0x66));
        assert_eq!(words[6], pack_vertex(110, 20));
        assert_eq!(words[7], 0x3C04 | material.tpage_high_word);
        assert_eq!(words[8], pack_color(0x77, 0x88, 0x99));
        assert_eq!(words[9], pack_vertex(110, 90));
        assert_eq!(words[10], 0x3C42);
        assert_eq!(words[11], pack_color(0xAA, 0xBB, 0xCC));
        assert_eq!(words[12], pack_vertex(10, 90));
        assert_eq!(words[13], 0x0240);
    }

    #[test]
    fn classic_packets_omit_texture_window_and_stage_ot_slot() {
        let tri = ClassicTriTexturedGouraud::with_staged_slot(
            [(1, 2), (3, 4), (5, 6)],
            [0x0201, 0x0403, 0x0605],
            [0x0033_2211, 0x0066_5544, 0x0099_8877],
            0x1234,
            0x0105,
            77,
        );
        assert_eq!(core::mem::size_of::<ClassicTriTexturedGouraud>(), 10 * 4);
        assert_eq!(tri.tag, (9 << 24) | 77);
        assert_eq!(tri.color0_cmd, 0x3433_2211);
        assert_eq!(tri.uv0_clut, 0x1234_0201);
        assert_eq!(tri.uv1_tpage, 0x0105_0403);

        let quad = ClassicQuadTexturedGouraud::with_staged_slot(
            [(1, 2), (3, 4), (5, 6), (7, 8)],
            [0x0201, 0x0403, 0x0605, 0x0807],
            [0x0033_2211, 0x0066_5544, 0x0099_8877, 0x00cc_bbaa],
            0x1234,
            0x0105,
            88,
        );
        assert_eq!(core::mem::size_of::<ClassicQuadTexturedGouraud>(), 13 * 4);
        assert_eq!(quad.tag, (12 << 24) | 88);
        assert_eq!(quad.color0_cmd, 0x3c33_2211);
        assert_eq!(quad.uv3, 0x0807);
    }

    #[test]
    fn classic_unchecked_packets_match_checked_packets_for_valid_words() {
        let tri_verts = [(1, 2), (3, 4), (5, 6)];
        let tri_uvs = [0x0201, 0x0403, 0x0605];
        let tri_colors = [0x0033_2211, 0x0066_5544, 0x0099_8877];
        let checked_tri = ClassicTriTexturedGouraud::with_staged_slot_prepacked_material(
            tri_verts,
            tri_uvs,
            tri_colors,
            0x1234_0000,
            0x0105_0000,
            77,
        );
        let unchecked_tri = ClassicTriTexturedGouraud::with_staged_slot_prepacked_colors(
            tri_verts,
            tri_uvs,
            tri_colors,
            0x1234_0000,
            0x0105_0000,
            77,
        );
        // SAFETY: ClassicTriTexturedGouraud is `repr(C, align(4))` with only u32 fields, so the
        // slice covers exactly the initialised local, which outlives it.
        let checked_tri_words = unsafe {
            core::slice::from_raw_parts(
                (&raw const checked_tri).cast::<u32>(),
                core::mem::size_of::<ClassicTriTexturedGouraud>() / core::mem::size_of::<u32>(),
            )
        };
        // SAFETY: ClassicTriTexturedGouraud is `repr(C, align(4))` with only u32 fields, so the
        // slice covers exactly the initialised local, which outlives it.
        let unchecked_tri_words = unsafe {
            core::slice::from_raw_parts(
                (&raw const unchecked_tri).cast::<u32>(),
                core::mem::size_of::<ClassicTriTexturedGouraud>() / core::mem::size_of::<u32>(),
            )
        };
        assert_eq!(checked_tri_words, unchecked_tri_words);

        let quad_verts = [(1, 2), (3, 4), (5, 6), (7, 8)];
        let quad_uvs = [0x0201, 0x0403, 0x0605, 0x0807];
        let quad_colors = [0x0033_2211, 0x0066_5544, 0x0099_8877, 0x00cc_bbaa];
        let checked_quad = ClassicQuadTexturedGouraud::with_staged_slot_prepacked_material(
            quad_verts,
            quad_uvs,
            quad_colors,
            0x1234_0000,
            0x0105_0000,
            88,
        );
        let unchecked_quad = ClassicQuadTexturedGouraud::with_staged_slot_prepacked_colors(
            quad_verts,
            quad_uvs,
            quad_colors,
            0x1234_0000,
            0x0105_0000,
            88,
        );
        // SAFETY: ClassicQuadTexturedGouraud is `repr(C, align(4))` with only u32 fields, so the
        // slice covers exactly the initialised local, which outlives it.
        let checked_quad_words = unsafe {
            core::slice::from_raw_parts(
                (&raw const checked_quad).cast::<u32>(),
                core::mem::size_of::<ClassicQuadTexturedGouraud>() / core::mem::size_of::<u32>(),
            )
        };
        // SAFETY: ClassicQuadTexturedGouraud is `repr(C, align(4))` with only u32 fields, so the
        // slice covers exactly the initialised local, which outlives it.
        let unchecked_quad_words = unsafe {
            core::slice::from_raw_parts(
                (&raw const unchecked_quad).cast::<u32>(),
                core::mem::size_of::<ClassicQuadTexturedGouraud>() / core::mem::size_of::<u32>(),
            )
        };
        assert_eq!(checked_quad_words, unchecked_quad_words);
    }
}
