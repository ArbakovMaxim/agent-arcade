# Asset and Media Provenance

This document records sources, authors, and licenses for the assets covered
by the June 2026 audit. It is not a complete inventory of later project assets. PSoXide's *code*
is licensed under GPL-2.0-or-later (see [`LICENSE`](../LICENSE)), but
binary assets each carry their own provenance and license, recorded
here.

Last updated: 2026-06-18.

## Known Unresolved Provenance Items

These items are documented in full in the sections below; they are collected
here so the open questions are visible up front. None is a licensing blocker
for the *code*; all concern bundled binary assets and should be resolved
before a public or commercial release. Nothing here is guessed: where a fact
is not recorded in the repo, it is listed as missing rather than invented.

1. **Exact Pexels source URLs** for `brick-wall.jpg` and `floor.jpg` were not
   captured at download time. The Pexels License permits the use; only the
   source URLs are missing. Action: locate and record the URLs, or replace
   with newly sourced images whose URLs are recorded. See "Textures".

## Branding

| File | Source | Author | License |
| --- | --- | --- | --- |
| `assets/branding/psoxide-logo.svg` | Original work | Emanuele Bonura | GPL-2.0-or-later |
| `assets/branding/psoxide-logo.png` | Rendered from `psoxide-logo.svg` | Emanuele Bonura | GPL-2.0-or-later |
| `assets/branding/psoxide-app-icon.svg` | Original work | Emanuele Bonura | GPL-2.0-or-later |
| `assets/branding/psoxide-app-icon.png` | Rendered from `psoxide-app-icon.svg` | Emanuele Bonura | GPL-2.0-or-later |
| `assets/branding/psoxide-itch-cover.svg` | Original work | Emanuele Bonura | GPL-2.0-or-later |
| `assets/branding/psoxide-itch-cover.png` | Rendered from `psoxide-itch-cover.svg` | Emanuele Bonura | GPL-2.0-or-later |

## 3D Models

> **Moved.** These two placeholder models now live in the PSoXide-editor repository
> (`assets/models/obsidian_wraith` and `assets/models/hooded_wretch`). This repository
> no longer contains them; the records below are kept for the audit trail.

The two character models bundled in the repo were generated using
**[Meshy](https://www.meshy.ai/)**, an AI 3D-model generation service.
They are placeholder / development / proof-of-concept assets used by
the engine showcase example and by the default editor project to
exercise the runtime model pipeline. They are not intended as final
shippable game content.

The models were generated under a paid Meshy subscription and are
marked private in the Meshy account. Meshy's current
[pricing](https://www.meshy.ai/pricing) and
[help](https://help.meshy.ai/en/articles/9992022-can-i-sell-the-models-on-other-platforms)
pages describe Pro/Studio/Enterprise generated assets as "private &
customer owned", and state that premium subscribers own the assets they
create with Meshy and may distribute or sell them. Keep the subscription
receipt / invoice and export metadata with the project records so this
remains auditable.

| Directory | Source | License |
| --- | --- | --- |
| `assets/models/obsidian_wraith/*` | Generated via Meshy (AI), paid subscription, private asset | User-owned per Meshy premium plan terms; distributed here under GPL-2.0-or-later |
| `assets/models/hooded_wretch/*` | Generated via Meshy (AI), paid subscription, private asset | User-owned per Meshy premium plan terms; distributed here under GPL-2.0-or-later |
| `editor/projects/default/assets/models/obsidian_wraith/*` | Cooked copy of the above for the default editor project | Same as above |

The two models share the same Meshy biped rig (24 joints), as already
noted in
[`engine/examples/showcase-model/src/main.rs`](../engine/examples/showcase-model/src/main.rs).

Note: Meshy's terms still make the user responsible for ensuring input
materials do not violate third-party rights. These models should remain
acceptable as bundled assets only if their prompts/reference inputs
were rights-clean.

## Textures

Source JPGs are bundled at 512×512 in the example `vendor/`
directories. The `.psxt` files alongside the assets are cooked
(quantised, palettised, VRAM-packed) outputs derived from those JPGs
via the editor's texture cooker (`make assets`).

| File | Source | Author | License |
| --- | --- | --- | --- |
| `sdk/examples/hello-tex/vendor/brick-wall.jpg` | "Brick Wall" via [Pexels](https://www.pexels.com/license/) | Michael Laut | Pexels License |
| `sdk/examples/hello-tex/vendor/floor.jpg` | "Batako Wall Texture Street" via [Pexels](https://www.pexels.com/license/) | (uncredited Pexels contributor) | Pexels License |
| `engine/examples/showcase-fog/vendor/brick-wall.jpg` | Byte-identical copy of `sdk/examples/hello-tex/vendor/brick-wall.jpg` | Michael Laut | Pexels License |
| `engine/examples/showcase-fog/vendor/floor.jpg` | Byte-identical copy of `sdk/examples/hello-tex/vendor/floor.jpg` | (uncredited Pexels contributor) | Pexels License |
| `assets/textures/brick-wall.psxt` | Cooked from `brick-wall.jpg` | (derived) | Pexels License (inherited) |
| `assets/textures/floor.psxt` | Cooked from `floor.jpg` | (derived) | Pexels License (inherited) |
| `editor/projects/default/assets/textures/brick-wall.psxt` | Cooked copy of `brick-wall.jpg` for the default editor project | (derived) | Pexels License (inherited) |
| `editor/projects/default/assets/textures/floor.psxt` | Cooked copy of `floor.jpg` for the default editor project | (derived) | Pexels License (inherited) |
| `editor/projects/default/assets/textures/torment_*.psxt` | Cooked/downsampled from Torment Textures v1.1 true-colour PNGs (`str_stonebrk1..4`, `str_stoneflr1..4`, `str_stonegen1..6`, `str_stonewall1..4`, `str_stonerubble`, `str_rotwoodgen1..3`, `{str_grating1..3`, `str_wasteland1..6`) | Torment Textures by Bradley D. ([Strideh](https://strideh.itch.io)) | Torment Textures license: commercial/free use, modification, and open-source distribution permitted with attribution; standalone asset resale and generative AI training use prohibited |
| `assets/models/*/*.psxt` (model textures) | See "3D Models" above | (Meshy) | User-owned per Meshy premium plan terms; distributed here under GPL-2.0-or-later |
| `engine/examples/game-magikaaaaaarp-pong/vendor/magikaaaaaarp_album.jpg` | magikAAAAArp album artwork, provided by the band | magikAAAAArp | Used with magikAAAAArp's permission; keep the authorization on record |
| `engine/examples/game-magikaaaaaarp-pong/assets/magikaaaaaarp_album.psxt` | Cooked from `magikaaaaaarp_album.jpg` | (derived) | Same as source |
| `engine/examples/game-magikaaaaaarp-pong/assets/goncharov_spectrum_16x30hz.bin` | Baked 16-band, 30 Hz visualizer table from `assets/audio/cdda/GONCHAROV.wav` via `psoxide-dev bake-spectrum` | (derived) | Same as source |

The Pexels License (https://www.pexels.com/license/) permits free
commercial and non-commercial use, modification, and redistribution;
attribution is appreciated but not required.

**TODO before public release**: locate and record the exact Pexels
URLs for both source images. The originals were downloaded without
the URLs being captured at the time;
[hello-tex/vendor/README.md](../sdk/examples/hello-tex/vendor/README.md)
records the titles and Pexels as origin but not the URLs.

## Fonts

See also [`emu/crates/frontend/assets/fonts/PROVENANCE.md`](../emu/crates/frontend/assets/fonts/PROVENANCE.md).

| File | Source | Author | License |
| --- | --- | --- | --- |
| `emu/crates/frontend/assets/fonts/VT323-Regular.ttf` | [Google Fonts](https://fonts.google.com/specimen/VT323) | Peter Hull | SIL Open Font License 1.1 |
| `emu/crates/frontend/assets/fonts/lucide.ttf` | [lucide.dev](https://lucide.dev/) | Lucide Contributors | ISC |
| `sdk/crates/psx-font/vendor/font8x8.bin` | font8x8 (PD) | dhepper | Public Domain |
| `sdk/crates/psx-font/vendor/IBM_VGA_8x16.bin` | IBM VGA BIOS font (PD) | IBM, extracted via VileR's font collection | Public Domain |

Font8x8 and IBM VGA fonts are already documented in detail at
[`sdk/crates/psx-font/vendor/PROVENANCE.md`](../sdk/crates/psx-font/vendor/PROVENANCE.md).

## CD-DA Music

| File | Source | Author | License |
| --- | --- | --- | --- |
| `assets/audio/cdda/GONCHAROV.wav` | Cooked from `local-assets/audio/goncharov-source.mp3` (magikAAAAArp track) | magikAAAAArp | Used with magikAAAAArp's permission; keep the authorization on record |
| `assets/audio/cdda/GONCHAROV.track02.cdda` | Cooked from `GONCHAROV.wav` as 44.1 kHz stereo signed 16-bit PCM, sector-padded for CD-DA track 2 | (derived) | Same as source |

## OBJ Reference Models

These are public-domain or hand-authored reference meshes used by SDK
or engine examples to exercise the rasterizer. Already reasonably
well-documented in their file headers, listed here for completeness.

| File | Source | License |
| --- | --- | --- |
| `engine/examples/showcase-lights/vendor/cube.obj` | Hand-authored | Public Domain (per file header) |
| `engine/examples/showcase-3d/vendor/teapot.obj` | Simplified Utah Teapot | Public Domain (Utah Teapot is public domain by Martin Newell, 1975) |
| `engine/examples/showcase-3d/vendor/suzanne.obj` | Blender's Suzanne mesh, decimated via MeshLab | CC-0 / Public Domain (Blender Foundation) |

## README Media

| File | Author | License | Notes |
| --- | --- | --- | --- |
| `docs/media/editor-3d-view.png` | Emanuele Bonura | GPL-2.0-or-later | Screenshot of the editor 3D viewport. Visible content includes the paid-subscription Meshy-generated character models documented above. |
| `docs/media/embedded-play-mode.png` | Emanuele Bonura | GPL-2.0-or-later | Screenshot of embedded play mode. Same Meshy asset provenance applies. |

## Excluded From Repository

The following categories are deliberately not tracked or distributed:

- PlayStation BIOS images. Nothing in this repository loads one: every boot goes
  through the built-in HLE runtime (see [README](../README.md)).
- Commercial game disc images.
- PCSX-Redux binaries or source.
- Direct renders of console firmware output. Parity tests compare
  hashes only; no firmware-derived image is stored.
- Mednafen / DuckStation source - used only as behavioural references
  (see [`LICENSE`](../LICENSE)).

## Pre-Publish Action Items

1. Preserve evidence for the Meshy models: paid subscription invoice,
   asset privacy status, export date, and rights-clean prompt/reference
   notes.
2. Capture exact Pexels URLs for `brick-wall.jpg` and `floor.jpg` (or
   replace with newly-sourced textures whose URLs are recorded at
   download time).
3. Run `cargo deny` or `cargo about` across every workspace to confirm
   no transitive dependency carries a license incompatible with
   GPL-2.0-or-later, and commit the report.
