# VoXide

**[Download the latest version on itch.io](https://bonnie-studios.itch.io/voxide)**

> **Largely written with agentic coding.** I direct the agents and test their work in two places: PSoXide's emulator, which profiles every cycle, and a real PlayStation, which shows me where the emulator is wrong. Working between them is where the accuracy and the speed come from. [How PSoXide is built](https://ebonura.github.io/PSoXide/how-its-built/)

It's also on the [PSoXide Demo Disc](https://bonnie-studios.itch.io/psoxide-demo-disc) with the other Bonnie Studios PlayStation games, and you can [play it in your browser](https://bonnie-studios.itch.io/psoxide).

A Minecraft-style survival sandbox for the PlayStation 1, written in Rust on
top of the PSoXide SDK.

The world is chunked and streamed. Chunks are 16x16x64 and recentre on the
player as you walk, so it never runs out. Terrain comes from seeded fixed-point
noise, which gives biomes, caves, ore banded by depth, lava pockets and a sea
level, with trees scattered on top of that.

From there it's most of the survival loop: mining and placing, crafting,
furnace smelting, hunger and health, farming, fluids that flow, fire that
spreads, animals you can breed and hostiles that come out at night, XP and
enchanting, and two other dimensions, the Inferno and the Void, if you build
the portals.

Some things work differently to Java, deliberately. Crafting is a tabbed recipe
book, with a 2x2 grid on the player page that R2 fills in for a recipe, rather
than a 3x3 grid at the table, because placing items into a grid with a d-pad is
worse than picking what you want to make; Minecraft's own console editions made
the same call. You choose the weapon you swing at mobs, and the game still
picks the tool that suits the block you're aiming at. Music follows Java too: a piece plays, then silence for 10 to 20 minutes.
Structures, falling sand, boats and rails, hoppers and signs aren't in yet.

Detailed terrain
draws 20 blocks ahead (the outermost ring as coarse two-block tops), projected on the GTE, using 2D
greedy meshing over cached per-chunk face pools that only rebuild the planes an
edit actually touches.

The measured rate is **20fps** in the grassy, tree-and-flower terrain the game spawns you
into. The same renderer holds a locked **30fps** in sparse terrain: the sandier
spawn it used to ship measures exactly that on the same route. So roughly a
third of the frame budget goes on trees and ground plants, and vegetation won
that trade on purpose, because a green world looks like the game it is nodding
to and a beige one does not.

What limits draw distance is the cost of projecting faces, not memory. I tried
imposters for the far ring and pulled them back out after measuring that they
drew no visible pixels.

Every asset is CC0. Block art is the "16x16 Block Texture Set" from
OpenGameArt, quantised to per-block CLUTs by `tools/voxide-tools` (`convert-pack`); tiles the
pack doesn't cover are drawn in code. Sources are credited in
`assets/pack/CREDITS.md` and on the in-game credits screen. No Mojang assets,
code or data are used.

## Play it

The disc image is on [itch.io](https://bonnie-studios.itch.io/voxide). VoXide
also ships on the
[PSoXide Demo Disc](https://bonnie-studios.itch.io/psoxide-demo-disc), which
runs [in your browser](https://bonnie-studios.itch.io/psoxide) on the PSoXide
page, no console needed.

## Build

VoXide uses the [PSoXide SDK](https://github.com/EBonura/PSoXide) as Cargo
path dependencies. `make` imports the exact SDK, editor/engine and
emulator-library revisions in `components.lock.json` into ignored `.psoxide/`
(the same lock the other PSoXide games use); a sibling checkout is not
required. For a checkout that predates the lock, preserve or remove its old
`.psoxide/` cache once before building: imports refuse to overwrite unowned or
edited files.

```bash
git clone https://github.com/EBonura/voxide.git
cd voxide
make disc
```

```bash
make psoxide      # import the revisions in components.lock.json
make compile      # PSX-EXE only
make disc         # dist/voxide.cue + dist/voxide.bin
make install      # copy the disc into the local game library
make smoke        # boot through PSoXide headless and write captures/
```

The build needs a nightly Rust toolchain (pinned by `rust-toolchain.toml`,
which also pulls `rust-src` for the `mipsel-sony-psx` target) and Make. Host
Rust tools require a C/C++ linker. The asset converters, the benchmark tape
generator and the profile report are Rust crates in `tools/voxide-tools`, so
recooking source assets needs nothing else installed.

`make disc` writes `dist/voxide.{bin,cue}` and installs a copy under
`~/Downloads/ps1 games/VoXide/`; override that library with `GAMES_DIR`.
Keep each BIN/CUE pair together. For smoke tests, build the separate
[PSoXide emulator](https://github.com/EBonura/PSoXide-emulator) and pass
`make smoke FRONTEND=/absolute/path/to/frontend`. `PSOXIDE_FROM` is an
explicit source override for SDK development and demo-disc integration.

## Controls

The layout follows Minecraft Bedrock's PS4/PS5 defaults.

- Left stick: move (forward/back + strafe); D-pad works as a fallback
  (up/down walk, left/right strafe)
- Right stick: turn and look (a full push turns 117 degrees a second and
  pitches 98 at LOOK SPEED 100%)
- Cross: jump; hold it in water to swim up; in creative fly (toggled in the
  options menu) Cross rises and Circle sinks
- Circle: hold to sneak (slow, and you will not walk off a ledge); backs
  out of any menu
- Square: pocket crafting (planks, sticks, torches, the crafting table);
  everything else needs a placed crafting table, opened with L2, as in the
  original. L1/R1 page the category tabs (blocks, gear, items, food), D-pad
  selects, Cross crafts (hold for more), Triangle crafts as many as the
  ingredients allow, Select hides what you lack materials for, R2 lays a
  small recipe in the 2x2 grid
- Triangle: inventory, opened on the player page; L1/R1 page to the item
  tabs. Select shows the full catalogue instead of what you own
- In every inventory screen (item tabs and hotbar, the player page and its
  2x2 grid, chests, furnaces) the four face buttons mean the same thing, and
  a prompt bar at the bottom shows what each does for the slot under the
  cursor: Cross takes a stack, then places it (swapping with what is there);
  Square takes half, then places one (hold it to keep placing in a chest);
  Triangle quick-moves the stack under the cursor (to the hotbar, back to
  the pack, across to the chest or furnace, wears armour, crafts all);
  Circle puts the stack in hand back, or closes the screen when the hand is
  empty
- L2: use -- interact with the targeted mob or block (chest, furnace, bed,
  enchant table, door), otherwise place/use the held block or item (bow,
  bucket, wheat, ...); sneak + L2 force-places
- R2: tap to attack the mob under the crosshair, hold to mine the targeted
  block (time scales with hardness and tool). As in Java, a mob in front of
  a block takes the crosshair: no block outline or cracks show behind it
- L1 / R1: hotbar previous/next (9 slots, wraps; an empty slot is an empty
  hand)
- L3 or double-tap forward: sprint (drops when forward stops)
- Start: the game menu -- BACK TO GAME, OPTIONS..., CONTROLS (every button on
  a two-page card), SAVE WORLD and LOAD WORLD (memory card) and SAVE AND QUIT
  TO TITLE (saves, then back to the title screen; PLAY GAME there starts a new
  world, LOAD WORLD there or in the game menu brings the saved one back). OPTIONS... opens
  VIDEO SETTINGS (brightness, screen position), MUSIC & SOUNDS (the two
  volumes), STICK SETTINGS (look speed, invert, deadzones) and GAMEPLAY (the
  tutorial toggle and CHEATS), then SAVE SETTINGS to keep what you changed.
  Cross enters a page or does the row, left/right changes a value, Circle goes
  up one page (and closes the menu from the first), Start closes it from
  anywhere. Each page remembers its row
- Main menu: up/down moves between PLAY GAME, LOAD WORLD, NEW WORLD, CONTROLS,
  SETTINGS and CREDITS; Cross confirms. PLAY GAME goes straight into the world;
  LOAD WORLD loads the world saved on the memory card in slot 1 (it is dim, and
  says why when you move onto it, with no card or no saved world); the
  controls card is on the CONTROLS row (and in the game menu). SETTINGS opens the same OPTIONS pages as the game menu, minus CHEATS

Settings are never written on their own. Changes to the sticks, volume,
brightness and screen position last until you power off, unless you choose SAVE
SETTINGS on the OPTIONS page (SETTINGS on the main menu). That writes
them to the memory card. On a blank card, the first SAVE SETTINGS asks and the
second formats it.

Earlier builds showed the controls card on the first PLAY and kept a "seen" mark
for it in the settings record. Nothing reads or writes that mark now; cards
with it set or not load as before.

A first run walks you through the basics with a chain of hint toasts: look,
move, jump, chop a tree, craft planks, craft a table, place it, open it, then
make a pickaxe. OPTIONS > GAMEPLAY > TUTORIAL turns it off.

There are four tools, a pickaxe, axe, shovel and sword, each crafted per tier
from wood up to diamond. They wear out at Java's rates, a better one
auto-equips, and the game picks whichever suits the block under your
crosshair, so the slot beside the hotbar changes as you look around. Using the
right tool is what makes a block break quickly; the wrong one works at
bare-hand pace. Only a pickaxe of the right tier will yield ore. The weapon you
swing at mobs is your choice, from the player page: fist, sword, axe, pickaxe
or shovel, each with Java's damage and attack speed.

Holding up or down in any menu autorepeats after a beat.

### Cheats

Press Start, then OPTIONS..., GAMEPLAY... and CHEATS.... Up/down picks a row,
left/right changes TIME, WEATHER and SPAWN, Cross acts, Circle goes back to
GAMEPLAY.

- FLY (NO CLIP): flight, which passes through blocks (the only flight switch)
- GOD MODE: health, hunger and breath stay full
- SHOW XYZ + FPS: block coordinates and frame rate in the top-left corner
- GIVE EVERYTHING: 64 of every block and item, diamond tools and armour
- TIME: jump to sunrise, noon, sunset or midnight
- WEATHER: clear, rain or a thunderstorm (as Java's /weather sets them),
  or LIGHTNING, a bolt four blocks in front of you
- SPAWN: any mob, dragon included, three blocks in front of you
- TO SPAWN POINT: back to the world spawn (or the bed you last slept in)
- TO INFERNO / TO VOID / TO OVERWORLD: cross as a portal would, with a
  return portal built where you land

Like Java's commands, they leave no mark on the world or its save.

The HUD carries hearts, hunger, air bubbles, armour pips, the XP bar and the
hotbar. Mining draws crack stages on the block itself rather than a progress
bar.

## Credits

The credited texture and sound assets are CC0 (public domain), the music is
CC BY 4.0; game code is
[GPL-2.0-or-later](LICENSE). `assets/pack/CREDITS.md` has
the per-sound breakdown and the links; the short version:

- **Music** is from Mulula VGM Loops, Simple Piano Music Vol 1 (Aranha, Melodia,
  Nulo, Pianeta, Side Label, Talher), [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/),
  <https://mululavgmloops.itch.io/>. The loops are arranged into four pieces
  with crossfades and converted to XA-ADPCM; see "Music" below.
- **Block textures** are the "16x16 Block Texture Set" from OpenGameArt.
- **Sound effects** come from [Kenney](https://kenney.nl) (Impact Sounds, RPG
  Audio, Interface Sounds) and from freesound.org, where the recordings are by
  qubodup, Zozzy, sqeeeek, MBPL, OwNathan, Kneeling, Reitanna and
  swordofkings128.
- **The SDK** is [PSoXide](https://github.com/EBonura/PSoXide), which provides
  the GPU, GTE, SPU, pad, memory-card and CD layers this game is built on.

Tiles the texture pack doesn't cover (the crafting table, chest, tool icons,
crack overlays and mob faces) are drawn procedurally in `game/src/tex.rs`, and
the sound bank is cooked to SPU-ADPCM by `tools/voxide-tools` (`convert-sfx`).

## Music

The disc carries four pieces of two and a half to three minutes, streamed from
the disc by the drive as XA-ADPCM (37.8 kHz stereo, about 29 MB). They follow
Java: the title screen plays one a few seconds after it appears, the music stops
when a world loads, the first piece comes five seconds after you join, then
each piece is followed by 10 to 20 minutes of silence. The pause menu does not
stop it. MUSIC VOLUME sits next to SFX VOLUME in MUSIC & SOUNDS and, like
the other settings, reaches the memory card only with SAVE SETTINGS; at 0 nothing
plays.

The pieces are made offline from six seamless loops by `tools/loop-mixer`: a
seeded sequence of whole loops, each played one or two times, joined by 4 second
equal-power crossfades, resampled to 37.8 kHz, turned down to -16 LUFS and
dithered to 16 bits. The PS1
drive decodes one XA stream at a time, so the overlap cannot happen at run
time. `assets/music/tracks.txt` lists the pieces, the credits card lines and the
exact `loop-mixer` command and seed; `make music MUSIC_SRC=<dir of pieces>
PSX_AUDIO_COOK=<built psx-audio-cook>` cooks them into `assets/music/MUSIC1.XA`
and `game/src/musicdata.rs`, which are committed (a fresh clone and CI build the disc
from them, with no WAV). The loops themselves are not in the repo; `make music-check`
with the same arguments cooks again and fails if a single committed byte changes.
Swapping the music is a change to `tracks.txt`.

## Provenance

VoXide is developed with substantial AI assistance, with a human directing the
architecture, debugging and hardware verification. This is disclosed openly and
is **not** a clean-room claim. The same holds for the SDK underneath it; see
PSoXide's own provenance note.

## Trademark

VoXide is an original implementation inspired by Minecraft. It ships no Mojang
assets, code or data, and it is not affiliated with, endorsed by or associated
with Mojang Studios or Microsoft. Minecraft is a trademark of Mojang Studios.

## Recent changes

**0.3.2**: dying in the Inferno or the Void respawns you in the overworld,
holding L2 keeps placing blocks and holding Cross keeps hopping, saving to a
blank memory card asks before formatting it, portals draw as Java's blended
sheets, and the world builds faster, so a flowing lake no longer drags the
frame rate down.

**0.3.1**: Java's thunderstorms (lightning, thunder, storm clouds, rain,
snow or nothing by biome, a rain sound); saves keep the weather, no longer
freeze the screen and survive a card pulled mid-save; the cheats are in
OPTIONS.

**0.3.0**: Java Edition parity, round two: Java's day, weather, hunger,
attack cooldown and durability; only the pause menu pauses; mobs that see,
keep their distance and fight like Java's, tamed wolves that follow and
fight; blocks held as 3D models; saves that keep the world's seed.

**0.2.1**: the camera turns 30% faster, the crosshair picks the mob in
front of a block the way Java does, and a hidden cheat menu for testing
(now OPTIONS > CHEATS, see Cheats above).
See the [changelog](CHANGELOG.md) for the remaining changes and published download versions.
