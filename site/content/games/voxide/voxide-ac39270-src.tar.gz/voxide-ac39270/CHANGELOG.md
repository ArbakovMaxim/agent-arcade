# Changelog

## 0.4.1 | TBD

Equipment, fire and TNT, a controls card, and settings that save only when you
say so, with LOAD WORLD on the title screen, long TNT chains that finish in under
half the time, a 20 block view distance and a rendering pass.

- LOAD WORLD on the title screen, second row, loads the world saved on the
  memory card in slot 1, as Java's Singleplayer list does for a saved world.
  After SAVE AND QUIT TO TITLE it is one press instead of PLAY GAME, Start,
  LOAD WORLD. With no card in the slot, or no saved world on it, the row is
  dim and says which when the cursor is on it; X on it looks at the card again,
  so a card put in later works. A save that will not read back returns to the
  title with that reason. The six title buttons are a little shorter to fit.
- A chain of TNT settles in under half the time. Sixteen, lit by one, is done
  3.0 s after the first goes off on flat ground and 3.3 s on the spawn meadow
  (it was 7.3 s and 12.9 s); four is done in 1.5 to 2.2 s (it was 2.3 to 4 s).
  Java's is done in about 1.5 s. The blasts break exactly the blocks they did:
  a ray that can only cross air is not walked, a blast reads only the columns it
  can reach, the log of broken blocks is looked up instead of scanned, and while
  blasts wait the game takes up to two extra vblanks a frame (15 to 20 fps) for
  as long as the chain lasts. Sixteen runs 54 of 478 frames long, in one stretch
  of about 2.7 s; a single TNT is unchanged.
- The view distance is 20 blocks, up from 16. The outermost ring of chunks is
  drawn as coarse two-block tops with skirts (it already existed for distances
  above 16). On the recorded walk 38 of 1,734 frames (2.2 percent) run below 30
  fps (it was 1.2 percent at 16); the train and unseen walks 1 and 0 of 947.
  Behind that: faces wholly off the screen and far plants are dropped before the
  seal and the projection; the close-range tessellation classifies its patches
  and cells on their positions before shading them; the face cull hands its
  survivors to the packet builder once a chunk instead of once a plane (the two
  together are bigger than the instruction cache, so every hand-over refilled
  both); and a ring that is starved of streaming slices forces one only on a
  frame with room for it. Every one of these but the last draws the same
  picture as before, frame for frame.
- The dashed sky-coloured lines between terrain faces are gone. A distant floor
  plate or a terrace edge near the side of the screen is a thin slanted sliver,
  and the old seal grew it along its own length instead of sideways, so
  neighbouring faces still left a one pixel gap. Every opaque polygon now grows
  outward on its edges (by 3 pixels, 1 at the sharp end of a sliver), which
  closes the cracks the recorded walk showed on the title fly-over, on floor
  tiles and on terrace edges. About 2% of the frame.
- Distant trees are whole again. The last two blocks of the draw carried only
  the tops of faces, so a tree at the edge of the view showed as a floating
  canopy of thin leaf slivers with its trunk and sides cut away, and terraces
  ended in spikes. Sides now reach the far plane with the tops. About 4% of the
  frame.
- The PGO profile is re-collected for the new code.
- The pause menu and the settings are nested, as in Java. Start opens the GAME
  MENU (BACK TO GAME, OPTIONS..., CONTROLS, SAVE WORLD, LOAD WORLD, SAVE AND
  QUIT TO TITLE). OPTIONS... holds VIDEO SETTINGS (brightness, screen position), MUSIC & SOUNDS, STICK
  SETTINGS (look speed, invert, deadzones), GAMEPLAY (the tutorial and
  CHEATS...) and SAVE SETTINGS. The main menu's SETTINGS opens the same pages.
  Cross enters a page, left/right changes a value, Circle goes up one page,
  Start leaves, and each page remembers its row. Before, OPTIONS was one
  16-row list that scrolled, with FLIGHT in it and again on the CHEATS page;
  flight is now only FLY (NO CLIP) on CHEATS. Nothing else about saving
  changed: values still reach the card only through SAVE SETTINGS.
  SAVE AND QUIT TO TITLE is new: it saves the world, then returns to the title
  screen. A blank card asks first, and a save that fails (no card, card full,
  card removed) shows why and stays in the menu, as Java's does. PLAY GAME
  from there starts a new world; LOAD WORLD brings the saved one back.
- Music, at last (GitHub issue 1): four pieces of two and a half to three
  minutes from Mulula VGM Loops, Simple Piano Music Vol 1 (Aranha, Melodia, Nulo,
  Pianeta, Side Label, Talher), CC BY 4.0, https://mululavgmloops.itch.io/,
  arranged into pieces with crossfades. It follows Java: a piece on the title
  screen, silence while a world loads, the first piece five seconds after you
  join, then 10 to 20 minutes of silence after each piece; the pause menu does
  not stop it. The disc grows by about 29 MB. MUSIC VOLUME is a new setting
  beside SFX VOLUME (0 plays nothing) and is saved with SAVE SETTINGS like the
  rest; settings saved earlier load with it at 100. The credits card has a
  second page.
- The inventory opens on a player page, as Java's survival screen does: the
  four armour slots down the left, the player in the middle wearing what you
  put on, the off hand, your armour and defense, the weapon you swing, the
  armour you carry and the hotbar. L1 and R1 page between it and the item tabs.
- Armour is made a piece at a time at a crafting table (helmet, chestplate,
  leggings, boots, in iron or diamond) for Java's 5, 8, 7 and 4 ingots, and
  worn from the player page. Each piece keeps its own wear and takes it off
  with you, a worn piece that runs out is gone, and defense, toughness and the
  armour bar are Java's. Before, one recipe equipped a whole set at once.
- The player page has Java's 2x2 crafting grid and an output slot. Lift a
  stack with X, put it down with X, put one down or lift half with SQUARE,
  send a cell back with TRIANGLE; X on the output crafts once, TRIANGLE crafts
  as many as the cells allow. Shapes are matched wherever they sit: planks from
  a log, sticks from two planks one above the other, a crafting table from four
  planks, torches from coal over a stick, bone meal from a bone. What is in the
  grid goes back to your inventory when the screen closes.
- The SQUARE crafting list away from a table still crafts with X. It is also
  the recipe book: R2 on planks, sticks, a table, torches or bone meal lays the
  shape in the grid for you and takes you to the output. At a crafting table
  nothing changes.
- Pick the weapon you swing at mobs: fist, sword, axe, pickaxe or shovel, each
  with Java's damage and attack speed, and each wearing as Java's does (a
  sword loses one use a hit, the other tools two).
- L1 and R1 together swap the item in your hand with the off hand, as Java's
  swap-hands key does. Put an item in the off hand from the player page.
- Coal, iron, gold, diamond, sticks and the rest of what you collect now go
  on the hotbar like any other item, so a mined ore shows up where you look.
  Nothing is placed from them. Ore still drops only to the pickaxe Java asks
  for: nothing from coal by hand, nothing from iron below stone, nothing from
  gold or diamond below iron.
- The short bar under the crosshair when you started mining a block was the
  attack cooldown. Java only restarts it when a swing hits a mob or finds
  nothing, so mining no longer shows it.
- Glowstone breaks at the same speed with any tool, as in Java.
- Saves are version 12 and keep what you wear, the off hand and the weapon.
  Saves from before load wearing the armour tier they had.
- BRIGHTNESS and SCREEN X / SCREEN Y join the settings, on the main menu's
  SETTINGS page and in OPTIONS. BRIGHTNESS runs from DARKER 5 through DEFAULT to
  BRIGHTER 5 and covers the intro, the loading bars, the HUD and menus; DEFAULT
  draws exactly what it did before. SCREEN X / Y move the picture up to 16
  pixels for a television that crops the edge. All three are saved with the
  stick and volume settings; settings saved by an earlier version load with
  them at their defaults.
- Fire and TNT use Java-inspired ignition and blast rules. Flint and steel,
  adjacent fire or lava, redstone and another explosion can light TNT. Lit TNT
  becomes an entity with a four second fuse that blinks white, gets a small
  kick up, falls with gravity and explodes with power 4: rays of strength that
  blast resistance and distance wear down break the blocks they reach, a
  quarter of them drop, creatures and the player take blast damage and
  knockback (less behind cover), other lit TNT is pushed, and TNT in reach is
  lit with a fuse of half a second to a second and a half, so a stack goes off
  in a chain. Before, a lit block only vanished into a hole, and nothing but
  redstone lit it.
- Fire ages, spreads and burns out under Java-inspired rules: a flame ticks
  every 1.5 to 2 seconds, burns planks, logs, leaves, wool, grass and TNT away,
  lights flames in empty cells beside fuel, goes out in rain, dies young on
  bare ground and lives forever on netherrack. Flint and steel puts a flame
  only where one can stand. Mobs standing in fire burn.
- Explosions and flames use bounded queues and spare frame time. A blast near
  you now gets most of the frame's spare time instead of a third of it, takes
  its phases one after another in the same frame, casts its rays from a table
  and meshes the crater you can see first. One TNT's blocks are gone in about
  a tenth of a second and the crater is on screen in 0.3 to 0.6 s (it was 2 to
  3 s). A chain of four is done in 1.5 to 2.2 s and sixteen in 3 to 3.3 s (see
  the first entries above). The first frames of an explosion can run at 12
  to 20 fps. If all 32 primed TNT slots are full, TNT that cannot be lit stays in the
  world, including blocks reached by a chain blast.
- A CONTROLS card lists every button on two pages, in the world and in menus.
  It is on the main menu and in the pause menu (CONTROLS). Nothing shows it by
  itself: PLAY GAME and NEW WORLD go straight into the game. (An earlier
  0.4.0 build showed it once on the first PLAY and kept a "seen" mark in the
  settings record; that mark is no longer read or written, and cards that
  have it set or not load unchanged.)
- The inventory, the 2x2 grid, chests and furnaces share one pad grammar, the
  one Minecraft's PlayStation editions use. X takes a stack, then places it
  and swaps with what is there. SQUARE takes half, then places one. TRIANGLE
  quick-moves the stack under the cursor: to the hotbar, back to the pack,
  across to the chest or furnace, wears armour, crafts all. CIRCLE puts the
  stack in hand back, or closes when the hand is empty. A prompt bar at the
  bottom shows what each button does for the slot under the cursor and hides
  the ones that do nothing there. X used to both put a stack on a hotbar slot
  and put it back in the grid; it no longer puts anything back, CIRCLE does,
  and a hotbar slot is cleared with TRIANGLE.
- Chests and furnaces work with a stack in hand, like the inventory: X takes
  the stack, move to the other side and X places it, SQUARE takes half and
  places one (hold it to keep placing one at a time in a chest). They used
  to move one item per X, with a held X repeating.
- The crafting list's TRIANGLE crafts as many as the ingredients allow, and
  SELECT now hides what you cannot make (it was TRIANGLE), as SELECT does in
  the inventory.
- The first tutorial steps name the buttons (X crafts in the crafting list)
  and the last one points at CONTROLS.
- Settings are saved only by SAVE SETTINGS, a new last row on the main menu's
  SETTINGS page and in OPTIONS. Adjusting a setting, leaving the page and
  change the game until you power off and write nothing to the memory card.
  SAVE SETTINGS keeps the stick, volume, brightness and screen position
  settings. Before, closing the page or the first PLAY wrote the card on its
  own. On a blank
  card the first SAVE SETTINGS asks and the second formats it, as the world's
  SAVE WORLD does.
- A zombie, spider or other melee mob in reach now hits once a second, as in
  Java. Before, it hit every half second, as soon as your own half second of
  invulnerability ended, so one zombie took 3 hearts a second instead of 1.5.
  Skeleton arrows, sapper blasts and every damage value are
  unchanged. Hunger already matched Java and is unchanged. See AUDIT.md.
- The hint line under the SETTINGS list is drawn in dark ink. It was nearly
  invisible on the grey panel.
- Saves written by 0.4.0 are version 12 and do not load in 0.3.2 or earlier.
  Saves from 0.3.2 and earlier load in 0.4.0.

## 0.3.2 | 2026-10-08

Portals, controls and world speed fixes, on top of 0.3.1.

- Dying in the Inferno or the Void now sends you back to the overworld, as in
  Java. Before, you came back at the overworld spawn's coordinates inside the
  dimension you died in.
- Holding L2 keeps placing blocks, one every four game ticks, so a row or a
  pillar goes up with the button held, as with Java's use button.
- Holding Cross jumps again as soon as you land, ten game ticks apart, as in
  Java. Before, each jump needed a fresh press.
- Saving to a memory card with no directory asks first: the first save says
  the card will be formatted and the second does it. Before, it erased
  whatever the card held at once.
- The tutorial hint box in the Void is drawn below the dragon's boss bar
  instead of over its title.
- Portals: each sheet is drawn as the two blended faces of Java's portal model,
  cut to the frame and animated, instead of two opaque quads that poked
  through the obsidian and vanished up close and far away. The Void portal is
  a sheet you can walk through, like the Nether portal. Standing in a portal
  tints the screen purple, and the crosshair reaches the block behind a sheet.
- Faster world: meshing a chunk no longer scans every cell for skylight,
  lights and plants, and a spreading fluid rebuilds only the planes it
  touches, so a flowing lake or lava stream no longer drags the frame rate
  down.
- Newer PSoXide SDK, engine and emulator components, with the build profile
  collected again for them.

## 0.3.1 | 2026-10-02

Standalone disc published on itch.io.

Thunderstorms, saves and the cheats page.

- Java's thunderstorms: lightning bolts drawn Java's way, a flash on the
  sky and the world, thunder heard everywhere, the crack within 32 blocks,
  darker storm clouds. Strikes come at Java's rate (about 2.4 a minute
  within 128 blocks), land on the highest block or on a creature that sees
  the sky, set fire around them, deal 5 damage, burn up dropped items and
  charge sappers (twice the blast).
- Rain and thunder levels and the sky light follow Java's formulas, so a
  shower darkens the world as it rolls in; rain puts fires out.
- Rain, snow or nothing by biome as in Java: deserts stay dry under a
  storm sky, cold and high ground gets snow. Rain has a sound (muffled
  under a roof); thunder comes from the strike's side. The distant haze
  darkens with the storm instead of staying sand-coloured.
- Saves keep the weather (format 11). A save writes one card frame per
  game frame with a progress bar instead of freezing the screen, and is
  written beside the previous save, so pulling the card mid-save keeps
  the old one. Older saves still load.
- The cheats are a CHEATS page in OPTIONS (the hidden combo is gone),
  with WEATHER: clear, rain, thunder or a lightning bolt. Using them no
  longer marks the world, as in Java.

## 0.3.0 | 2026-10-01

Standalone disc published on itch.io.

Java Edition parity, round two, and a review round.

- The world runs on Java's clocks: a 20-minute day, Java's weather (now
  with thunderstorms), crops and saplings on random ticks, 10 s smelting,
  a 4 s TNT fuse and portal.
- Java's day and night: sky light steps down at dusk and up at dawn by
  Java's table (darker in rain, darker still in a storm) while the screen
  fades smoothly; the sun and moon follow Java's eased arc, crossing the
  horizon at 12,786 and 23,216, with the sunset glow centred there.
  Monsters spawn outdoors from 13,188 to 22,812 in clear weather and by
  day in a thunderstorm; beds work and the undead burn on Java's ticks.
- Java's hunger (exhaustion and saturation), 1.9 attack cooldown, crits,
  and durability for tools, armour, the bow, the rod and flint and steel.
- Only the pause menu pauses the world; inventory and containers do not.
- Mobs see before they hunt and stop at touching distance; skeletons keep
  their range and shoot to 15 blocks; creepers (sappers) fuse within 3
  blocks; tamed wolves follow, fight for you, persist and are saved.
- Blocks are held as their 3D models, items as flat icons in the fist.
- The sun and moon are Java's size; the sun has its halo and sets behind
  the horizon.
- Sprinting needs food above 6; sink sand slows you; ladders climb when
  you push against them; you can attack and build underwater.
- Saves keep the world's seed, respawn point, day and tamed wolves, and a
  load rebuilds the world (it kept blocks placed after the save).
- Fixes: ladders no longer cause fall damage; burning or drowning no
  longer makes you immune to mobs; embers and wailers hover instead of
  rising forever; farms keep growing; held buttons in the furnace and
  crafting no longer roll onto the next item; L2 acts on the mob under
  the crosshair; an exploding sapper drops nothing; a sapper blast stalls
  the game half as long.

## 0.2.1 | 2026-09-26

Standalone disc published on itch.io.


- The right stick turns 30% faster: a full push is 117 degrees a second of
  yaw and 98 of pitch at LOOK SPEED 100% (was 90 and 75).
- Mobs take the crosshair. A mob between you and a block is targeted, as in
  Java: the block outline and break cracks no longer land on the block
  behind or under it, R2 strikes that mob (damage and knockback), and
  holding R2 no longer mines through it. Hitboxes use Java's widths (pig,
  cow and sheep 0.9 blocks, chicken 0.4, spider 1.4) and reach up to each
  model's drawn height.
- A hidden cheat menu for testing: from OPTIONS, hold L1 + R1 and press
  Select. Flight, god mode, a coordinates and FPS readout, a full
  inventory, time of day, spawning any mob, back to spawn, and travel to the
  Inferno, the Void or the overworld. Using one marks the world's save;
  saves from worlds that never do are unchanged.

## 0.2.0 | 2026-09-26

Standalone disc published on itch.io.


- Gameplay follows Minecraft Java Edition's numbers: walking, sprinting, sneaking,
  jumping and swimming, block break times, combat and explosions, burning, healing
  and hunger, mob spawning by light level, day length, fluids, fishing, experience,
  breeding and taming. All game time runs on one 60 Hz clock.
- The inventory is an icon grid with the hotbar as its last row; chests and
  furnaces open as two panes and move whole stacks.
- Saves keep chests, furnaces, the hotbar, enchant levels, the food pouch, the
  current dimension, return portals and the Void's dragon. Older saves load.

## Source 2026.09.05

This source snapshot is tagged `source-2026.09.05`. Download versions are
listed separately below; source cleanup does not replace an already published disc.

- Switched standalone builds to the extracted SDK and separate emulator.
- Removed unused terrain helpers and formatted Rust sources.

## 0.1.11-split.20260905 | 2026-09-05

Standalone disc published on itch.io.

- Published the SDK split build of VoXide 0.1.11.

