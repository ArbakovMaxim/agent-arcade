//! Cuboid mobs: passive (pig/cow/sheep/chicken) and hostile (zombie/skeleton/
//! sapper/spider). Fixed-point FSM AI (idle/wander/chase/flee), greedy axis-step
//! toward the player with a jump when blocked (no A*), gravity + AABB collision
//! reused from the player. Capped and despawned by distance to protect fps.
//! Rendering lives in `main` (flat cuboid boxes inserted into the OT).

use crate::{
    aabb_collides_dims, world, world_to_block_x, world_to_block_y, world_to_block_z, BLOCK, GRASS,
    PLAYER_HALF_W, PLAYER_HEIGHT,
};
use psx_fx::rng::LcgRng;
use psx_math::sincos;

pub const CAP: usize = 8;

pub const PIG: u8 = 0;
pub const COW: u8 = 1;
pub const SHEEP: u8 = 2;
pub const CHICKEN: u8 = 3;
pub const ZOMBIE: u8 = 4;
pub const SKELETON: u8 = 5;
pub const SAPPER: u8 = 6;
pub const SPIDER: u8 = 7;
/// The void dragon. Flies (no gravity, no block collision -- it phases through
/// the pillars the way Java's does), circles the island, and dives at you.
/// Spawned by the world when you arrive in the Void, never by the spawn timer.
pub const DRAGON: u8 = 8;
/// Neutral until you hit it, then it comes for you; blinks away when hurt.
pub const WRAITH: u8 = 9;
/// Passive; feed it a bone to tame it and it follows you and fights for you.
pub const WOLF: u8 = 10;
/// Passive; trade with it (R3) rather than kill it.
pub const VILLAGER: u8 = 11;
// Inferno natives. They exist in Java to gate the brewing ingredients, which is
// exactly what they do here: ember rods, wailer tears and magma paste.
pub const EMBER: u8 = 12; // hovers, hostile
pub const WAILER: u8 = 13; // large, hovers high
pub const CHARRED_SK: u8 = 14; // walks, hostile

/// Hostile = hunts you on sight. Wraiths are NEUTRAL (they only retaliate),
/// and wolves and villagers never do, so the plain `kind >= ZOMBIE` test that
/// worked while spider was the last kind no longer holds.
#[inline]
pub fn is_hostile(kind: u8) -> bool {
    (kind >= ZOMBIE && kind <= DRAGON) || kind == WRAITH || kind >= EMBER
}

/// Standing between strolls. Zero, so a dead slot stays all-zero and MOBS
/// stays in .bss.
const ST_IDLE: u8 = 0;
const ST_CHASE: u8 = 1;
const ST_FLEE: u8 = 2;
/// Walking a stroll: `heading` for `timer` more ticks.
const ST_WANDER: u8 = 3;

// Every per-tick number in this file is per SIM tick, the one game clock
// (units.rs): main steps the sim once per elapsed vblank, so a tick is 1/60 s
// whatever the frame rate. Speeds are written in blocks per second and
// durations in seconds, converted through units.rs at compile time.
use crate::units::{cbps_q8 as q8, java_ticks, ms, secs};

/// Ground speed, Q8 units/tick: Java's movement_speed attribute per mob. A
/// Java mob steers with that speed as both its input and its gain, so on
/// ground friction (0.546) it settles at s*s/0.454 blocks per game tick, about
/// 44*s^2 blocks per second; the same model with the player's 0.98 input and
/// 0.1 speed gives the wiki's 4.317 walk. Kinds with no ground-walking Java
/// counterpart keep the old intended speed, 5 units per 30 Hz frame (2.34).
fn walk_q8(kind: u8) -> i32 {
    match kind {
        COW => q8(176),                                            // 0.20
        SHEEP | ZOMBIE => q8(233),                                 // 0.23
        SPIDER | WOLF | WRAITH => q8(396),                         // 0.30 (wraith: the enderman)
        PIG | CHICKEN | SKELETON | SAPPER | CHARRED_SK => q8(275), // 0.25
        _ => q8(234),                                              // villager, ember, wailer
    }
}

/// Fleeing: Java's panic goal runs at 1.25x the attribute, and the settled
/// speed goes with its square.
fn flee_q8(kind: u8) -> i32 {
    walk_q8(kind) * 25 / 16
}

/// A standing mob sets off on a stroll with this 1-in-N chance per tick: a
/// mean pause of 6 s, Java's 1-in-120 per 20 Hz tick.
const IDLE_ROLL: u32 = secs(6) as u32;
/// Stroll length in blocks, like Java's random target within ten.
const STROLL_MIN: i32 = 2;
const STROLL_MAX: i32 = 10;
/// Mob gravity and jump: the old 30 Hz values (GRAVITY 4, JUMP_VY 28)
/// converted to 60 Hz, a quarter the acceleration and half the impulse, so a
/// hop reaches the same 1.5 blocks in the same 0.23 s it was written for.
const MOB_GRAVITY: i32 = 1;
const MOB_JUMP_VY: i32 = 14;
const MOB_TERMINAL_VY: i32 = -28;
/// Spiders climb walls toward you at about 2.8 blocks/s (3 units a tick net
/// of gravity).
const SPIDER_CLIMB_VY: i32 = MOB_GRAVITY + 3;
/// After a hit a mob is invulnerable, and flashes red, for 10 game ticks
/// (minecraft.wiki/w/Damage#Invulnerability timer, #Effects).
const HURT_TICKS: u8 = java_ticks(10) as u8;
const FLASH_TICKS: u8 = HURT_TICKS;
/// Skeleton bow: draw for a second after spotting you, then a shot every 3 s
/// (Easy/Normal, minecraft.wiki/w/Skeleton).
const SHOT_DRAW: u16 = secs(1) as u16;
const SHOT_TICKS: u16 = secs(3) as u16;
/// Hit animals run for 3 s.
const FLEE_TICKS: u16 = secs(3) as u16;
/// The dragon's per-axis speed, 5 units per 30 Hz frame per axis as written
/// (4.7 blocks/s on an axis), Q8 units/tick.
const DRAGON_Q8: i32 = q8(469);
/// Melee knockback, units (one shove per hit, not per tick).
const KNOCKBACK: i32 = 15;
const CHASE_R: i32 = 12 * BLOCK; // aggro radius of kinds without a Java value here
const LOSE_R: i32 = 18 * BLOCK; // give-up radius for those
/// Java's follow ranges: zombies pursue from 35 blocks (minecraft.wiki/w/
/// Zombie), skeletons 16 (/w/Skeleton), creepers 16 (/w/Creeper). Mobs
/// despawn past DESPAWN_R, the edge of the streamed ring, so a zombie hunts
/// from 28 blocks here (PS1 limit: the 30-block ring).
fn follow_r(kind: u8) -> i32 {
    match kind {
        ZOMBIE => 28 * BLOCK,
        SKELETON | SAPPER => 16 * BLOCK,
        _ => CHASE_R,
    }
}
fn lose_r(kind: u8) -> i32 {
    match kind {
        ZOMBIE | SKELETON | SAPPER => follow_r(kind) + 2 * BLOCK,
        _ => LOSE_R,
    }
}
/// Skeletons shoot within 15 blocks with a clear line of sight and back off
/// inside 4 (minecraft.wiki/w/Skeleton).
const SHOOT_R: i32 = 15 * BLOCK;
const RETREAT_R: i32 = 4 * BLOCK;
/// A creeper lights its fuse within 3 blocks and gives up past 7 or out of
/// sight (minecraft.wiki/w/Creeper).
const FUSE_START_R: i32 = 3 * BLOCK;
const FUSE_KEEP_R: i32 = 7 * BLOCK;
/// Tamed wolves (minecraft.wiki/w/Wolf): follow past 10 blocks, teleport past
/// 12 (16 while fighting), bite for 4.
const WOLF_FOLLOW_R: i32 = 10 * BLOCK;
const WOLF_STOP_R: i32 = 2 * BLOCK;
const WOLF_TELEPORT_R: i32 = 12 * BLOCK;
const WOLF_TELEPORT_FIGHT_R: i32 = 16 * BLOCK;
const WOLF_BITE: i16 = 4;
const TEMPT_STOP: i32 = 5 * BLOCK / 2;
/// Java's melee goal strikes every 20 game ticks (its MeleeAttackGoal; the
/// wiki gives no figure).
const WOLF_BITE_TICKS: u16 = java_ticks(20) as u16;
/// A hostile's melee goal swings at most once every 20 game ticks (1 s), so a
/// mob touching the player hits once a second whatever the player's own
/// 10-tick invulnerability does. The same interval as WOLF_BITE_TICKS; the
/// figure is Java's `MeleeAttackGoal` (the wiki gives none for zombies, see
/// AUDIT.md).
const MELEE_TICKS: u8 = java_ticks(20) as u8;
/// Tamed wolves kept off the mob pool: in another dimension, or left behind
/// outside the loaded ring (Java's unloaded chunk). Saved with the world.
pub const TAMED_CAP: usize = 4;
#[derive(Copy, Clone)]
pub struct Parked {
    pub used: bool,
    pub dim: u8,
    pub x: i32,
    pub y: i32,
    pub z: i32,
    pub hp: i16,
}
pub const NO_PARKED: Parked = Parked {
    used: false,
    dim: 0,
    x: 0,
    y: 0,
    z: 0,
    hp: 0,
};
static mut PARKED: [Parked; TAMED_CAP] = [NO_PARKED; TAMED_CAP];
/// The mob tamed wolves go for: the last one the player hit or that hurt the
/// player, or a skeleton near the pack. CAP = none.
static mut PACK_TGT: usize = CAP;
/// Per-slot line of sight to the player, refreshed every 10 ticks.
static mut SIGHT: [bool; CAP] = [false; CAP];
const LURE_R: i32 = 8 * BLOCK; // passive-animal follow radius when luring with wheat
const DESPAWN_R: i32 = 30 * BLOCK;
const SPAWN_MIN: i32 = 8 * BLOCK;
const SPAWN_MAX: i32 = 14 * BLOCK;

#[derive(Copy, Clone)]
struct Mob {
    kind: u8,
    alive: bool,
    on_ground: bool,
    x: i32,
    y: i32, // feet
    z: i32,
    vy: i32,
    health: i16,
    state: u8,
    timer: u16, // wander/flee countdown, or skeleton shoot cooldown
    fuse: u16,  // sapper detonation charge
    hurt_cd: u8,
    /// Sim ticks until a melee mob can strike again (Java's attack interval).
    atk: u8,
    love: u16, // breeding "in love" countdown (passive mobs, set by feeding wheat)
    cool: u16, // sim ticks before this animal can fall in love again after breeding
    /// Gait phase, advanced only while actually moving, so legs stop when the
    /// mob stops. Java drives limb swing off distance travelled for the same
    /// reason -- a timer-driven swing marches on the spot.
    walk: u8,
    /// Which way the body points: 0 +Z, 1 +X, 2 -Z, 3 -X, the nearest quarter
    /// turn to the way it moves, so the renderer can put the face on the
    /// correct side.
    facing: u8,
    /// Stroll direction, 256 to the turn, 0 = +Z, 64 = +X.
    heading: u8,
    /// Sim ticks left alight (lightning sets 8 s; rain and water put it out).
    fire: u16,
    /// A sapper struck by lightning: Java's charged creeper, blast power 6.
    charged: bool,
}

const DEAD: Mob = Mob {
    kind: 0,
    alive: false,
    on_ground: false,
    x: 0,
    y: 0,
    z: 0,
    vy: 0,
    health: 0,
    state: ST_IDLE,
    timer: 0,
    fuse: 0,
    hurt_cd: 0,
    atk: 0,
    love: 0,
            cool: 0,
    walk: 0,
    facing: 0,
    heading: 0,
    fire: 0,
    charged: false,
};

// Arrows fired by skeletons.
const ARROW_CAP: usize = 8;
/// Skeleton arrows fly like every arrow, on the bow's gravity and drag
/// (minecraft.wiki/w/Arrow). The launch speed is not on the wiki: Java's
/// skeleton shoots at 1.6 blocks a game tick (32 blocks/s), aimed above the
/// target by a fifth of the horizontal distance to carry it there. They used
/// to fly 26 units a tick on a Manhattan-normalised aim with a steep drop, and
/// fell short past about 5 blocks.
const SKEL_Q8: i32 = crate::units::cbps_q8(3200);
/// Player arrows, Java's bow at full draw: 3 blocks a game tick (60 blocks/s,
/// a block a sim tick), gravity 0.05 blocks/tick^2 and 0.99 drag a game tick
/// (minecraft.wiki/w/Arrow), spread over three sim ticks: 91/256 of a unit a
/// tick per tick, and 1 - 55/16384 of the velocity kept each tick.
const BOW_Q8: i32 = crate::units::cbps_q8(6000);
const BOW_GRAVITY: i32 = 91;
const BOW_DRAG_16384: i32 = 55;
/// Breeding (minecraft.wiki/w/Breeding#Love mode): love mode lasts 30 s and a
/// parent cannot breed again for 5 minutes.
const LOVE_TICKS: u16 = secs(30) as u16;
const BREED_COOLDOWN: u16 = secs(300) as u16;
/// A tamed wolf's health, 40 (minecraft.wiki/w/Wolf); a wild one has 8.
const TAMED_WOLF_HEALTH: i16 = 40;
/// Arrows vanish after 1.5 s in flight.
const ARROW_LIFE: u16 = ms(1500) as u16;
/// Idle voices: each mob mutters every ~7 s.
const VOICE_PERIOD: usize = ms(7133) as usize;
/// Undead in daylight lose 1 hp every second.
const SUN_BURN_PERIOD: u16 = secs(1) as u16; // burning: 1 hp a second (Damage#Burning)
const FUSE_MAX: u16 = java_ticks(30) as u16; // Java's 30-game-tick (1.5 s) sapper fuse
/// The sapper's blast: explosion power 3, the creeper's (minecraft.wiki/w/Creeper).
const SAPPER_POWER: i32 = 3;
/// Height the dragon cruises at, above the Void island's deck.
const DRAGON_CRUISE: i32 = 42 * BLOCK;
/// The dragon never stops hunting, so it needs its own reach rather than the
/// shared aggro radius.
const DRAGON_CHASE_R: i32 = 80 * BLOCK;
/// Standoff radius: it circles at this range rather than closing to nothing.
const DRAGON_ORBIT: i32 = 9 * BLOCK;

#[derive(Copy, Clone)]
struct Arrow {
    alive: bool,
    // Position and velocity in Q8 world units (a tick).
    x: i32,
    y: i32,
    z: i32,
    vx: i32,
    vy: i32,
    vz: i32,
    life: u16,
    from_player: bool, // player arrows hit mobs; skeleton arrows hit the player
}

const NO_ARROW: Arrow = Arrow {
    alive: false,
    x: 0,
    y: 0,
    z: 0,
    vx: 0,
    vy: 0,
    vz: 0,
    life: 0,
    from_player: false,
};

static mut MOBS: [Mob; CAP] = [DEAD; CAP];
static mut ARROWS: [Arrow; ARROW_CAP] = [NO_ARROW; ARROW_CAP];
static mut HAZARD_DMG: i32 = 0; // arrow hits + blast damage to the player this frame
static mut SPAWN_TIMER: u16 = secs(2) as u16;
static mut RNG: LcgRng = LcgRng::new(0x1234_5678);
static mut XP_DROPS: u16 = 0; // experience from kills, drained by main

// Kills this frame, for main to turn into item entities. This used to be four
// running counters (meat/wool/bones/powder) that main added straight to the
// inventory, so loot teleported off the corpse from anywhere on the map.
// Logging the position instead lets it fall where the mob died. Which items a
// kind yields stays main's business: mob.rs has no idea what RAW_MEAT is.
const DEATH_CAP: usize = 8;
static mut DEATH_X: [i32; DEATH_CAP] = [0; DEATH_CAP];
static mut DEATH_Y: [i32; DEATH_CAP] = [0; DEATH_CAP];
static mut DEATH_Z: [i32; DEATH_CAP] = [0; DEATH_CAP];
static mut DEATH_KIND: [u8; DEATH_CAP] = [0; DEATH_CAP];
static mut DEATH_N: usize = 0;
/// Set when the void dragon dies, for good: it is a one-time boss, and the
/// save carries this so a defeated dragon stays gone.
static mut DRAGON_SLAIN: bool = false;

fn record_death(m: &Mob) {
    unsafe {
        if m.kind == DRAGON {
            DRAGON_SLAIN = true;
        }
        if DEATH_N >= DEATH_CAP {
            return; // eight kills in one frame is already a sapper blast
        }
        DEATH_X[DEATH_N] = m.x;
        DEATH_Y[DEATH_N] = m.y;
        DEATH_Z[DEATH_N] = m.z;
        DEATH_KIND[DEATH_N] = m.kind;
        DEATH_N += 1;
    }
}

/// Kills logged since the last drain.
pub fn death_count() -> usize {
    unsafe { DEATH_N }
}

/// `(x, y, z, kind)` of logged kill `i`.
pub fn death_at(i: usize) -> (i32, i32, i32, u8) {
    unsafe { (DEATH_X[i], DEATH_Y[i], DEATH_Z[i], DEATH_KIND[i]) }
}

pub fn clear_deaths() {
    unsafe {
        DEATH_N = 0;
    }
}
static mut LURE: u8 = 0; // the item the player holds (animals follow their food)

/// Take and clear accumulated XP from kills this frame.
pub fn take_xp() -> u16 {
    unsafe {
        let d = XP_DROPS;
        XP_DROPS = 0;
        d
    }
}

/// Set each frame: passive animals follow the player while this is true.
pub fn set_lure(item: u8) {
    unsafe {
        LURE = item;
    }
}

/// What tempts and breeds each animal (minecraft.wiki/w/Breeding): cows and
/// sheep wheat, chickens seeds. Pigs take carrots in Java; with no carrots
/// here they keep wheat. Villagers are not fed by hand.
fn eats(kind: u8, item: u8) -> bool {
    match kind {
        COW | SHEEP | PIG => item == crate::WHEAT_ITEM,
        CHICKEN => item == crate::SEEDS,
        _ => false,
    }
}

#[inline]
fn rng() -> u32 {
    // The fold this used to do by hand lives on the generator now: callers
    // here lean on the low bits (& 1, % 4, % 120) and a raw LCG's cycle with
    // tiny periods.
    unsafe { RNG.next_mixed() }
}

/// (half-width, height) in world units per kind.
pub fn dims(kind: u8) -> (i32, i32) {
    match kind {
        // Boss scale: half-width 2.5 blocks and 1.75 tall, and render_dragon
        // reaches out to 2*hw for the wings, so it spans ~10 blocks tip to tip.
        DRAGON => (160, 112),
        WRAITH => (14, 116), // Java's tall, thin silhouette
        EMBER => (16, 56),
        WAILER => (56, 56), // Java's is enormous; this is as big as the pool allows
        CHARRED_SK => (14, 96),
        WOLF => (14, 46),
        VILLAGER => (16, 80),
        CHICKEN => (12, 40),
        SPIDER => (28, 36),
        PIG | SHEEP => (16, 56),
        COW => (18, 70),
        _ => (16, 80), // zombie/skeleton/sapper, ~human
    }
}

#[inline]
pub fn is_flyer(kind: u8) -> bool {
    kind == DRAGON || kind == EMBER || kind == WAILER
}

fn max_health(kind: u8) -> i16 {
    // Java Edition HP (2 HP = 1 heart). minecraft.wiki per-mob pages.
    match kind {
        CHICKEN => 4,
        SHEEP => 8,
        PIG | COW => 10,
        SPIDER => 16,
        ZOMBIE | SKELETON | SAPPER => 20,
        DRAGON => 200, // Java's boss pool, and it takes a while
        WRAITH => 40,
        EMBER => 20,
        WAILER => 10, // Java: papery, dies in one good hit
        CHARRED_SK => 20,
        WOLF => 8, // wild; 40 once tamed (TAMED_WOLF_HEALTH)
        VILLAGER => 20,
        _ => 16,
    }
}

#[derive(Copy, Clone)]
pub struct MobView {
    pub kind: u8,
    pub alive: bool,
    pub x: i32,
    pub y: i32,
    pub z: i32,
    pub priming: bool, // sapper with a lit fuse (renderer flashes it white)
    /// Gait phase 0..255, for the leg swing.
    pub walk: u8,
    /// Body facing: 0 +Z, 1 +X, 2 -Z, 3 -X.
    pub facing: u8,
    /// Struck within the last few frames -- the renderer flashes it red.
    pub hurt: bool,
    /// A charged sapper, blinking its blue aura on (every 0.15 s).
    pub charged: bool,
}

pub fn get(i: usize) -> MobView {
    let m = unsafe { MOBS[i] };
    MobView {
        kind: m.kind,
        alive: m.alive,
        x: m.x,
        y: m.y,
        z: m.z,
        // Flash on/off every 0.1 s while the fuse burns.
        priming: m.kind == SAPPER && m.fuse > 0 && (unsafe { BURN_TICK } / ms(100) as u16) % 2 == 0,
        walk: m.walk,
        facing: m.facing,
        // hurt_cd was set on every hit and decremented every frame and then read
        // by nothing at all -- a dead field. It is the damage flash now.
        hurt: m.hurt_cd > HURT_TICKS - FLASH_TICKS,
        charged: m.charged && (unsafe { BURN_TICK } / ms(150) as u16) % 2 == 0,
    }
}

fn count_alive() -> usize {
    let mut c = 0;
    let mut i = 0;
    while i < CAP {
        if unsafe { MOBS[i].alive } {
            c += 1;
        }
        i += 1;
    }
    c
}

/// Alive mobs that are hostile (true) or not (false).
fn count_kind(hostile: bool) -> usize {
    let mut c = 0;
    let mut i = 0;
    while i < CAP {
        let m = unsafe { MOBS[i] };
        if m.alive && is_hostile(m.kind) == hostile {
            c += 1;
        }
        i += 1;
    }
    c
}

/// The 8 slots split evenly between the categories. Java caps them apart
/// (70 monsters, 10 animals, minecraft.wiki/w/Mob spawning); sharing one pool
/// let daytime animals fill every slot, so no cave could ever spawn.
const MONSTER_CAP: usize = CAP / 2;
const ANIMAL_CAP: usize = CAP / 2;

fn free_slot() -> Option<usize> {
    let mut i = 0;
    while i < CAP {
        if !unsafe { MOBS[i].alive } {
            unsafe {
                KICK_X[i] = 0;
                KICK_Z[i] = 0;
            }
            return Some(i);
        }
        i += 1;
    }
    None
}

/// Spawn attempts alternate between a monster and an animal, Java's two
/// spawn categories.
static mut SPAWN_MONSTER: bool = false;

/// One spawn attempt at a random column 8 to 14 blocks out, by Java's light
/// rules (minecraft.wiki/w/Mob spawning, light levels): an Overworld monster
/// needs block light 0 and internal sky light 7 or less, and then a light
/// level no higher than a roll of 0 to 7 -- so the surface at night and any
/// dark cave by day or night, never beside a torch. An animal needs a grass
/// block with light 9 or more (#Passive mobs). In the Inferno a monster needs
/// block light 11 or less, in the Void block light 0. `sky` is the internal
/// sky light where the sky is open, 4 at midnight to 15 at noon.
fn try_spawn(px: i32, pz: i32, sky: i32) {
    let s = match free_slot() {
        Some(s) => s,
        None => return,
    };
    // A random point in the ring SPAWN_MIN..SPAWN_MAX around the player. It
    // used to draw both offsets from 8..14 blocks, four diagonal squares that
    // never put a mob anywhere near either axis.
    let span = (2 * SPAWN_MAX + 1) as u32;
    let mut k = 0;
    let (sx, sz) = loop {
        if k >= 4 {
            return;
        }
        let r = rng();
        let dx = (r % span) as i32 - SPAWN_MAX;
        let dz = ((r >> 12) % span) as i32 - SPAWN_MAX;
        let d2 = dx * dx + dz * dz;
        if d2 >= SPAWN_MIN * SPAWN_MIN && d2 <= SPAWN_MAX * SPAWN_MAX {
            break (px + dx, pz + dz);
        }
        k += 1;
    };
    let bx = world_to_block_x(sx);
    let bz = world_to_block_z(sz);
    let top = world::surface_y(bx, bz);
    if top < 2 || top > 100 {
        return;
    }
    let monster = unsafe {
        SPAWN_MONSTER = !SPAWN_MONSTER;
        SPAWN_MONSTER
    };
    if count_kind(monster) >= if monster { MONSTER_CAP } else { ANIMAL_CAP } {
        return;
    }
    let dim = world::dimension();
    let mut sy = top;
    let kind = if dim == world::DIM_VOID {
        if !monster || crate::block_light(bx, sy, bz) > 0 {
            return;
        }
        WRAITH // the End's own mob, and the only one that spawns there
    } else if dim == world::DIM_INFERNO {
        if !monster || crate::block_light(bx, sy, bz) > 11 {
            return;
        }
        match rng() % 3 {
            0 => EMBER,
            1 => WAILER,
            _ => CHARRED_SK,
        }
    } else if monster {
        // Half the attempts try a cave cell under the column: pick a height
        // and walk down to a floor with two clear cells above it.
        if rng() & 1 == 0 {
            let mut y = 1 + (rng() % (top - 1) as u32) as i32;
            let mut k = 0;
            loop {
                if k >= 16 || y < 1 {
                    return;
                }
                if world::get(bx, y, bz) == crate::AIR
                    && world::get(bx, y + 1, bz) == crate::AIR
                    && solid(bx * BLOCK, (y - 1) * BLOCK, bz * BLOCK)
                {
                    break;
                }
                y -= 1;
                k += 1;
            }
            sy = y;
        }
        let open = if sy >= top { sky } else { 0 };
        let block = crate::block_light(bx, sy, bz);
        if open > 7 || block > 0 || open.max(block) > (rng() % 8) as i32 {
            return;
        }
        // One in eight is a wraith, as endermen are in Java's overworld.
        if rng() % 8 == 0 {
            WRAITH
        } else {
            ZOMBIE + (rng() % 4) as u8
        }
    } else {
        // Animals need light 9, but under open sky that is the raw sky light,
        // 15 day or night (minecraft.wiki/w/Light#Mobs): Java spawns them at
        // night too. Only a covered cell needs block light.
        let open = if sy >= top { 15 } else { 0 };
        if world::get(bx, sy - 1, bz) != GRASS || open.max(crate::block_light(bx, sy, bz)) < 9 {
            return;
        }
        // Wolves and villagers share the roll with the farm animals.
        match rng() % 6 {
            4 => WOLF,
            5 => VILLAGER,
            r => r as u8,
        }
    };
    let (hw, h) = dims(kind);
    let feet = sy * BLOCK;
    if aabb_collides_dims(sx, feet, sz, hw, h) {
        return; // spawn point blocked
    }
    unsafe {
        MOBS[s] = Mob {
            kind,
            alive: true,
            on_ground: false,
            x: sx,
            y: feet,
            z: sz,
            vy: 0,
            health: max_health(kind),
            state: ST_IDLE,
            timer: 0,
            fuse: 0,
            hurt_cd: 0,
            atk: 0,
            love: 0,
            cool: 0,
            walk: 0,
            facing: 0,
            heading: 0,
            fire: 0,
            charged: false,
        };
    }
}

/// Put the void dragon in the air over the Void island. Called by the world
/// when the player arrives, not by the spawn timer: it is a boss, and there is
/// exactly one.
pub fn spawn_dragon(px: i32, pz: i32) {
    let s = match free_slot() {
        Some(s) => s,
        None => return,
    };
    unsafe {
        MOBS[s] = Mob {
            kind: DRAGON,
            alive: true,
            on_ground: false,
            x: px + 18 * BLOCK,
            y: DRAGON_CRUISE,
            z: pz + 18 * BLOCK,
            vy: 0,
            health: max_health(DRAGON),
            state: ST_CHASE,
            timer: 0,
            fuse: 0,
            hurt_cd: 0,
            atk: 0,
            love: 0,
            cool: 0,
            walk: 0,
            facing: 0,
            heading: 0,
            fire: 0,
            charged: false,
        };
    }
}

/// True once the dragon has been killed in this world.
pub fn dragon_slain() -> bool {
    unsafe { DRAGON_SLAIN }
}

pub fn set_dragon_slain(slain: bool) {
    unsafe { DRAGON_SLAIN = slain };
}

/// Put the Void's boss in the state arriving there calls for: one dragon in
/// the air unless it has been slain. Anywhere else, no dragon: it never
/// despawns by distance, so without this it followed you home through the
/// portal, and every return to the Void added another.
pub fn settle_dragon(in_void: bool, px: i32, pz: i32) {
    let alive = dragon_status().is_some();
    if in_void && !alive && !dragon_slain() {
        spawn_dragon(px, pz);
    } else if !in_void && alive {
        let mut i = 0;
        while i < CAP {
            unsafe {
                if MOBS[i].alive && MOBS[i].kind == DRAGON {
                    MOBS[i] = DEAD;
                }
            }
            i += 1;
        }
    }
}

/// Fixture builds: kill the dragon the way a last hit does.
#[cfg(feature = "ui-fixture")]
pub fn slay_dragon() {
    let mut i = 0;
    while i < CAP {
        let m = unsafe { MOBS[i] };
        if m.alive && m.kind == DRAGON {
            record_death(&m);
            unsafe { MOBS[i] = DEAD };
        }
        i += 1;
    }
}

/// Interact with mob slot `i`, the one under the crosshair: feed a wolf a bone
/// to tame it, or trade with a villager. Returns what the player should be
/// charged and given, or None if that mob takes nothing.
///
/// `love == u16::MAX` marks a tamed wolf. It reuses the breeding field because a
/// tamed wolf never breeds, and a whole extra byte per mob for one flag is not
/// worth it on this machine.
pub fn interact(i: usize, has_bone: bool, wheat: u16) -> Interact {
    if i >= CAP {
        return Interact::None;
    }
    let mut m = unsafe { MOBS[i] };
    if m.alive {
        if m.kind == WOLF && m.love != u16::MAX && has_bone {
            m.love = u16::MAX;
            m.health = TAMED_WOLF_HEALTH;
            unsafe { MOBS[i] = m };
            return Interact::Tamed;
        }
        if m.kind == VILLAGER && wheat >= 8 {
            return Interact::Traded;
        }
    }
    Interact::None
}

pub enum Interact {
    None,
    Tamed,
    Traded,
}

/// True while a dragon is alive, and its health, for the boss bar.
pub fn dragon_status() -> Option<(i16, i16)> {
    let mut i = 0;
    while i < CAP {
        let m = unsafe { MOBS[i] };
        if m.alive && m.kind == DRAGON {
            return Some((m.health, max_health(DRAGON)));
        }
        i += 1;
    }
    None
}

/// TEMP capture helper: fill the roster with one of each kind in a row on the
/// -Z side of the player (their +Z faces point at a camera looking -Z).
/// Re-assert every frame so AI/damage can't disturb the lineup.
pub const LINEUP_FIRST: u8 = 0;
pub fn debug_lineup(px: i32, py: i32, pz: i32) {
    let mut k: u8 = 0;
    while k < 8 {
        unsafe {
            MOBS[k as usize] = Mob {
                kind: k + LINEUP_FIRST,
                alive: true,
                on_ground: true,
                x: px + (k as i32 * 2 - 7) * 40,
                y: py,
                z: pz - 210,
                vy: 0,
                health: max_health(k + LINEUP_FIRST),
                state: ST_IDLE,
                timer: 0,
                fuse: 0,
                hurt_cd: 0,
                atk: 0,
                love: 0,
            cool: 0,
                walk: 0,
                facing: 0,
                heading: 0,
                fire: 0,
                charged: false,
            };
        }
        k += 1;
    }
}

/// Measurement harness (feature `mob-lab`): one fixed cast placed around the
/// player on the first update, night forced so hostiles hunt, and mob damage
/// counted into LAB_HITS / LAB_ARROWS instead of dealt, so a standing player
/// survives the whole run. Headless route logs watch MOBS and these counters.
#[cfg(feature = "mob-lab")]
pub static mut LAB_HITS: u32 = 0;
#[cfg(feature = "mob-lab")]
pub static mut LAB_ARROWS: u32 = 0;
#[cfg(feature = "mob-lab")]
static mut LAB_INIT: bool = false;
#[cfg(feature = "mob-lab")]
fn lab_setup(px: i32, pz: i32) {
    unsafe {
        if LAB_INIT {
            return;
        }
        LAB_INIT = true;
        MOBS = [DEAD; CAP];
    }
    let cast: [(u8, i32, i32); 8] = [
        (ZOMBIE, -3, 10),
        (SPIDER, 3, 10),
        (SKELETON, 0, 13),
        (PIG, -6, 5),
        (COW, 6, 5),
        (SHEEP, -8, -4),
        (CHICKEN, 8, -4),
        (WOLF, 0, -8),
    ];
    let mut k = 0;
    while k < 8 {
        let (kind, ox, oz) = cast[k];
        spawn_at(kind, px + ox * BLOCK, pz + oz * BLOCK);
        k += 1;
    }
}

/// Tuning lab: (hostiles, animals) alive, and how many of the hostiles stand
/// below the surface of their column.
#[cfg(feature = "tune-lab")]
pub fn lab_census() -> (i32, i32, i32) {
    let (mut h, mut a, mut cave) = (0, 0, 0);
    let mut i = 0;
    while i < CAP {
        let m = unsafe { MOBS[i] };
        if m.alive {
            if is_hostile(m.kind) {
                h += 1;
                let (bx, bz) = (world_to_block_x(m.x), world_to_block_z(m.z));
                if world_to_block_y(m.y) < world::surface_y(bx, bz) {
                    cave += 1;
                }
            } else {
                a += 1;
            }
        }
        i += 1;
    }
    (h, a, cave)
}

/// Tuning lab: hold slot 0 as a `kind` standing on (x, y, z).
#[cfg(feature = "tune-lab")]
pub fn lab_pin(kind: u8, x: i32, y: i32, z: i32) {
    unsafe {
        let m = &mut MOBS[0];
        if !m.alive || m.kind != kind {
            *m = DEAD;
            m.kind = kind;
            m.alive = true;
            m.health = max_health(kind);
        }
        m.x = x;
        m.y = y;
        m.z = z;
        m.vy = 0;
    }
}

/// Crosshair lab (feature `pick-lab`): where the pinned pig stands.
#[cfg(feature = "pick-lab")]
static mut PICK_PIN: (i32, i32, i32) = (0, 0, 0);

/// Crosshair lab: clear the roster and stand one `kind` at (x, y, z), side on
/// to a camera looking +Z. It is held there until first hurt.
#[cfg(feature = "pick-lab")]
pub fn lab_pin_pick(kind: u8, x: i32, y: i32, z: i32) {
    unsafe {
        MOBS = [DEAD; CAP];
        PICK_PIN = (x, y, z);
        let m = &mut MOBS[0];
        m.kind = kind;
        m.alive = true;
        m.on_ground = true;
        m.health = max_health(kind);
        m.facing = 1;
        (m.x, m.y, m.z) = (x, y, z);
    }
}

/// Crosshair lab: slot 0's health and position (health 0 once it is gone).
#[cfg(feature = "pick-lab")]
pub fn lab_pig() -> (i32, i32, i32) {
    let m = unsafe { MOBS[0] };
    if m.alive {
        (m.health as i32, m.x, m.z)
    } else {
        (0, m.x, m.z)
    }
}

#[cfg(feature = "pick-lab")]
fn lab_hold() {
    unsafe {
        let m = &mut MOBS[0];
        if m.alive && m.health == max_health(m.kind) && PICK_PIN.0 != 0 {
            (m.x, m.y, m.z) = PICK_PIN;
            m.vy = 0;
            m.state = ST_IDLE;
            m.timer = 0;
            m.facing = 1;
        }
    }
}

/// Advance all mobs: spawn budget, AI, physics, despawn.
/// `sky` is the internal sky light mobs spawn by (thunder already folded
/// in); `burn` is whether it is day enough for the undead to burn.
pub fn update(px: i32, py: i32, pz: i32, sky: i32, burn: bool) {
    #[cfg(feature = "pick-lab")]
    lab_hold();
    #[cfg(feature = "mob-lab")]
    lab_setup(px, pz);
    #[cfg(feature = "mob-lab")]
    let sky = if true { 4 } else { sky };
    // Night: the open sky dark enough for monsters to spawn on it.
    let night = sky <= 7;
    unsafe {
        if SPAWN_TIMER > 0 {
            SPAWN_TIMER -= 1;
        } else {
            if count_alive() < CAP {
                try_spawn(px, pz, sky);
            }
            SPAWN_TIMER = secs(3) as u16;
        }
    }

    unsafe {
        BURN_TICK = BURN_TICK.wrapping_add(1);
        let t = PACK_TGT;
        if t < CAP && !MOBS[t].alive {
            PACK_TGT = CAP;
        }
    }
    if unsafe { BURN_TICK } % secs(1) as u16 == 0 {
        unpark_near(px, pz);
        pack_pick_skeleton(px, pz);
    }
    let mut i = 0;
    while i < CAP {
        if unsafe { MOBS[i].alive } {
            step_mob(i, px, py, pz, night);
            // Idle voices: each slot mutters on its own ~7s cycle (offset per
            // slot so the field never speaks in chorus), volume falling with
            // distance, silent out of earshot.
            if (unsafe { BURN_TICK } as usize).wrapping_add(i * 134) % VOICE_PERIOD == 0 {
                let (mx, mz, kind) = unsafe { (MOBS[i].x, MOBS[i].z, MOBS[i].kind) };
                let d = ((mx - px).abs() + (mz - pz).abs()) / 64;
                if d < 14 {
                    match kind {
                        PIG => crate::sfx::pig(d),
                        COW => crate::sfx::cow(d),
                        SHEEP => crate::sfx::sheep(d),
                        CHICKEN => crate::sfx::chicken(d),
                        ZOMBIE => crate::sfx::zombie(d),
                        SKELETON => crate::sfx::skeleton(d),
                        WOLF => crate::sfx::wolf(d),
                        SPIDER => crate::sfx::spider(d),
                        _ => {}
                    }
                }
            }
            if burn {
                sun_burn(i);
            }
            if world::fire_live() {
                fire_contact(i);
            }
            if unsafe { MOBS[i].fire } > 0 {
                mob_fire(i);
            }
            unsafe {
                // u16::MAX marks a tamed wolf and must not count down: it
                // used to, so a wolf stayed tamed for a single tick.
                if MOBS[i].love > 0 && MOBS[i].love != u16::MAX {
                    MOBS[i].love -= 1;
                }
                if MOBS[i].cool > 0 {
                    MOBS[i].cool -= 1;
                }
            }
        }
        i += 1;
    }
    breed_tick();
    update_arrows(px, py, pz);
}

/// A pack with nothing to fight goes for a skeleton within 16 blocks of the
/// owner: standing tamed wolves attack skeletons unprovoked
/// (minecraft.wiki/w/Wolf).
fn pack_pick_skeleton(px: i32, pz: i32) {
    if unsafe { PACK_TGT } < CAP {
        return;
    }
    let mut wolves = false;
    let mut i = 0;
    while i < CAP {
        wolves |= is_tamed(i);
        i += 1;
    }
    if !wolves {
        return;
    }
    let r = 16 * BLOCK;
    let mut i = 0;
    while i < CAP {
        let m = unsafe { MOBS[i] };
        if m.alive
            && (m.kind == SKELETON || m.kind == CHARRED_SK)
            && (m.x - px).abs() < r
            && (m.z - pz).abs() < r
        {
            unsafe { PACK_TGT = i };
            return;
        }
        i += 1;
    }
}

/// Pair up two nearby in-love same-kind animals into a new one, then clear both.
fn breed_tick() {
    let mut i = 0;
    while i < CAP {
        let mi = unsafe { MOBS[i] };
        if mi.alive && mi.love > 0 && mi.love != u16::MAX && !is_hostile(mi.kind) {
            let mut j = i + 1;
            while j < CAP {
                let mj = unsafe { MOBS[j] };
                if mj.alive && mj.love > 0 && mj.love != u16::MAX && mj.kind == mi.kind {
                    let d = (mi.x - mj.x).abs() + (mi.z - mj.z).abs();
                    if d < 2 * BLOCK {
                        let (cx, cz) = ((mi.x + mj.x) / 2, (mi.z + mj.z) / 2);
                        spawn_offspring(mi.kind, mi.x, mi.y, mi.z);
                        unsafe {
                            MOBS[i].love = 0;
                            MOBS[j].love = 0;
                            MOBS[i].cool = BREED_COOLDOWN;
                            MOBS[j].cool = BREED_COOLDOWN;
                        }
                        crate::spawn_particles(
                            cx,
                            mi.y + BLOCK,
                            cz,
                            (240, 120, 170),
                            8,
                            (i * 31 + j) as u32,
                            14,
                        );
                        break;
                    }
                }
                j += 1;
            }
        }
        i += 1;
    }
}

/// The young appear at a parent, as in Java; they used to drop onto the
/// column's surface, on the roof over a barn.
fn spawn_offspring(kind: u8, x: i32, y: i32, z: i32) {
    let s = match free_slot() {
        Some(s) => s,
        None => return,
    };
    unsafe {
        MOBS[s] = Mob {
            kind,
            alive: true,
            on_ground: false,
            x,
            y,
            z,
            vy: 0,
            health: max_health(kind),
            state: ST_IDLE,
            timer: 0,
            fuse: 0,
            hurt_cd: 0,
            atk: 0,
            love: 0,
            cool: 0,
            walk: 0,
            facing: 0,
            heading: 0,
            fire: 0,
            charged: false,
        };
    }
}

/// Feed mob `t`, the one under the crosshair, the held `item`: an animal
/// takes its breeding food (`eats`) into love mode, a tamed wolf below full
/// health takes meat and heals by its hunger points (raw meat 3, steak 8:
/// minecraft.wiki/w/Wolf, /w/Raw_Beef, /w/Steak). True when it was eaten.
/// It used to feed the nearest animal in front of you, whatever it ate.
pub fn feed(t: usize, item: u8) -> bool {
    if t >= CAP {
        return false;
    }
    let mut m = unsafe { MOBS[t] };
    if !m.alive {
        return false;
    }
    if m.kind == WOLF && m.love == u16::MAX {
        let heal = match item {
            crate::RAW_MEAT => 3,
            crate::COOKED_MEAT => 8,
            _ => return false,
        };
        if m.health >= TAMED_WOLF_HEALTH {
            return false;
        }
        m.health = (m.health + heal).min(TAMED_WOLF_HEALTH);
    } else if eats(m.kind, item) && m.love == 0 && m.cool == 0 {
        m.love = LOVE_TICKS;
    } else {
        return false;
    }
    unsafe { MOBS[t] = m };
    crate::spawn_particles(m.x, m.y + BLOCK, m.z, (240, 120, 170), 5, t as u32, 12);
    true
}

static mut BURN_TICK: u16 = 0;

/// Zombies and skeletons caught in open daylight catch fire and burn down,
/// like Java. ponytail: "exposed" = at/above the surface column (ignores
/// overhangs/caves-with-skylight); damage ticks on a shared cadence.
/// Wraiths teleport when struck: a short hop to a random spot around the
/// player, which is what makes them awkward to fight rather than just tanky.
fn blink(m: &mut Mob, px: i32, pz: i32) {
    let r = rng();
    let dx = ((r % 9) as i32 - 4) * BLOCK;
    let dz = (((r >> 4) % 9) as i32 - 4) * BLOCK;
    let (nx, nz) = (px + dx, pz + dz);
    let bx = world_to_block_x(nx);
    let bz = world_to_block_z(nz);
    let sy = world::surface_y(bx, bz);
    if sy < 1 || sy > 120 {
        return;
    }
    let feet = sy * BLOCK;
    let (hw, h) = dims(m.kind);
    if aabb_collides_dims(nx, feet, nz, hw, h) {
        return; // no room there; stay put
    }
    m.x = nx;
    m.y = feet;
    m.z = nz;
    m.vy = 0;
}

fn sun_burn(i: usize) {
    let tick = unsafe { BURN_TICK };
    if tick % SUN_BURN_PERIOD != 0 {
        return;
    }
    let mut m = unsafe { MOBS[i] };
    if m.kind != ZOMBIE && m.kind != SKELETON {
        return;
    }
    // Java's undead burn only under open sky and out of water (minecraft.wiki
    // /w/Zombie, /w/Skeleton): any block overhead, leaves included, shades
    // them, and water puts them out. surface_y skips leaves and water, so
    // they used to burn under trees and at the bottom of lakes.
    let bx = world_to_block_x(m.x);
    let bz = world_to_block_z(m.z);
    let by = world_to_block_y(m.y);
    if crate::is_water(world::get(bx, by, bz)) || crate::is_water(world::get(bx, by + 1, bz)) {
        return;
    }
    let mut y = by + 2;
    while y < world::CH {
        if world::get(bx, y, bz) != crate::AIR {
            return; // shaded
        }
        y += 1;
    }
    // Rain wets them where it falls (Java's isInWaterRainOrBubble); in a
    // desert or in snow they burn on.
    if unsafe { RAINING } && world::precipitation(bx, bz) == world::PRECIP_RAIN {
        return;
    }
    crate::spawn_particles(
        m.x,
        m.y + BLOCK,
        m.z,
        (240, 140, 40),
        4,
        (tick as u32) ^ (i as u32),
        16,
    );
    m.health -= 1;
    if m.health <= 0 {
        unsafe {
            MOBS[i] = DEAD;
        }
    } else {
        unsafe {
            MOBS[i] = m;
        }
    }
}

/// Line of sight between two points (world units): sampled every quarter
/// block, blocked by any solid block. Java's mobs need sight to pick a
/// target, a skeleton to shoot and a creeper to keep its fuse lit.
fn sees(ax: i32, ay: i32, az: i32, bx: i32, by: i32, bz: i32) -> bool {
    let (dx, dy, dz) = (bx - ax, by - ay, bz - az);
    let n = (dx.abs().max(dy.abs()).max(dz.abs()) / 16).max(1);
    let mut k = 1;
    while k < n {
        if solid(ax + dx * k / n, ay + dy * k / n, az + dz * k / n) {
            return false;
        }
        k += 1;
    }
    true
}

/// Experience a kill drops (minecraft.wiki/w/Experience): monsters 5, animals
/// and wolves 1 to 3, villagers none.
fn xp_for(kind: u8) -> u16 {
    if kind == VILLAGER {
        0
    } else if is_hostile(kind) {
        5
    } else {
        1 + (rng() % 3) as u16
    }
}

pub fn is_tamed(i: usize) -> bool {
    i < CAP && unsafe { MOBS[i].alive && MOBS[i].kind == WOLF && MOBS[i].love == u16::MAX }
}

/// Put a tamed wolf on the parked list. False when the list is full (the
/// wolf is then lost: Java keeps any number, the PS1 build keeps four).
fn park(m: &Mob) -> bool {
    let dim = world::dimension();
    unsafe {
        let mut k = 0;
        while k < TAMED_CAP {
            if !PARKED[k].used {
                PARKED[k] = Parked {
                    used: true,
                    dim,
                    x: m.x,
                    y: m.y,
                    z: m.z,
                    hp: m.health,
                };
                return true;
            }
            k += 1;
        }
    }
    false
}

/// Leaving this dimension: tamed wolves go on the parked list, everything
/// else in the pool belonged to this dimension and is dropped.
pub fn leave_dimension() {
    let mut i = 0;
    while i < CAP {
        if is_tamed(i) {
            let m = unsafe { MOBS[i] };
            park(&m);
        }
        i += 1;
    }
    reset();
}

/// Bring parked wolves of this dimension back once their spot is inside the
/// loaded ring again.
fn unpark_near(px: i32, pz: i32) {
    let dim = world::dimension();
    let mut k = 0;
    while k < TAMED_CAP {
        let p = unsafe { PARKED[k] };
        if p.used
            && p.dim == dim
            && (p.x - px).abs() < DESPAWN_R - 4 * BLOCK
            && (p.z - pz).abs() < DESPAWN_R - 4 * BLOCK
        {
            if let Some(s) = free_slot() {
                unsafe {
                    MOBS[s] = Mob {
                        kind: WOLF,
                        alive: true,
                        x: p.x,
                        y: p.y,
                        z: p.z,
                        health: p.hp,
                        love: u16::MAX,
                        ..DEAD
                    };
                    PARKED[k] = NO_PARKED;
                }
            }
        }
        k += 1;
    }
}

/// Every tamed wolf in the world, for the save: parked ones and those in
/// the pool (in this dimension). Returns how many were written.
pub fn tamed_list(out: &mut [Parked; TAMED_CAP]) -> usize {
    let mut n = 0;
    let mut k = 0;
    while k < TAMED_CAP {
        let p = unsafe { PARKED[k] };
        if p.used && n < TAMED_CAP {
            out[n] = p;
            n += 1;
        }
        k += 1;
    }
    let dim = world::dimension();
    let mut i = 0;
    while i < CAP {
        if is_tamed(i) && n < TAMED_CAP {
            let m = unsafe { MOBS[i] };
            out[n] = Parked {
                used: true,
                dim,
                x: m.x,
                y: m.y,
                z: m.z,
                hp: m.health,
            };
            n += 1;
        }
        i += 1;
    }
    n
}

/// A loaded save's tamed wolves: all parked, so they come back as the ring
/// reaches them.
pub fn set_tamed(list: &[Parked]) {
    unsafe {
        PARKED = [NO_PARKED; TAMED_CAP];
        let mut k = 0;
        while k < list.len() && k < TAMED_CAP {
            PARKED[k] = list[k];
            k += 1;
        }
    }
}

#[inline]
fn solid(wx: i32, wy: i32, wz: i32) -> bool {
    let b = world::get(
        world_to_block_x(wx),
        world_to_block_y(wy),
        world_to_block_z(wz),
    );
    b != crate::AIR && b != crate::WATER && b != crate::LAVA
}

fn free_arrow() -> Option<usize> {
    let mut i = 0;
    while i < ARROW_CAP {
        if !unsafe { ARROWS[i].alive } {
            return Some(i);
        }
        i += 1;
    }
    None
}

fn shoot_arrow(sx: i32, sy: i32, sz: i32, px: i32, py: i32, pz: i32) {
    let a = match free_arrow() {
        Some(a) => a,
        None => return,
    };
    let (ex, ey, ez) = (sx, sy + 56, sz);
    let dx = px - ex;
    let dz = pz - ez;
    let horiz = psx_math::int32::isqrt_i32(dx * dx + dz * dz);
    let dy = (py + PLAYER_HEIGHT / 3) - ey + horiz / 5;
    let len = psx_math::int32::isqrt_i32(dx * dx + dy * dy + dz * dz).max(1);
    unsafe {
        ARROWS[a] = Arrow {
            alive: true,
            x: ex << 8,
            y: ey << 8,
            z: ez << 8,
            vx: dx * SKEL_Q8 / len,
            vy: dy * SKEL_Q8 / len,
            vz: dz * SKEL_Q8 / len,
            life: ARROW_LIFE,
            from_player: false,
        };
    }
}

/// Fire an arrow from the player's eye along a Q12 look direction (the camera
/// forward vector, unit length). Player arrows damage mobs, not the player.
pub fn player_shoot(ex: i32, ey: i32, ez: i32, dx: i32, dy: i32, dz: i32) {
    let a = match free_arrow() {
        Some(a) => a,
        None => return,
    };
    unsafe {
        ARROWS[a] = Arrow {
            alive: true,
            x: ex << 8,
            y: ey << 8,
            z: ez << 8,
            vx: dx * BOW_Q8 >> 12,
            vy: dy * BOW_Q8 >> 12,
            vz: dz * BOW_Q8 >> 12,
            life: ARROW_LIFE,
            from_player: true,
        };
    }
}

/// An in-flight player arrow at (ax,ay,az) doing `dmg`: damage the first mob it overlaps.
fn arrow_hit_mob(ax: i32, ay: i32, az: i32, dmg: i16) -> bool {
    let mut i = 0;
    while i < CAP {
        let mut m = unsafe { MOBS[i] };
        if m.alive {
            let (w, h) = dims(m.kind);
            if m.hurt_cd == 0
                && (ax - m.x).abs() < w + 6
                && (az - m.z).abs() < w + 6
                && ay > m.y - 8
                && ay < m.y + h
            {
                // Java: ceil(2 x speed in blocks a game tick) (minecraft.wiki/w/
                // Arrow), 6 leaving the bow, less as drag slows it.
                m.health -= dmg;
                m.hurt_cd = HURT_TICKS;
                if m.health <= 0 {
                    record_death(&m);
                    unsafe {
                        XP_DROPS += xp_for(m.kind);
                        MOBS[i] = DEAD;
                    }
                } else {
                    if !is_hostile(m.kind) {
                        m.state = ST_FLEE;
                        m.timer = FLEE_TICKS;
                    }
                    unsafe {
                        MOBS[i] = m;
                    }
                }
                return true;
            }
        }
        i += 1;
    }
    false
}

fn explode(i: usize, cx: i32, cy: i32, cz: i32, charged: bool) -> bool {
    // A charged sapper blasts at twice the power, 6 (Creeper.explodeCreeper).
    let power = if charged { 2 * SAPPER_POWER } else { SAPPER_POWER };
    let blast_y = cy + BLOCK / 2; // half a block up the sapper
    if !world::explode(cx, blast_y, cz, power, (cx ^ cz) as u32) {
        return false;
    }
    // Remove the sapper only after its block blast is queued. The following
    // entity hit must not kill it and drop gunpowder or XP.
    unsafe { MOBS[i] = DEAD };
    crate::spawn_particles(cx, cy + BLOCK, cz, (96, 84, 72), 30, (cx ^ cz) as u32, 44);
    crate::tnt::explosion_effects(cx, blast_y, cz, power, usize::MAX);
    true
}

/// A spent fuse retries each tick until the bounded blast queue accepts it.
fn finish_sapper(i: usize, m: Mob) {
    if !explode(i, m.x, m.y, m.z, m.charged) {
        unsafe { MOBS[i] = m };
    }
}

/// A blast's damage and knockback on every mob in reach (Java hurts all
/// entities). The push is a decaying shove (KICK_X, KICK_Z) plus an upward
/// speed; the centre sees the mob through the world as it stands.
pub fn blast_mobs(cx: i32, cy: i32, cz: i32, power: i32) {
    let mut i = 0;
    while i < CAP {
        let mut m = unsafe { MOBS[i] };
        if m.alive {
            let (hw, h) = dims(m.kind);
            if let Some(hit) = crate::tnt::hit_on(power, (cx, cy, cz), (m.x, m.y, m.z), hw, h, h * 9 / 10, true)
            {
                m.health -= hit.dmg as i16;
                m.hurt_cd = HURT_TICKS;
                // Q8 blocks a Java tick to Q8 units a sim tick, x 64 / 3.
                unsafe {
                    KICK_X[i] = (KICK_X[i] + hit.kx * 64 / 3).clamp(-9000, 9000);
                    KICK_Z[i] = (KICK_Z[i] + hit.kz * 64 / 3).clamp(-9000, 9000);
                }
                // The same push up, in units a sim tick (x 64 / 3 / 256).
                m.vy = m.vy.max(hit.ky / 12);
                m.on_ground = false;
                if m.health <= 0 {
                    record_death(&m);
                    m = DEAD;
                }
                unsafe { MOBS[i] = m };
            }
        }
        i += 1;
    }
}

/// A mob's knockback from blasts, Q8 world units a sim tick, decaying by an
/// eighth a tick. Beside the mob table so `Mob` stays as it was.
static mut KICK_X: [i32; CAP] = [0; CAP];
static mut KICK_Z: [i32; CAP] = [0; CAP];

/// A blast's damage to the player, taken with the arrows' through the same
/// invulnerability rule. The strongest of a frame's blasts counts: Java gives
/// a second hit inside the i-frames only the difference.
pub fn blast_hazard(d: i32) {
    unsafe { HAZARD_DMG = HAZARD_DMG.max(d) };
}

/// A mob standing in a fire block catches fire for 8 s (160 game ticks) and
/// takes 1 damage every half second while it stays (Damage#Fire).
#[inline(never)]
fn fire_contact(i: usize) {
    let mut m = unsafe { MOBS[i] };
    let (bx, by, bz) = (
        world_to_block_x(m.x),
        world_to_block_y(m.y + 8),
        world_to_block_z(m.z),
    );
    let (_, h) = dims(m.kind);
    let in_fire = world::get(bx, by, bz) == crate::FIRE
        || world::get(bx, world_to_block_y(m.y + h / 2), bz) == crate::FIRE;
    if !in_fire {
        return;
    }
    m.fire = m.fire.max(java_ticks(160) as u16);
    if (unsafe { BURN_TICK } as usize).wrapping_add(i * 11) % java_ticks(10) as usize == 0 {
        m.health -= 1;
        if m.health <= 0 {
            record_death(&m);
            m = DEAD;
        }
    }
    unsafe { MOBS[i] = m };
}

/// A player arrow's damage from its speed: ceil(2 x blocks a game tick).
fn arrow_damage(a: &Arrow) -> i16 {
    let v2 = (a.vx >> 4) * (a.vx >> 4) + (a.vy >> 4) * (a.vy >> 4) + (a.vz >> 4) * (a.vz >> 4);
    let v = psx_math::int32::isqrt_i32(v2) << 4; // Q8 units a sim tick
    // blocks a game tick = v * 3 / (64 * 256); x 2, rounded up.
    ((v * 6 + 16383) / 16384) as i16
}

fn update_arrows(px: i32, py: i32, pz: i32) {
    let mut i = 0;
    while i < ARROW_CAP {
        let mut a = unsafe { ARROWS[i] };
        if a.alive {
            a.vy -= BOW_GRAVITY;
            a.vx -= (a.vx * BOW_DRAG_16384) >> 14;
            a.vy -= (a.vy * BOW_DRAG_16384) >> 14;
            a.vz -= (a.vz * BOW_DRAG_16384) >> 14;
            // A bow arrow covers a block a tick: test it in steps of at most
            // 16 units so it cannot pass through a mob or a thin wall.
            let far = a.vx.abs().max(a.vy.abs()).max(a.vz.abs());
            let n = far / (16 << 8) + 1;
            let mut dead = a.life == 0;
            let mut k = 0;
            while k < n && !dead {
                a.x += a.vx / n;
                a.y += a.vy / n;
                a.z += a.vz / n;
                let (ax, ay, az) = (a.x >> 8, a.y >> 8, a.z >> 8);
                if solid(ax, ay, az) {
                    dead = true;
                } else if a.from_player {
                    // Player arrow: damage the first mob it overlaps.
                    if arrow_hit_mob(ax, ay, az, arrow_damage(&a)) {
                        dead = true;
                    }
                } else if (ax - px).abs() < PLAYER_HALF_W + 8
                    && (az - pz).abs() < PLAYER_HALF_W + 8
                    && ay > py
                    && ay < py + PLAYER_HEIGHT
                {
                    // Skeleton arrow: damage the player.
                    // Skeleton arrows: 3 to 5 on Normal (minecraft.wiki/w/Skeleton).
                    unsafe {
                        HAZARD_DMG += 3 + (rng() % 3) as i32;
                    }
                    dead = true;
                }
                k += 1;
            }
            if a.life > 0 {
                a.life -= 1;
            }
            if dead {
                a.alive = false;
            }
            unsafe {
                ARROWS[i] = a;
            }
        }
        i += 1;
    }
}

/// Arrow + blast damage to the player this frame (taken and cleared).
pub fn hazard_damage() -> i32 {
    unsafe {
        let d = HAZARD_DMG;
        HAZARD_DMG = 0;
        #[cfg(feature = "mob-lab")]
        {
            LAB_ARROWS += (d > 0) as u32;
            return 0;
        }
        #[allow(unreachable_code)]
        d
    }
}

/// Damage to the player from the world (a lightning strike), applied with
/// the mob hits through the same invulnerability rule.
pub fn add_hazard(d: i32) {
    unsafe { HAZARD_DMG += d };
}

/// Java's isRaining, mirrored from the weather each tick: rain puts out a
/// burning mob under the open sky.
static mut RAINING: bool = false;
pub fn set_raining(on: bool) {
    unsafe { RAINING = on };
}

/// A mob a strike may jump to: alive, within 3 blocks of the struck column,
/// no lower than 3 under its ground, and under open sky (Java's
/// findLightningTargetAround).
fn thunder_ok(m: &Mob, bx: i32, by: i32, bz: i32) -> bool {
    if !m.alive {
        return false;
    }
    let (mx, my, mz) = (
        world_to_block_x(m.x),
        world_to_block_y(m.y),
        world_to_block_z(m.z),
    );
    (mx - bx).abs() <= 3
        && (mz - bz).abs() <= 3
        && my >= by - 3
        && crate::weather::sky_above(mx, my, mz)
}

/// How many mobs a strike on this column could jump to.
#[inline(never)]
#[optimize(size)] // only when lightning strikes
pub fn thunder_candidates(bx: i32, by: i32, bz: i32) -> usize {
    let mut n = 0;
    let mut i = 0;
    while i < CAP {
        if thunder_ok(unsafe { &MOBS[i] }, bx, by, bz) {
            n += 1;
        }
        i += 1;
    }
    n
}

/// The `k`th of those, its feet in world units.
#[inline(never)]
#[optimize(size)] // only when lightning strikes
pub fn thunder_candidate(bx: i32, by: i32, bz: i32, k: usize) -> Option<(i32, i32, i32)> {
    let mut n = 0;
    let mut i = 0;
    while i < CAP {
        let m = unsafe { MOBS[i] };
        if thunder_ok(&m, bx, by, bz) {
            if n == k {
                return Some((m.x, m.y, m.z));
            }
            n += 1;
        }
        i += 1;
    }
    None
}

/// A lightning flash's strike box, 3 blocks around the bolt and from 3
/// below to 9 above (LightningBolt.tick): every mob in it takes the bolt's 5
/// damage through its damage immunity and is set alight for `burn` sim
/// ticks (Entity.thunderHit), and a sapper becomes charged, as a creeper does
/// (minecraft.wiki/w/Creeper#Charged creeper). Java's other conversions have
/// no VoXide mob to happen to: pigs into zombified piglins, villagers into
/// witches, mooshrooms, turtles.
#[inline(never)]
#[optimize(size)] // only when lightning strikes
pub fn thunder_hit(x: i32, y: i32, z: i32, burn: u16) {
    let r = 3 * BLOCK;
    let mut i = 0;
    while i < CAP {
        let mut m = unsafe { MOBS[i] };
        if m.alive
            && (m.x - x).abs() <= r
            && (m.z - z).abs() <= r
            && m.y >= y - r
            && m.y <= y + 9 * BLOCK
        {
            if m.hurt_cd == 0 {
                m.health -= 5;
                m.hurt_cd = HURT_TICKS;
            }
            m.fire = m.fire.max(burn);
            if m.kind == SAPPER {
                m.charged = true;
            }
            if m.health <= 0 {
                record_death(&m);
                m = DEAD;
            }
            unsafe { MOBS[i] = m };
        }
        i += 1;
    }
}

/// A burning mob: 1 damage a second while alight (Java hurts on every 20th
/// fire tick), put out by water, or by rain where it can see the sky.
#[inline(never)]
fn mob_fire(i: usize) {
    let mut m = unsafe { MOBS[i] };
    if m.fire == 0 {
        return;
    }
    let (bx, by, bz) = (
        world_to_block_x(m.x),
        world_to_block_y(m.y),
        world_to_block_z(m.z),
    );
    if crate::is_water(world::get(bx, by, bz))
        || (unsafe { RAINING }
            && crate::weather::sky_above(bx, by, bz)
            && world::precipitation(bx, bz) == world::PRECIP_RAIN)
    {
        m.fire = 0;
    } else {
        if m.fire % SUN_BURN_PERIOD == 0 {
            m.health -= 1;
            crate::spawn_particles(m.x, m.y + BLOCK, m.z, (240, 140, 40), 4, i as u32, 16);
        }
        m.fire -= 1;
        if m.health <= 0 {
            record_death(&m);
            m = DEAD;
        }
    }
    unsafe { MOBS[i] = m };
}

pub const fn arrow_cap() -> usize {
    ARROW_CAP
}

pub fn arrow_view(i: usize) -> (bool, i32, i32, i32) {
    let a = unsafe { ARROWS[i] };
    (a.alive, a.x >> 8, a.y >> 8, a.z >> 8)
}

/// Q8 velocity of length `speed` along (dx, dz). The length is the
/// alpha-max-plus-beta-min estimate (within 4%), which spares a square root.
/// The old greedy axis-step moved both axes at full speed, so a diagonal
/// chase ran 1.41x the straight one.
fn toward(dx: i32, dz: i32, speed: i32) -> (i32, i32) {
    let (a, b) = (dx.abs(), dz.abs());
    let len = (a.max(b) * 123 + a.min(b) * 51) >> 7;
    if len == 0 {
        return (0, 0);
    }
    (speed * dx / len, speed * dz / len)
}

/// Q8 velocity of length `speed` along a 256-step heading (0 = +Z, 64 = +X).
#[inline(never)]
fn heading_vec(h: u8, speed: i32) -> (i32, i32) {
    let a = (h as u16) << 4;
    (
        (speed * sincos::sin_q12(a)) >> 12,
        (speed * sincos::cos_q12(a)) >> 12,
    )
}

/// Whole units to move this tick for a Q8 velocity. `t` is a running tick
/// count, so over any 256 ticks the steps add up to exactly the velocity:
/// fractional speeds come out right with nothing stored per mob.
#[inline]
fn dstep(v: i32, t: i32) -> i32 {
    ((v * (t + 1)) >> 8) - ((v * t) >> 8)
}

/// Quarter turn for a movement direction. It only changes when the new side
/// clearly wins, so a mob walking near a diagonal does not flicker between two
/// faces.
#[inline(never)]
fn face_of(vx: i32, vz: i32, cur: u8) -> u8 {
    let score = [vz, vx, -vz, -vx];
    let mut best = 0;
    let mut k = 1;
    while k < 4 {
        if score[k] > score[best] {
            best = k;
        }
        k += 1;
    }
    if score[best] > score[cur as usize & 3] + (vx.abs() + vz.abs()) / 4 {
        best as u8
    } else {
        cur
    }
}

fn step_mob(i: usize, px: i32, py: i32, pz: i32, night: bool) {
    let mut m = unsafe { MOBS[i] };
    if m.hurt_cd > 0 {
        m.hurt_cd -= 1;
    }
    if m.kind == SAPPER && m.fuse >= FUSE_MAX {
        finish_sapper(i, m);
        return; // Keep a spent fuse pending until the blast queue accepts it.
    }

    let dx = px - m.x;
    let dz = pz - m.z;
    let dist2 = dx * dx + dz * dz;

    // Despawn far mobs (protects fps + RAM). A tamed wolf never despawns in
    // Java: one left outside the ring is parked instead (its chunk unloaded).
    if m.kind != DRAGON && (dx.abs() > DESPAWN_R || dz.abs() > DESPAWN_R) {
        if m.kind == WOLF && m.love == u16::MAX {
            park(&m);
        }
        unsafe {
            MOBS[i] = DEAD;
        }
        return;
    }
    let (mhw, mh) = dims(m.kind);
    // Eyes, for line of sight: the mob's near the top of its box, the
    // player's at 0.9 of its height.
    let (eyey, peye) = (m.y + mh * 85 / 100, py + PLAYER_HEIGHT * 9 / 10);
    if is_hostile(m.kind)
        && dist2 < follow_r(m.kind) * follow_r(m.kind)
        && (unsafe { BURN_TICK } as usize + i) % 10 == 0
    {
        unsafe { SIGHT[i] = sees(m.x, eyey, m.z, px, peye, pz) };
    }
    let sight = unsafe { SIGHT[i] };

    // State transitions.
    let was = m.state;
    let flyer = is_flyer(m.kind);
    if m.state == ST_FLEE {
        if m.timer > 0 {
            m.timer -= 1;
        } else {
            m.state = ST_IDLE;
        }
    } else if m.kind == DRAGON {
        // Never loses interest, and daylight means nothing to it.
        m.state = if dist2 < DRAGON_CHASE_R * DRAGON_CHASE_R {
            ST_CHASE
        } else {
            ST_WANDER
        };
        m.timer = m.timer.wrapping_add(1); // flight phase, drives the height weave
    } else if m.kind == EMBER || m.kind == WAILER {
        // Hostile on sight and unaffected by daylight; they only live in the
        // Inferno, where there is none.
        m.state = if dist2 < CHASE_R * CHASE_R {
            ST_CHASE
        } else {
            ST_WANDER
        };
        m.timer = m.timer.wrapping_add(1);
    } else if m.kind == WRAITH {
        // Neutral: it only hunts once you have hit it, and hitting it sets
        // ST_CHASE directly. Daylight is irrelevant to it.
        if m.state == ST_CHASE && dist2 > LOSE_R * LOSE_R {
            m.state = ST_IDLE;
        }
    } else if is_hostile(m.kind)
        && (night || m.kind != SPIDER)
        && dist2 < follow_r(m.kind) * follow_r(m.kind)
        && (m.state == ST_CHASE || sight)
    {
        // Monsters hunt by day too (a cave spawn does); spiders only in the
        // dark, as Java's are neutral in bright light. Java's monsters pick
        // a target they can see, within their follow range, and keep it.
        m.state = ST_CHASE;
    } else if m.state == ST_CHASE && dist2 > lose_r(m.kind) * lose_r(m.kind) {
        m.state = ST_IDLE;
    }

    // A tamed wolf (minecraft.wiki/w/Wolf) goes for the pack target, else
    // follows its owner past 10 blocks and stops within 2, and teleports to
    // the owner past 12 blocks (16 while fighting).
    let tamed = m.kind == WOLF && m.love == u16::MAX;
    let mut tgt = CAP;
    if tamed {
        let t = unsafe { PACK_TGT };
        if t < CAP && t != i && unsafe { MOBS[t].alive } && !is_tamed(t) {
            tgt = t;
        }
        let tele = if tgt < CAP { WOLF_TELEPORT_FIGHT_R } else { WOLF_TELEPORT_R };
        if dist2 > tele * tele {
            // Two blocks off the owner, on the owner's level.
            let (ux, uz) = toward(-dx, -dz, 2 * BLOCK);
            if !aabb_collides_dims(px + ux, py, pz + uz, mhw, mh) {
                m.x = px + ux;
                m.y = py;
                m.z = pz + uz;
                m.vy = 0;
            }
        }
        if tgt < CAP {
            m.state = ST_CHASE;
        } else if dist2 > WOLF_FOLLOW_R * WOLF_FOLLOW_R {
            m.state = ST_CHASE;
        } else if m.state == ST_CHASE && dist2 < WOLF_STOP_R * WOLF_STOP_R {
            m.state = ST_IDLE;
        }
        if m.fuse > 0 {
            m.fuse -= 1; // bite cooldown (a wolf has no fuse)
        }
        if tgt < CAP {
            let t = unsafe { MOBS[tgt] };
            let (thw, _) = dims(t.kind);
            let reach = mhw + thw + 8;
            if m.fuse == 0
                && (t.x - m.x).abs() < reach
                && (t.z - m.z).abs() < reach
                && (t.y - m.y).abs() < BLOCK
            {
                bite(tgt, m.x, m.z);
                m.fuse = WOLF_BITE_TICKS;
            }
        }
    } else if m.kind == WOLF && m.state == ST_CHASE && dist2 > LOSE_R * LOSE_R {
        m.state = ST_IDLE; // a provoked wild wolf gives up, as hostiles do
    }
    // Passive animals follow a player holding their food (reuses the chase walk).
    if !is_hostile(m.kind) && m.kind != WOLF && m.state != ST_FLEE {
        let lure = eats(m.kind, unsafe { LURE });
        if lure && dist2 < LURE_R * LURE_R {
            m.state = ST_CHASE;
        } else if m.state == ST_CHASE && (!lure || dist2 > LURE_R * LURE_R) {
            m.state = ST_IDLE;
        }
    }
    // While hunting, `timer` is the skeleton's bow cooldown (flyers keep it as
    // their flight phase). It used to carry over whatever the wander count
    // was; a skeleton now draws for a second after spotting you.
    if m.state == ST_CHASE && was != ST_CHASE && !flyer {
        m.timer = if m.kind == SKELETON { SHOT_DRAW } else { 0 };
    }

    // Ranged + explosive hostiles while chasing.
    if m.state == ST_CHASE {
        if m.kind == SKELETON {
            if m.timer > 0 {
                m.timer -= 1;
            } else if dist2 < SHOOT_R * SHOOT_R && sight {
                shoot_arrow(m.x, m.y, m.z, px, py, pz);
                m.timer = SHOT_TICKS;
            }
        } else if m.kind == SAPPER {
            // Java's swell: start within 3 blocks in sight, keep going while
            // within 7 and in sight, otherwise wind back down. `cool` holds
            // the direction (a sapper never breeds).
            let dy = py - m.y;
            let d3 = dist2 + dy * dy;
            let r = if m.cool == 1 { FUSE_KEEP_R } else { FUSE_START_R };
            m.cool = (sight && d3 < r * r) as u16;
            if m.cool == 1 {
                m.fuse += 1;
                if m.fuse == 1 {
                    crate::sfx::sapper_hiss(); // the dreaded tsss
                }
                if m.fuse >= FUSE_MAX {
                    m.fuse = FUSE_MAX;
                    finish_sapper(i, m);
                    return;
                }
            } else if m.fuse > 0 {
                m.fuse -= 1;
            }
        }
    }

    // Movement intent, a Q8 units/tick velocity.
    let (mut vx, mut vz) = (0i32, 0i32);
    if m.kind == DRAGON && m.state == ST_CHASE {
        // Java's dragon keeps its distance and circles. Ours used to fly
        // straight at the player and STOP there -- a ground mob is held off by
        // its own AABB, but a phasing flyer just parks inside you, where all its
        // boxes are backface-culled and it is invisible.
        let far = dist2 > DRAGON_ORBIT * DRAGON_ORBIT;
        let v = DRAGON_Q8;
        if far {
            vx = if dx > 0 { v } else { -v };
            vz = if dz > 0 { v } else { -v };
        } else {
            // Tangent to the player: (dz, -dx), reduced to signs.
            vx = if dz > 0 { v } else { -v };
            vz = if dx > 0 { -v } else { v };
        }
    } else {
        let walk = walk_q8(m.kind);
        match m.state {
            ST_CHASE if m.kind == SKELETON => {
                // Close in until in range and in sight, back off inside 4
                // blocks, otherwise strafe round the player.
                if dist2 > SHOOT_R * SHOOT_R || !sight {
                    (vx, vz) = toward(dx, dz, walk);
                } else if dist2 < RETREAT_R * RETREAT_R {
                    (vx, vz) = toward(-dx, -dz, walk);
                } else {
                    if rng() % secs(2) as u32 == 0 {
                        m.heading ^= 1;
                    }
                    let side = if m.heading & 1 == 0 { 1 } else { -1 };
                    (vx, vz) = toward(dz * side, -dx * side, walk / 2);
                }
            }
            ST_CHASE if m.kind == SAPPER && m.fuse > 0 => {} // stands while it swells
            ST_CHASE => {
                // Java's mobs never overlap their target: entity collision
                // holds them at touching distance, half-widths summed. They
                // used to walk to within 4 units of the player's centre and
                // stand inside the camera.
                let (cdx, cdz, stop) = if tgt < CAP {
                    let t = unsafe { MOBS[tgt] };
                    (t.x - m.x, t.z - m.z, mhw + dims(t.kind).0)
                } else {
                    (dx, dz, mhw + PLAYER_HALF_W)
                };
                // An animal tempted by food stops 2.5 blocks off, as Java's
                // tempt goal does (its code; the wiki gives no figure).
                let tempted = !is_hostile(m.kind) && m.kind != WOLF;
                let far = if tempted {
                    dist2 > TEMPT_STOP * TEMPT_STOP
                } else {
                    cdx.abs() > stop || cdz.abs() > stop
                };
                if far {
                    (vx, vz) = toward(cdx, cdz, walk);
                }
            }
            ST_FLEE => {
                (vx, vz) = toward(-dx, -dz, flee_q8(m.kind));
            }
            ST_WANDER if flyer => {
                // Flyers drift on a heading and bank onto a new one now and
                // then; `timer` is their flight phase, not a stroll count.
                if rng() % secs(3) as u32 == 0 {
                    m.heading = rng() as u8;
                }
                (vx, vz) = heading_vec(m.heading, walk);
            }
            ST_WANDER => {
                if m.timer > 0 {
                    m.timer -= 1;
                    (vx, vz) = heading_vec(m.heading, walk);
                } else {
                    m.state = ST_IDLE;
                }
            }
            _ => {
                // Standing. Now and then set off on a stroll a few blocks in a
                // random direction. This used to pick a fresh random step EVERY
                // tick, so a wandering animal jittered on the spot, turning 17
                // times a second (measured), which read as a mob on fast
                // forward.
                let r = rng();
                if r % IDLE_ROLL == 0 {
                    m.heading = (r >> 12) as u8;
                    let span = (STROLL_MAX - STROLL_MIN + 1) as u32;
                    let blocks = STROLL_MIN + ((r >> 20) % span) as i32;
                    m.timer = (blocks * BLOCK * 256 / walk) as u16;
                    m.state = ST_WANDER;
                }
            }
        }
    }

    let t = (unsafe { BURN_TICK } as i32).wrapping_add(i as i32 * 37) & 255;
    let sx = dstep(vx, t);
    let sz = dstep(vz, t);
    if vx != 0 || vz != 0 {
        m.facing = face_of(vx, vz, m.facing);
    }

    // Physics: move-and-slide, gravity, jump when blocked.
    let (hw, h) = dims(m.kind);
    let mut blocked = false;
    // A flyer phases through terrain HORIZONTALLY too, not just vertically.
    // The End's obsidian pillars reach above the dragon's cruise height, so
    // with collision on it pins itself against the first one it meets and never
    // reaches the player.
    let phases = flyer;
    // Self-heal: a mob standing INSIDE terrain used to stay there forever.
    // Every move it can make is collision-checked against the position it is
    // trying to reach, and from inside a block they all fail, so it froze half
    // sunk in the world and could not be walked into or escaped from -- the
    // itch report of mobs clipped into blocks that cannot be killed. Getting
    // there is easy: build a block on top of one, or generate terrain around
    // it. Lift it out a sixteenth of a block a tick instead.
    if !phases && aabb_collides_dims(m.x, m.y, m.z, hw, h) {
        m.y += 4;
        m.vy = 0;
        unsafe {
            MOBS[i] = m;
        }
        return;
    }
    let (x0, z0) = (m.x, m.z);
    if sx != 0 {
        let nx = m.x + sx;
        if !phases && aabb_collides_dims(nx, m.y, m.z, hw, h) {
            blocked = true;
        } else {
            m.x = nx;
        }
    }
    if sz != 0 {
        let nz = m.z + sz;
        if !phases && aabb_collides_dims(m.x, m.y, nz, hw, h) {
            blocked = true;
        } else {
            m.z = nz;
        }
    }
    // A blast's shove, through the same collision tests as the walk.
    unsafe {
        if KICK_X[i] != 0 || KICK_Z[i] != 0 {
            let (kx, kz) = (KICK_X[i] >> 8, KICK_Z[i] >> 8);
            KICK_X[i] -= KICK_X[i] >> 3;
            KICK_Z[i] -= KICK_Z[i] >> 3;
            if kx != 0 {
                if aabb_collides_dims(m.x + kx, m.y, m.z, hw, h) {
                    KICK_X[i] = 0;
                } else {
                    m.x += kx;
                }
            }
            if kz != 0 {
                if aabb_collides_dims(m.x, m.y, m.z + kz, hw, h) {
                    KICK_Z[i] = 0;
                } else {
                    m.z += kz;
                }
            }
        }
    }
    // Gait: the leg phase advances with the distance actually covered, one
    // stride cycle per ~2.4 blocks as in Java's limb swing, so the legs match
    // the ground speed. Advancing only while moving is what makes the legs
    // stop when the mob does; standing, they finish the swing and come to rest
    // instead of freezing mid-stride.
    let moved = (m.x - x0).abs() + (m.z - z0).abs();
    if moved > 0 {
        m.walk = m.walk.wrapping_add(((moved * 27) >> 4).min(9) as u8);
    } else {
        let ph = m.walk & 127;
        if ph != 0 {
            m.walk = if ph < 64 {
                m.walk - ph.min(2)
            } else {
                m.walk.wrapping_add((128 - ph).min(2))
            };
        }
    }
    if flyer {
        // No gravity and no block collision: it phases through the pillars,
        // like Java's dragon. `timer` doubles as the flight phase, one weave
        // every 128 ticks (2.1 s).
        // Embers and wailers hover just off the ground rather than at the
        // dragon's cruise, which is above the Inferno roof.
        let cruise = if m.kind == DRAGON {
            DRAGON_CRUISE
        } else {
            // Two blocks over the floor beneath it, found within 8 blocks.
            // This used to be its own height plus two blocks, a target always
            // above it, so embers and wailers rose without end through the
            // Inferno roof, out of reach of the player and of contact damage.
            // Inside a block (they phase through pillars) it holds height.
            let (bx, bz) = (world_to_block_x(m.x), world_to_block_z(m.z));
            let mut fy = world_to_block_y(m.y);
            if world::get(bx, fy, bz) != crate::AIR {
                m.y
            } else {
                let lo = (fy - 8).max(1);
                while fy > lo && world::get(bx, fy - 1, bz) == crate::AIR {
                    fy -= 1;
                }
                fy * BLOCK + 2 * BLOCK
            }
        };
        let want = cruise + ((m.timer as i32 / 2 % 64) - 32) * 2;
        if m.y < want {
            m.y += 2;
        } else if m.y > want {
            m.y -= 2;
        }
        m.vy = 0;
        m.on_ground = false;
    } else {
        m.vy = (m.vy - MOB_GRAVITY).max(MOB_TERMINAL_VY);
        let ny = m.y + m.vy;
        if aabb_collides_dims(m.x, ny, m.z, hw, h) {
            if m.vy < 0 {
                m.y = (world_to_block_y(ny) + 1) * BLOCK;
                m.on_ground = true;
            }
            m.vy = 0;
        } else {
            m.y = ny;
            m.on_ground = false;
        }
    }
    if blocked {
        if m.kind == SPIDER && m.state == ST_CHASE {
            m.vy = SPIDER_CLIMB_VY; // spiders climb walls toward the player
        } else if m.on_ground {
            m.vy = MOB_JUMP_VY;
        } else if m.state == ST_WANDER && m.vy <= 0 {
            // Hopped and still blocked: a wall, not a step. Stand, and pick
            // another stroll later.
            m.state = ST_IDLE;
        }
    }

    unsafe {
        MOBS[i] = m;
    }
}

/// A hostile's melee hit on Normal difficulty (minecraft.wiki per-mob pages):
/// zombie 3, spider 2, enderman 7, blaze contact 6, wither skeleton 8, ender
/// dragon 10. Skeletons shoot and creepers explode instead of hitting. The
/// wailer (ghast) has no melee in Java; with no fireball to throw here it
/// keeps its fireball's 6 as a contact hit.
fn melee_damage(kind: u8) -> i32 {
    match kind {
        ZOMBIE => 3,
        SPIDER => 2,
        WRAITH => 7,
        EMBER => 6,
        WAILER => 6,
        CHARRED_SK => 8,
        DRAGON => 10,
        _ => 0, // skeleton, sapper
    }
}

/// Hostile contact damage to the player this frame (max over touching mobs).
pub fn contact_damage(px: i32, py: i32, pz: i32) -> i32 {
    let mut dmg = 0;
    let mut who = CAP;
    let mut i = 0;
    while i < CAP {
        unsafe {
            if MOBS[i].atk > 0 {
                MOBS[i].atk -= 1;
            }
        }
        let m = unsafe { MOBS[i] };
        let angry_wolf = m.kind == WOLF && m.love != u16::MAX && m.state == ST_CHASE;
        if m.alive && (is_hostile(m.kind) || angry_wolf) {
            let dx = (px - m.x).abs();
            let dz = (pz - m.z).abs();
            let dy = (py - m.y).abs();
            if dx < BLOCK && dz < BLOCK && dy < 2 * BLOCK {
                // A wraith (Java's enderman) is neutral until provoked.
                let d = if m.kind == WRAITH && m.state != ST_CHASE {
                    0
                } else if angry_wolf {
                    WOLF_BITE as i32
                } else {
                    melee_damage(m.kind)
                };
                // Each striking mob starts its own interval; one still waiting
                // out its last swing does no harm.
                if d > 0 && m.atk == 0 {
                    unsafe { MOBS[i].atk = MELEE_TICKS };
                    if d > dmg {
                        dmg = d;
                        who = i;
                    }
                }
            }
        }
        i += 1;
    }
    #[cfg(feature = "mob-lab")]
    unsafe {
        LAB_HITS += (dmg > 0) as u32;
        return 0;
    }
    // Tamed wolves attack what hurts their owner.
    if who < CAP {
        unsafe { PACK_TGT = who };
    }
    #[allow(unreachable_code)]
    dmg
}

/// Java Edition hitbox widths (minecraft.wiki/w/Hitbox), as half-widths in
/// world units: pig, cow and sheep 0.9, chicken 0.4, spider 1.4, wither
/// skeleton 0.7, and 0.6 for the zombie, skeleton, creeper, enderman, wolf,
/// villager and blaze. Java's heights (pig 0.9, cow 1.4, sheep 1.3, chicken
/// 0.7, zombie 1.95...) all stand taller than the models drawn here, so the
/// box stops at the top of the drawn model (dims) instead: a Java-height
/// zombie box would take hits in the air half a block over its head. The
/// ghast and the dragon are drawn far smaller than Java's 4 and 16 blocks, so
/// they keep their drawn size.
fn java_half_w(kind: u8) -> i32 {
    match kind {
        PIG | COW | SHEEP => 29,
        CHICKEN => 13,
        SPIDER => 45,
        CHARRED_SK => 22,
        _ => 19,
    }
}

/// The box the crosshair hits, as (x0, x1, z0, z1) around the mob's centre
/// and a height over its feet. Java's hitbox, widened only where the drawn
/// model reaches past it: a four-legged mob's head sticks out 3 half-widths
/// ahead of its centre (see main's render_mob), and aiming at a pig's snout
/// has to hit the pig, not the grass behind it.
fn pick_box(m: &Mob) -> (i32, i32, i32, i32, i32) {
    let (hw, h) = dims(m.kind);
    match m.kind {
        DRAGON => (-2 * hw, 2 * hw, -2 * hw, 2 * hw, h),
        ZOMBIE | SKELETON | SAPPER | WRAITH | VILLAGER | EMBER | CHARRED_SK => {
            let j = java_half_w(m.kind).max(hw);
            (-j, j, -j, j, h)
        }
        _ => {
            let j = if m.kind == WAILER { hw } else { java_half_w(m.kind).max(hw) };
            let (f, b) = (j.max(3 * hw), j.max(hw * 3 / 2));
            match m.facing {
                0 => (-j, j, -b, f, h),
                1 => (-b, f, -j, j, h),
                2 => (-j, j, -f, b, h),
                _ => (-f, b, -j, j, h),
            }
        }
    }
}

/// One axis of the slab test: narrow [t0, t1] (1/16 world units along the
/// ray) to where the ray is between `lo` and `hi`. `o` is the ray origin and
/// `d` its Q12 direction on this axis. False when the ray misses the slab.
#[inline(always)]
fn slab(o: i32, d: i32, lo: i32, hi: i32, t0: &mut i32, t1: &mut i32) -> bool {
    if d == 0 {
        return o >= lo && o <= hi;
    }
    // Offsets stay within a few hundred units (the caller rejects far mobs),
    // so << 16 keeps well inside i32: t in 1/16 units, as d is Q12.
    let (mut a, mut b) = (((lo - o) << 16) / d, ((hi - o) << 16) / d);
    if a > b {
        core::mem::swap(&mut a, &mut b);
    }
    *t0 = (*t0).max(a);
    *t1 = (*t1).min(b);
    *t0 <= *t1
}

/// The mob the crosshair is on: the nearest whose box the ray from (ox, oy,
/// oz) along the Q12 unit vector (dx, dy, dz) enters within `max_t` world
/// units, which the caller sets to the entity reach or the distance to the
/// block the ray hits, whichever is nearer. Java's rule: an entity in front
/// of the targeted block takes the crosshair (minecraft.wiki/w/Hitbox).
#[inline(never)]
pub fn ray_pick(ox: i32, oy: i32, oz: i32, dx: i32, dy: i32, dz: i32, max_t: i32) -> Option<usize> {
    let mut best = None;
    let mut best_t = max_t << 4;
    let mut i = 0;
    while i < CAP {
        let m = unsafe { &MOBS[i] };
        // Quick reject: no box reaches more than 6 blocks from its mob's
        // position (the dragon's is 5 wide a side of it).
        if m.alive
            && (m.x - ox).abs() < max_t + 6 * BLOCK
            && (m.z - oz).abs() < max_t + 6 * BLOCK
            && (m.y - oy).abs() < max_t + 6 * BLOCK
        {
            let (x0, x1, z0, z1, h) = pick_box(m);
            let (mut t0, mut t1) = (0, best_t);
            if slab(ox, dx, m.x + x0, m.x + x1, &mut t0, &mut t1)
                && slab(oy, dy, m.y, m.y + h, &mut t0, &mut t1)
                && slab(oz, dz, m.z + z0, m.z + z1, &mut t0, &mut t1)
                && t0 < best_t
            {
                best_t = t0;
                best = Some(i);
            }
        }
        i += 1;
    }
    best
}

/// Player melee on mob `best` (the crosshair target from ray_pick): damage
/// and knockback away from the player at (px, pz). True on a hit; false while
/// the mob is still invulnerable from the last one. Survivors of a passive
/// hit flee; killed mobs vanish.
pub fn strike(best: usize, px: i32, pz: i32, damage: i16) -> bool {
    let mut m = unsafe { MOBS[best] };
    if !m.alive {
        return false;
    }
    if m.hurt_cd > 0 {
        return false; // still invulnerable from the last hit
    }
    m.health -= damage;
    m.hurt_cd = HURT_TICKS;
    if m.kind == WRAITH {
        m.state = ST_CHASE; // neutral no longer: you started it
        blink(&mut m, px, pz);
    }
    // Knockback away from the player, THROUGH the same move-and-slide the AI
    // uses. It used to teleport the mob 15 units per hit with no collision
    // test at all, so a couple of swings against a wall pushed it bodily into
    // the blocks behind: it then read as clipping through the terrain, and
    // since every AI step is collision-checked it could never walk back out,
    // which is the itch report of mobs that "clip through blocks when you try
    // to attack them so it's unable to kill them".
    let (hw, h) = dims(m.kind);
    // Straight away from the attacker; it used to shove on both axes at
    // once, always at 45 degrees.
    let (kx, kz) = toward(m.x - px, m.z - pz, KNOCKBACK);
    if !aabb_collides_dims(m.x + kx, m.y, m.z, hw, h) {
        m.x += kx;
    }
    if !aabb_collides_dims(m.x, m.y, m.z + kz, hw, h) {
        m.z += kz;
    }
    if m.health <= 0 {
        record_death(&m);
        unsafe {
            XP_DROPS += xp_for(m.kind);
        }
        unsafe {
            MOBS[best] = DEAD;
        }
    } else {
        if m.kind == WOLF {
            // A wild wolf turns on whoever hits it (minecraft.wiki/w/Wolf);
            // a tamed one never does.
            if m.love != u16::MAX {
                m.state = ST_CHASE;
            }
        } else if !is_hostile(m.kind) {
            m.state = ST_FLEE;
            m.timer = FLEE_TICKS;
        }
        unsafe {
            MOBS[best] = m;
        }
    }
    // Tamed wolves attack what their owner attacks.
    if !is_tamed(best) {
        unsafe { PACK_TGT = best };
    }
    true
}

/// A tamed wolf's bite on mob `t`: 4 damage (minecraft.wiki/w/Wolf), with
/// the hit flash, knockback and, on a kill, the drops and XP a kill by the
/// player gives (Java drops them for a tamed wolf's kill too).
fn bite(t: usize, wx: i32, wz: i32) {
    let mut m = unsafe { MOBS[t] };
    if !m.alive || m.hurt_cd > 0 {
        return;
    }
    m.health -= WOLF_BITE;
    m.hurt_cd = HURT_TICKS;
    let (hw, h) = dims(m.kind);
    let (kx, kz) = toward(m.x - wx, m.z - wz, KNOCKBACK);
    if !aabb_collides_dims(m.x + kx, m.y, m.z + kz, hw, h) {
        m.x += kx;
        m.z += kz;
    }
    if m.health <= 0 {
        record_death(&m);
        unsafe {
            XP_DROPS += xp_for(m.kind);
            MOBS[t] = DEAD;
        }
    } else {
        if !is_hostile(m.kind) && m.kind != WOLF {
            m.state = ST_FLEE;
            m.timer = FLEE_TICKS;
        }
        unsafe { MOBS[t] = m };
    }
}

pub fn reset() {
    let mut i = 0;
    while i < CAP {
        unsafe {
            MOBS[i] = DEAD;
        }
        i += 1;
    }
    let mut a = 0;
    while a < ARROW_CAP {
        unsafe {
            ARROWS[a] = NO_ARROW;
        }
        a += 1;
    }
    unsafe {
        KICK_X = [0; CAP];
        KICK_Z = [0; CAP];
    }
}

/// Place one mob of `kind` on the ground at world coords (sx, sz).
fn spawn_at(kind: u8, sx: i32, sz: i32) {
    let s = match free_slot() {
        Some(s) => s,
        None => return,
    };
    let bx = world_to_block_x(sx);
    let bz = world_to_block_z(sz);
    let sy = world::surface_y(bx, bz);
    if sy < 2 || sy > 100 {
        return;
    }
    let (hw, h) = dims(kind);
    let feet = sy * BLOCK;
    if aabb_collides_dims(sx, feet, sz, hw, h) {
        return;
    }
    unsafe {
        MOBS[s] = Mob {
            kind,
            alive: true,
            on_ground: false,
            x: sx,
            y: feet,
            z: sz,
            vy: 0,
            health: max_health(kind),
            state: ST_IDLE,
            timer: 0,
            fuse: 0,
            hurt_cd: 0,
            atk: 0,
            love: 0,
            cool: 0,
            walk: 0,
            facing: 0,
            heading: 0,
            fire: 0,
            charged: false,
        };
    }
}

/// Cheat menu: stand a `kind` at (x, z) on the first clear height at or up
/// to three blocks over `y`. A full roster gives up its first non-dragon
/// slot, so the cheat always spawns.
pub fn cheat_spawn(kind: u8, x: i32, y: i32, z: i32) {
    let s = free_slot().unwrap_or(if unsafe { MOBS[0].kind } == DRAGON { 1 } else { 0 });
    let (hw, h) = dims(kind);
    let mut feet = y;
    let mut k = 0;
    while k < 3 && aabb_collides_dims(x, feet, z, hw, h) {
        feet += BLOCK;
        k += 1;
    }
    unsafe {
        MOBS[s] = Mob {
            kind,
            alive: true,
            x,
            y: feet,
            z,
            health: max_health(kind),
            ..DEAD
        };
    }
}

/// Seed a few passive mobs in front of the player (+Z at spawn) at world start.
/// Despawn everything (mobs + arrows) -- the "NEW WORLD" reset. A new world
/// has its dragon back.
pub fn clear() {
    unsafe {
        MOBS = [DEAD; CAP];
        ARROWS = [NO_ARROW; ARROW_CAP];
        KICK_X = [0; CAP];
        KICK_Z = [0; CAP];
        DRAGON_SLAIN = false;
    }
}

/// Everything the mob system carries between ticks, back to a cold boot's
/// values: the roster and arrows, the wolves parked in other dimensions, the
/// pack target, the spawn timer and generator, pending XP and deaths. Quitting
/// to the title screen (main.rs `reset_session`).
#[inline(never)]
#[optimize(size)]
pub fn reset_session() {
    clear();
    reset();
    unsafe {
        PARKED = [NO_PARKED; TAMED_CAP];
        PACK_TGT = CAP;
        SIGHT = [false; CAP];
        HAZARD_DMG = 0;
        SPAWN_TIMER = secs(2) as u16;
        RNG = LcgRng::new(0x1234_5678);
        XP_DROPS = 0;
        DEATH_N = 0;
        LURE = 0;
        SPAWN_MONSTER = false;
        BURN_TICK = 0;
        RAINING = false;
    }
}

/// Mobs alive, for the settings receipt.
pub fn alive_count() -> u32 {
    let mut n = 0;
    let mut i = 0;
    while i < CAP {
        if unsafe { MOBS[i].alive } {
            n += 1;
        }
        i += 1;
    }
    n
}

pub fn populate(px: i32, pz: i32) {
    let mut k = 0i32;
    while k < 4 {
        spawn_at(
            (k as u8) % 4,
            px + (k - 2) * 2 * BLOCK,
            pz + (4 + k) * BLOCK,
        );
        k += 1;
    }
}
