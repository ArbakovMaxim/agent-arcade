/* SKYHAUL / Sega Master System. Gameplay adapted from ABA Games (MIT).
 * 12.4 fixed point; no heap, no float, no framebuffer. See README.md.
 */
#include "SMSlib.h"
#include "assets.h"
typedef unsigned char u8;
typedef signed char s8;
typedef unsigned int u16;
typedef signed int s16;
typedef unsigned long u32;
#define FP(x) ((s16)(x)<<4)
#define NH 16
#define TITLE 0
#define READY 1
#define PLAY 2
#define DYING 3
#define CLEAR 4
#define BONUS 5
#define OVER 6
#define WIN 7
#define GROUND 0
#define CHAIN 1
#define FALL 2
#define DONE 3
#define CARRIED 4
#define WAITING 5
#define UP PORT_A_KEY_UP
#define DOWN PORT_A_KEY_DOWN
#define LEFT PORT_A_KEY_LEFT
#define RIGHT PORT_A_KEY_RIGHT
#define BUTTONS (PORT_A_KEY_1|PORT_A_KEY_2)

/* All authoritative state is exported for the ROM test harness. */
u8 state, round_no, planet, lives, paused, dirty, bonus_mode;
u8 human_count, left_count, chain_count, haul_weight, invuln, hot, hatch_open;
u8 has_rescuer, has_bomber, turret_count, heavy_every, ace;
u8 delivered_total, cuts_total, rescues_total, stolen_total;
u8 ground[32], chain[NH], band[24];
u16 clock_ticks, state_ticks, round_ticks, hot_limit, bonus_ticks;
u16 loop_count, keys, previous_keys, pressed;
u32 score, high_score, next_extend;
s16 px, py, pvx, pvy, hook_x, hook_y;
s16 dx, dy, laser_x, laser_y, bx, by, rx, ry;
s8 ddir, bdir;
u16 dcool, rcool, bdrop;
u8 dcharge, laser_life, rcarry;
s8 laser_dir;
u8 sfx_ticks, sfx_kind;
u16 sound_pitch;
char hud[2][33];
u8 hud_line;
volatile u8 vblank_count;
u8 presented_frame;
void frame_irq(void){++vblank_count;}

typedef struct { s16 x,y,vx; u8 state,weight,cool; } Human;
Human humans[NH];
typedef struct { s16 x,y; u16 age; } Mine;
Mine mines[3];
typedef struct { u8 x,charge,beam,top; u16 cool; } Turret;
Turret turrets[3];
const u8 hot_seconds[8]={50,55,60,85,85,85,115,115};
const u8 speeds[25]={44,40,36,34,32,30,28,26,24,22,22,20,20,18,18,16,16,16,14,14,14,14,12,12,12};
const char * const planets[4]={"VERDA","OCHRE","CINDER","VOID"};
const char * const names[8]={"FIRST CONTACT","THE RESCUER","HEAVY LIFT","MINES","GUNS","ACE","CROSSFIRE","SIEGE"};
const u8 bg_palette[16]={RGB(0,0,0),RGB(3,3,3),RGB(3,0,0),RGB(1,3,1),RGB(0,3,3),RGB(1,3,1),RGB(0,1,0),RGB(1,1,1),RGB(2,2,2),0,0,0,0,0,0,RGB(3,3,3)};
const u8 sp_palette[16]={0,RGB(1,3,1),RGB(3,1,1),RGB(0,3,3),RGB(3,1,3),RGB(3,3,0),RGB(1,1,1),RGB(1,2,3),RGB(2,2,2),0,0,0,0,0,0,RGB(3,3,3)};
__sfr __at(0x7f) PSG;

s16 abs16(s16 x){return x<0?-x:x;}
s16 clamp(s16 n,s16 a,s16 b){if(n<a)return a;if(n>b)return b;return n;}
u8 ground_at(s16 x){return ground[(u8)clamp(x,0,255)>>3];}
u8 ground_under(s16 x){u8 a=ground_at(x-6),b=ground_at(x+6);return a<b?a:b;}
void text(u8 x,u8 y,const char *s,u16 flags){SMS_setNextTileatXY(x,y);while(*s)SMS_setTile((u8)*s++|flags);}
void centered(u8 y,const char*s,u16 f){const char*p=s;u8 n=0;while(*p++){n++;}text((32-n)>>1,y,s,f);}
const u32 powers[7]={1UL,10UL,100UL,1000UL,10000UL,100000UL,1000000UL};
void digits(char*p,u32 n,u8 len){u32 d;u8 c;while(len){d=powers[--len];c='0';while(n>=d){n-=d;++c;}*p++=c;}}
void silence(void){PSG=0x9f;PSG=0xbf;PSG=0xdf;PSG=0xff;}
void sound(u8 kind){sfx_kind=kind;sfx_ticks=kind==4?45:kind==3?32:12;}
void audio_tick(void){
    if(sfx_ticks){
        --sfx_ticks;
        if(sfx_kind==1)sound_pitch=150-(haul_weight<<2)-(sfx_ticks<<2);
        else if(sfx_kind==2)sound_pitch=120+((16-sfx_ticks)<<4);
        else if(sfx_kind==3)sound_pitch=100+((sfx_ticks&7)<<4);
        else sound_pitch=350+((45-sfx_ticks)<<3);
        PSG=0x80|(sound_pitch&15);PSG=sound_pitch>>4;PSG=0x93;
        if(sfx_kind==4){PSG=0xe6;PSG=0xf5+(sfx_ticks<15?6:0);}
    }else{PSG=0x9f;PSG=0xff;}
    if(chain_count && (state==PLAY||state==BONUS)&&!paused){
        sound_pitch=550+(haul_weight<<4);PSG=0xa0|(sound_pitch&15);PSG=sound_pitch>>4;
        PSG=(clock_ticks&8)?0xbd:0xbf;
    }else PSG=0xbf;
}
void add_score(u16 n){score+=n;if(score>9999999UL)score=9999999UL;if(score>high_score)high_score=score;
    if(score>=next_extend){next_extend+=30000UL;if(lives<9)++lives;sound(3);}}
void weight(void){u8 i;haul_weight=0;for(i=0;i<chain_count;++i)haul_weight+=humans[chain[i]].weight;}
void cut_chain(u8 first){u8 i;Human*h;if(first>=chain_count)return;
    for(i=first;i<chain_count;++i){h=&humans[chain[i]];h->state=FALL;h->cool=12;h->vx=0;}
    chain_count=first;weight();++cuts_total;sound(2);
}
void die(void){if(invuln||state!=PLAY)return;cut_chain(0);--lives;state=DYING;state_ticks=43;dirty=1;sound(4);}
void respawn(void){px=FP(128);py=FP(62);pvx=pvy=0;hook_x=px;hook_y=py+FP(9);invuln=60;}
void stage_start(u8 bonus){
    u8 i;Human*h;bonus_mode=bonus;planet=(round_no-1)>>1;
    has_rescuer=!bonus&&(round_no==2||round_no==3||round_no==8);
    has_bomber=!bonus&&(round_no==4||round_no==7||round_no==8);
    turret_count=bonus?0:(round_no==5||round_no==7?3:round_no==8?2:0);
    heavy_every=(!bonus&&(round_no==3||round_no==4||round_no==7))?4:(!bonus&&round_no==5)?5:0;
    ace=round_no==6||round_no==8;
    for(i=0;i<32;++i){
        ground[i]=176;
        if(planet==1){if((i>=4&&i<=10)||(i>=23&&i<=28))ground[i]=168;}
        if(planet==2){if((i>=6&&i<=10)||(i>=23&&i<=27))ground[i]=152;}
        if(planet==3){if(i<6||i>26)ground[i]=152;else if(i==6||i==26)ground[i]=160;}
        if(bonus)ground[i]=184;
    }
    human_count=bonus?12:8+(planet<<1);left_count=human_count;
    chain_count=haul_weight=0;round_ticks=0;hot=0;hot_limit=(u16)hot_seconds[round_no-1]*30;
    bonus_ticks=720;hatch_open=1;
    for(i=0;i<NH;++i){h=&humans[i];h->x=FP(16+(u16)i*224/human_count);h->y=FP(ground_at(((u16)h->x)>>4)-4);
        h->vx=0;h->state=i<human_count?(bonus?WAITING:GROUND):DONE;
        h->weight=(heavy_every&&((i+1)%heavy_every)==0)?2:1;h->cool=0;}
    dx=FP(20);dy=FP(92);ddir=1;dcool=round_no==1?120:75;dcharge=laser_life=0;
    rx=FP(224);ry=FP(90);rcarry=255;rcool=120;
    bx=FP(8);by=FP(94);bdir=1;bdrop=70;
    for(i=0;i<3;++i){mines[i].age=0;turrets[i].x=(turret_count==2)?(i?208:48):(i==0?56:i==1?128:200);
        turrets[i].cool=30;turrets[i].charge=turrets[i].beam=0;turrets[i].top=48;}
    respawn();state=READY;state_ticks=50;dirty=1;sound(3);
}
void new_game(void){score=0;next_extend=10000;round_no=1;lives=3;paused=0;delivered_total=cuts_total=rescues_total=stolen_total=0;stage_start(0);}
void deliver(void){
    u8 i;u16 payout;if(!chain_count)return;
    payout=(u16)haul_weight*haul_weight*100;
    for(i=0;i<chain_count;++i){humans[chain[i]].state=DONE;++delivered_total;--left_count;}
    chain_count=haul_weight=0;add_score(payout);sound(3);
}
void player_tick(void){
    s16 tx=0,ty=0,v;u8 g;
    v=speeds[haul_weight>24?24:haul_weight];
    if(keys&LEFT)tx=-v;if(keys&RIGHT)tx=v;if(keys&UP)ty=-v;if(keys&DOWN)ty=v;
    /* Rounded acceleration avoids the +/-1 fixed-point stall. */
    if(pvx<tx)pvx+=4;else if(pvx>tx)pvx-=4;
    if(pvy<ty)pvy+=4;else if(pvy>ty)pvy-=4;
    px=clamp(px+pvx,FP(7),FP(248));
    g=ground_under(((u16)px)>>4);if(py>FP(g-10))py=FP(g-10);
    py=clamp(py+pvy,FP(46),FP(g-10));
    hook_x+=((px-hook_x)>>1);hook_y=py+FP(9);
    if(invuln)--invuln;
}
void human_tick(void){
    u8 i;Human*h; s16 ax=hook_x,ay=hook_y,len,delta,tipx,tipy,goal;
    for(i=0;i<chain_count;++i){
        h=&humans[chain[i]];len=h->weight==2?12:9;
        h->vx+=((ax-h->x)>>4)-(h->vx>>3);
        h->vx=clamp(h->vx,-28,28);h->x+=h->vx;
        h->x=clamp(h->x,ax-FP(len-2),ax+FP(len-2));h->x=clamp(h->x,FP(3),FP(252));
        delta=abs16(h->x-ax);goal=ay+FP(len)-(delta>>1);
        h->y+=(goal-h->y)>>1;goal=FP(ground_at(((u16)h->x)>>4)-4);if(h->y>goal)h->y=goal;
        ax=h->x;ay=h->y;
    }
    tipx=ax>>4;tipy=ay>>4;
    for(i=0;i<human_count;++i){
        h=&humans[i];if(h->cool)--h->cool;
        if(h->state==WAITING){if((u16)i*45<=720-bonus_ticks){h->state=FALL;h->y=FP(56);h->cool=0;}else continue;}
        if(h->state==GROUND){
            if((clock_ticks&7)==(i&7)){h->x+=(i&1)?16:-16;if(h->x<FP(9))h->x=FP(240);if(h->x>FP(246))h->x=FP(16);}
            h->y=FP(ground_at(((u16)h->x)>>4)-4);
        }else if(h->state==FALL){
            h->y+=h->weight==2?28:(bonus_mode?6:12);
            goal=FP(ground_at(((u16)h->x)>>4)-4);if(h->y>=goal){h->y=goal;h->state=GROUND;}
        }
        if((h->state==GROUND||h->state==FALL||h->state==CARRIED)&&!h->cool&&chain_count<NH){
            if(abs16((((u16)h->x)>>4)-tipx)<10&&abs16((((u16)h->y)>>4)-tipy)<10){
                if(h->state==CARRIED){rcarry=255;rcool=120;++stolen_total;}
                h->state=CHAIN;h->vx=0;chain[chain_count++]=i;weight();sound(1);
                tipx=((u16)h->x)>>4;tipy=((u16)h->y)>>4;
            }
        }
    }
    /* Hatch is a forgiving funnel; no grab or delivery button. */
    if(chain_count&&hatch_open&&abs16((((u16)px)>>4)-128)<13&&(((u16)py)>>4)<=49)deliver();
}
/* A shot tests both the bodies and the links between them. */
void horizontal_hit(s16 x0,s16 x1,s16 y){
    u8 i;Human*h; s16 ax=((u16)px)>>4,ay=(((u16)py)>>4)+3,bxx,byy;
    if(state!=PLAY)return;
    if(abs16((((u16)py)>>4)-y)<6&&(((u16)px)>>4)>=x0-6&&(((u16)px)>>4)<=x1+6){die();if(state!=PLAY)return;}
    for(i=0;i<chain_count;++i){h=&humans[chain[i]];bxx=((u16)h->x)>>4;byy=((u16)h->y)>>4;
        if(y>=ay-3&&y<=byy+4&&((ax>=x0-3&&ax<=x1+3)||(bxx>=x0-3&&bxx<=x1+3))){cut_chain(i);return;}
        ax=bxx;ay=byy;
    }
}
void defender_tick(void){
    u8 i,target=255;Human*h;s16 tx=px,ty=py,speed=30+(planet<<2),climb=10+planet,row;
    if(ace){speed+=14;climb+=6;}if(hot){speed+=14;climb+=8;}
    /* Rescue falling captives instead of blindly hunting the player. */
    for(i=0;i<human_count;++i)if(humans[i].state==FALL&&!humans[i].cool){target=i;break;}
    if(target!=255){h=&humans[target];tx=h->x;ty=h->y;dcharge=0;
        if(abs16(dx-tx)<FP(13)&&abs16(dy-ty)<FP(10)){
            h->state=GROUND;h->x=FP(dx<FP(128)?228:28);h->y=FP(ground_at(((u16)h->x)>>4)-4);h->cool=15;dcool=38;++rescues_total;
        }
    }else if(chain_count&&((clock_ticks>>6)&1))ty=humans[chain[chain_count>>1]].y;
    if(!dcharge){
        if(ddir>0&&dx>tx+FP(44))ddir=-1;else if(ddir<0&&dx<tx-FP(44))ddir=1;
        if(abs16(tx-dx)>FP(35)){if(dy<ty)dy+=climb;else dy-=climb;}
    }
    dx+=ddir*speed;
    if(dx<FP(10)){dx=FP(10);ddir=1;}if(dx>FP(246)){dx=FP(246);ddir=-1;}
    row=FP(ground_under((((u16)dx)>>4)+ddir*12)-10);if(dy>row){dy=row;dcharge=0;}
    dy=clamp(dy,FP(56),FP(174));
    if(dcool)--dcool;
    if(dcharge){if(!--dcharge){laser_x=dx;laser_y=dy;laser_dir=ddir;laser_life=24;dcool=(round_no==1?96:ace?39:60);if(hot)dcool-=15;sound(2);}}
    else if(!dcool&&target==255&&abs16(ty-dy)<FP(7)&&abs16(tx-dx)<FP(150)){dcharge=12;}
    if(abs16(px-dx)<FP(12)&&abs16(py-dy)<FP(6))die();
    horizontal_hit((((u16)dx)>>4)-9,(((u16)dx)>>4)+9,((u16)dy)>>4);
    if(laser_life){
        --laser_life;laser_x+=laser_dir*160;
        if(laser_x<FP(-40)||laser_x>FP(290)){laser_life=0;return;}
        row=laser_y>>4;if(row>=ground_at(laser_x>>4)){laser_life=0;return;}
        if(laser_dir>0)horizontal_hit((laser_x>>4)-28,laser_x>>4,row);
        else horizontal_hit(laser_x>>4,(laser_x>>4)+28,row);
    }
}
void rescuer_tick(void){
    u8 i,target=255;Human*h; s16 tx,ty;
    if(!has_rescuer)return;if(rcool)--rcool;
    if(rcarry!=255){h=&humans[rcarry];tx=FP(px<FP(128)?234:20);ty=FP(ground_at(tx>>4)-18);
        h->x=rx;h->y=ry+FP(9);
        if(abs16(rx-tx)<FP(8)&&abs16(ry-ty)<FP(7)){h->state=FALL;h->cool=12;rcarry=255;rcool=120;}
    }else{
        if(!rcool){for(i=0;i<human_count;++i)if(humans[i].state==FALL&&!humans[i].cool){target=i;break;}
            if(target==255&&chain_count>=2)target=chain[chain_count-1];}
        if(target!=255){h=&humans[target];tx=h->x;ty=h->y-FP(8);
            if(abs16(rx-tx)<FP(8)&&abs16(ry-ty)<FP(8)){
                if(h->state==CHAIN)cut_chain(chain_count-1);
                h->state=CARRIED;h->cool=12;rcarry=target;++rescues_total;
            }
        }else{tx=FP((clock_ticks&256)?220:36);ty=FP(88);}
    }
    if(rx<tx)rx+=18;else rx-=18;if(ry<ty)ry+=14;else ry-=14;
}
void bomber_tick(void){
    u8 i,j;Mine*m;Human*h;
    if(has_bomber){
        bx+=bdir*14;if(bx>FP(250)){bdir=-1;by=FP(118);}if(bx<FP(5)){bdir=1;by=FP(82);}
        if(bdrop)--bdrop;else{bdrop=84;
            for(i=0;i<3;++i)if(!mines[i].age){if(abs16(bx-px)+abs16(by-py)>FP(40)){mines[i].x=bx;mines[i].y=by+FP(8);mines[i].age=1;}break;}}
        if(abs16(px-bx)<FP(13)&&abs16(py-by)<FP(7))die();
        horizontal_hit((((u16)bx)>>4)-8,(((u16)bx)>>4)+8,((u16)by)>>4);
    }
    if(!has_bomber)return;
    for(i=0;i<3;++i){m=&mines[i];if(!m->age)continue;if(++m->age>360){m->age=0;continue;}if(m->age<18)continue;
        if(abs16(px-m->x)<FP(9)&&abs16(py-m->y)<FP(7)){die();m->age=0;continue;}
        for(j=0;j<chain_count;++j){h=&humans[chain[j]];
            if(abs16(h->x-m->x)<FP(7)&&abs16(h->y-m->y)<FP(10)){cut_chain(j);m->age=0;break;}}
    }
}
void turret_tick(void){
    u8 i,j;Turret*t;Human*h;u8 hit;
    for(i=0;i<turret_count;++i){t=&turrets[i];if(t->beam)--t->beam;if(t->cool)--t->cool;
        if(t->charge){if(!--t->charge){
            t->cool=78;t->beam=7;t->top=44;hit=0;
            for(j=chain_count;j>0;--j){h=&humans[chain[j-1]];if(abs16((((u16)h->x)>>4)-t->x)<8){t->top=((u16)h->y)>>4;cut_chain(j-1);hit=1;break;}}
            if(!hit&&abs16((((u16)px)>>4)-t->x)<6){t->top=((u16)py)>>4;die();}sound(2);
        }}else if(!t->cool&&abs16((((u16)px)>>4)-t->x)<22)t->charge=18;
    }
}
void gameplay_tick(void){
    ++round_ticks;
    if(bonus_mode){if(bonus_ticks)--bonus_ticks;
        if(!bonus_ticks){cut_chain(0);state=CLEAR;state_ticks=70;dirty=1;return;}}
    else if(round_ticks>=hot_limit)hot=1;
    hatch_open=1;
    if(!bonus_mode&&(round_no==5||round_no==7)){u16 period=round_no==5?144:138;u16 phase=round_ticks%period;hatch_open=phase<(round_no==5?96:84);}
    player_tick();human_tick();
    if(!bonus_mode){defender_tick();if(state==PLAY)rescuer_tick();if(state==PLAY)bomber_tick();if(state==PLAY)turret_tick();}
    if(!left_count&&(state==PLAY||state==BONUS)){
        if(bonus_mode)add_score(5000);else{add_score(1000);if(!hot)add_score(((hot_limit-round_ticks)/30)*50);}
        state=CLEAR;state_ticks=73;dirty=1;sound(3);
    }
}
void logic(void){
    if(state==TITLE){if(pressed&BUTTONS)new_game();return;}
    if(state==OVER||state==WIN){if(state_ticks){--state_ticks;return;}if(pressed&BUTTONS){state=TITLE;dirty=1;}return;}
    if(SMS_queryPauseRequested()){SMS_resetPauseRequest();paused=!paused;dirty=1;}
    if(pressed&PORT_A_KEY_2){paused=!paused;dirty=1;}
    if(paused)return;
    if(state==READY){if(!--state_ticks){state=bonus_mode?BONUS:PLAY;dirty=1;}return;}
    if(state==DYING){if(!--state_ticks){if(lives){respawn();state=READY;state_ticks=38;dirty=1;}else{state=OVER;state_ticks=38;dirty=1;silence();}}return;}
    if(state==CLEAR){if(!--state_ticks){
        if(round_no==8){add_score((u16)lives*5000);state=WIN;state_ticks=60;dirty=1;}
        else if(!bonus_mode&&!(round_no&1))stage_start(1);
        else{++round_no;stage_start(0);}
    }return;}
    gameplay_tick();
}
void clear_screen(void){u16 i;SMS_setNextTileatXY(0,0);for(i=0;i<768;++i)SMS_setTile(0);}
void stars(void){u8 i,x,y;for(i=0;i<38;++i){x=(i*23+7)&31;y=3+(i*11)%18;SMS_setTileatXY(x,y,93);}}
void paint(void){
    u8 x,y;SMS_displayOff();clear_screen();SMS_loadBGPalette(bg_palette);stars();
    if(state==TITLE){
        for(y=0;y<4;++y){SMS_setNextTileatXY(5,y+4);for(x=0;x<21;++x)SMS_setTile(128+(u16)y*21+x);}
        centered(2,"ABA GAMES / SMS EDITION",0);
        centered(9,"YOU ARE THE LANDER",TILE_USE_SPRITE_PALETTE);
        centered(12,"FLY. ABDUCT. HAUL HOME.",0);
        centered(14,"D-PAD TO FLY",0);
        centered(15,"TOUCH HUMANS TO HOOK THEM",0);
        centered(16,"FLY INTO THE GREEN HATCH",0);
        centered(18,"BIGGER CHAINS = BIGGER SCORE",TILE_USE_SPRITE_PALETTE);
        centered(21,"PRESS BUTTON 1 OR 2",0);
        centered(23,"ORIGINAL GAME BY ABA GAMES",0);
    }else if(state==OVER||state==WIN){
        centered(5,state==WIN?"MISSION COMPLETE":"GAME OVER",TILE_USE_SPRITE_PALETTE);
        centered(8,state==WIN?"ALL FOUR PLANETS CLEARED":"THE HERO SAVED THE DAY",0);
        centered(11,"YOUR SCORE",0);centered(15,"HIGH SCORE",0);
        {char n[8];n[7]=0;digits(n,score,7);centered(12,n,TILE_USE_SPRITE_PALETTE);digits(n,high_score,7);centered(16,n,0);}
        centered(20,"PRESS 1 OR 2 FOR TITLE",0);
    }else{
        if(planet==1){SMS_setBGPaletteColor(5,RGB(3,2,0));SMS_setBGPaletteColor(6,RGB(1,1,0));}
        if(planet==2){SMS_setBGPaletteColor(5,RGB(3,1,0));SMS_setBGPaletteColor(6,RGB(1,0,0));}
        if(planet==3){SMS_setBGPaletteColor(5,RGB(2,1,3));SMS_setBGPaletteColor(6,RGB(1,0,1));}
        for(x=0;x<32;++x){for(y=ground[x]>>3;y<24;++y)SMS_setTileatXY(x,y,y==(ground[x]>>3)?91:92);}
        for(y=0;y<2;++y){SMS_setNextTileatXY(13,3+y);for(x=0;x<6;++x)SMS_setTile(214+y*6+x);}
        if(paused){centered(10,"PAUSED",0);centered(12,"BUTTON 2 TO RESUME",0);}
        else if(state==READY){
            centered(9,bonus_mode?"BONUS DROP":planets[planet],TILE_USE_SPRITE_PALETTE);
            centered(11,bonus_mode?"24 SECONDS - NO ENEMIES":names[round_no-1],0);
            centered(13,bonus_mode?"CATCH THEM ALL FOR 5000":"GET READY",0);
        }else if(state==CLEAR){centered(10,bonus_mode?(left_count?"BONUS OVER":"PERFECT! +5000"):"ROUND CLEAR",TILE_USE_SPRITE_PALETTE);
            centered(12,"HAUL DELIVERED",0);}
        else if(state==DYING){centered(10,"LANDER LOST",0);}
        
    }
    SMS_displayOn();dirty=0;
}
/* Conservative sprite admission for the real 8 sprites / scanline limit.
 * Order rotates for ground humans so crowded rows multiplex rather than vanish.
 * Bands may reject a little early, never late. Player is always first.
 */
void sprite(s16 x,s16 y,u8 tile){
    u8 b,c;if(x<0||x>248||y<16||y>183)return;b=(u8)y>>3;c=((u8)y+7)>>3;
    if(band[b]>=8||band[c]>=8)return;++band[b];if(c!=b)++band[c];SMS_addSprite((u8)x,(u8)y,tile);
}
void craft(s16 x,s16 y,u8 t){sprite(x-8,y-4,t);sprite(x,y-4,t+1);}
void draw(void){
    u8 i,j,n; s16 x,y;Human*h;Turret*t;
    SMS_initSprites();for(i=0;i<24;++i)band[i]=0;
    if(state==TITLE){craft(128,86,96);}
    else if(state!=OVER&&state!=WIN){
        if(state==DYING){sprite((((u16)px)>>4)-4,(((u16)py)>>4)-4,110);}
        else if(!invuln||(clock_ticks&4)||state==READY)craft(((u16)px)>>4,((u16)py)>>4,96);
        if(state!=DYING)sprite((((u16)hook_x)>>4)-4,(((u16)hook_y)>>4)-4,102);
        for(i=0;i<chain_count;++i){h=&humans[chain[i]];x=((u16)h->x)>>4;y=((u16)h->y)>>4;
            sprite(x-4,y-4,h->weight==2?101:100);if(i||y>(((u16)hook_y)>>4)+7)sprite(x-4,y-11,102);}
        if(!bonus_mode){
            craft(((u16)dx)>>4,((u16)dy)>>4,ddir>0?98:112);
            if(dcharge&&(clock_ticks&4)){sprite((((u16)dx)>>4)+(ddir>0?12:-20),(((u16)dy)>>4)-4,110);}
            if(laser_life){x=laser_x>>4;y=laser_y>>4;for(i=0;i<4;++i)sprite(x-laser_dir*(i<<3)-4,y-4,103);}
            if(has_rescuer)craft(((u16)rx)>>4,((u16)ry)>>4,107);
            if(has_bomber)craft(((u16)bx)>>4,((u16)by)>>4,105);
            for(i=0;i<3;++i)if(mines[i].age&&(mines[i].age>=18||(clock_ticks&8)))sprite((mines[i].x>>4)-4,(mines[i].y>>4)-4,104);
            for(i=0;i<turret_count;++i){t=&turrets[i];sprite(t->x-4,ground_at(t->x)-8,t->charge&&(clock_ticks&4)?110:109);
                if(t->beam||(t->charge&&(clock_ticks&8))){for(y=t->top;y<ground_at(t->x)-8;y+=16)sprite(t->x-4,y,t->beam?110:102);}}
        }
        n=(clock_ticks>>1)%human_count;
        for(j=0;j<human_count;++j){i=n+j;if(i>=human_count)i-=human_count;h=&humans[i];
            if(h->state==GROUND||h->state==FALL||h->state==CARRIED){x=((u16)h->x)>>4;y=((u16)h->y)>>4;sprite(x-4,y-4,h->weight==2?101:100);
                if(bonus_mode&&h->state==FALL)sprite(x-4,y-12,111);}}
    }
    SMS_finalizeSprites();
}
void compose_hud(void){
    u8 i;u16 secs;for(i=0;i<32;++i){hud[0][i]=' ';hud[1][i]=' ';}hud[0][32]=hud[1][32]=0;
    hud[0][0]='1';hud[0][1]='U';hud[0][2]='P';digits(&hud[0][4],score,7);
    hud[0][13]='H';hud[0][14]='I';digits(&hud[0][16],high_score,7);
    hud[0][25]='R';hud[0][26]='D';hud[0][28]='0'+round_no;
    hud[1][0]='S';hud[1][1]='H';hud[1][2]='P';hud[1][4]='0'+lives;
    hud[1][6]='L';hud[1][7]='E';hud[1][8]='F';hud[1][9]='T';digits(&hud[1][11],left_count,2);
    hud[1][14]='+';digits(&hud[1][15],(u16)haul_weight*haul_weight*100,5);
    if(hot){hud[1][25]='H';hud[1][26]='O';hud[1][27]='T';}
    else{secs=bonus_mode?bonus_ticks/30:round_ticks<hot_limit?(hot_limit-round_ticks)/30:0;
        digits(&hud[1][25],secs,3);hud[1][28]='S';}
}
void main(void){
    SMS_displayOff();SMS_loadTiles(tiles,0,sizeof(tiles));SMS_loadBGPalette(bg_palette);SMS_loadSpritePalette(sp_palette);
    SMS_useFirstHalfTilesforSprites(1);SMS_setSpriteMode(SPRITEMODE_NORMAL);
    SMS_setBackdropColor(0);SMS_setFrameInterruptHandler(frame_irq);silence();state=TITLE;dirty=1;high_score=0;
    for(;;){
        keys=SMS_getKeysStatus();pressed=keys&~previous_keys;previous_keys=keys;
        ++clock_ticks;++loop_count;logic();
        if(dirty){paint();compose_hud();}
        if(state!=TITLE&&state!=OVER&&state!=WIN && !(clock_ticks&7))compose_hud();
        draw();audio_tick();
        do {SMS_waitForVBlank();} while((u8)(vblank_count-presented_frame)<2);
        presented_frame=vblank_count;SMS_copySpritestoSAT();
        if(state!=TITLE&&state!=OVER&&state!=WIN){
            text(0,hud_line,hud[hud_line],hud_line?TILE_USE_SPRITE_PALETTE:0);hud_line^=1;
            SMS_setTileatXY(15,4,hatch_open?94:95);SMS_setTileatXY(16,4,hatch_open?94:95);
        }
    }
}
SMS_EMBED_SEGA_ROM_HEADER(9999,0);
SMS_EMBED_SDSC_HEADER_AUTO_DATE(1,0,"ABA Games / SMS port","SKYHAUL","Role-reversed arcade abduction. Eight rounds, four planets.");
