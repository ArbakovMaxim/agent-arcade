import { SMS } from '../vendor/miracle/src/sms.generated.js';
import { SoundChip } from '../vendor/miracle/src/soundchip.js';
window.Miracle={SMS,SoundChip};
