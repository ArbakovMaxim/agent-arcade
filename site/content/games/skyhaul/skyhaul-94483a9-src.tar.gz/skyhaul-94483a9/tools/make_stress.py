#!/usr/bin/env python3
from pathlib import Path
import runpy
m=runpy.run_path('tools/make_tests.py')
ls=m['lines'];ls.clear();emit=m['emit'];poke=m['poke'];field=m['field'];human=m['human']
emit('symbols rom/skyhaul.noi\nrun 160\nhold 1\nrun 6\nhold none\nwaituntil state == 2 180 w1\nrun 14')
poke('invuln',250);poke('loop_count',0,'w2')
emit('run 120\nprint loop_count w2\nexpect loop_count >= 54 w2')
m['fixture_stage'](7)
for n,v in [('px',80*16),('py',46*16),('pvx',0),('pvy',0),('dcool',255)]:poke(n,v,'w2')
for i in range(14):
 human(i,80,min(173,64+i*9),state=1,weight=2 if i%4==3 else 1)
 field('chain',i,i)
poke('chain_count',14);poke('haul_weight',17)
for i in range(3):field('turrets',i*6+4,255,'w2')
poke('loop_count',0,'w2')
emit('run 120\nprint loop_count w2\nprint chain_count w1\nexpect loop_count >= 30 w2\nexpectvdp display 1\nexpectcolors 8\nscreenshot shots/stress.ppm')
Path('tests/stress.txt').write_text('\n'.join(ls)+'\n')
