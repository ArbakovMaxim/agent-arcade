const fs=require('fs'),{chromium}=require('playwright');
const symbols=Object.fromEntries(fs.readFileSync('rom/skyhaul.noi','utf8').split('\n').filter(l=>l.startsWith('DEF ')).map(l=>{let p=l.split(/\s+/);return[p[1].replace(/^_/,''),parseInt(p[2],16)]}));
(async()=>{const browser=await chromium.launch({headless:true,args:['--autoplay-policy=no-user-gesture-required']});const page=await browser.newPage({viewport:{width:1180,height:1000}});let errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://localhost:8000/Skyhaul.html');await page.waitForTimeout(2800);
const read=async(name)=>page.evaluate(a=>sms.getBus().readbyte(a),symbols[name]);
if(await read('state')!==0)throw Error('not title');
await page.click('#start');await page.waitForTimeout(1900);
if(await read('state')!==2)throw Error('not play');
await page.keyboard.down('ArrowDown');await page.waitForTimeout(1500);await page.keyboard.up('ArrowDown');await page.waitForTimeout(120);
console.log('after real flight: chain',await read('chain_count'),'lives',await read('lives'));
await page.keyboard.down('KeyP');await page.waitForTimeout(120);await page.keyboard.up('KeyP');await page.waitForTimeout(200);
if(await read('paused')!==1)throw Error('not paused');
console.log('PSG levels',await page.evaluate(()=>Array.from(soundChip.volume)));
await page.click('#reset');await page.waitForTimeout(500);
if(await read('state')!==0)throw Error('reset failed');
await page.setViewportSize({width:390,height:844});await page.screenshot({path:'shots/mobile.png',fullPage:true});
// Same allow-scripts-only sandbox as a file viewer. All code and ROM are embedded.
const p2=await browser.newPage();p2.on('pageerror',e=>errors.push(e.message));await p2.setContent('<iframe sandbox="allow-scripts" src="http://localhost:8000/Skyhaul.html" style="width:1000px;height:850px"></iframe>');await p2.waitForTimeout(2500);const frame=p2.frames()[1];console.log('sandbox state',await frame.evaluate(a=>sms.getBus().readbyte(a),symbols.state));await frame.locator('#start').click();await p2.waitForTimeout(1900);console.log('sandbox play state',await frame.evaluate(a=>sms.getBus().readbyte(a),symbols.state));
console.log('Browser errors:',JSON.stringify(errors));if(errors.length)throw Error('browser errors');await browser.close();})();
