#!/usr/bin/env python3
"""Generate integration scenarios against the linked ROM's real RAM layout.
Fixtures deliberately use pokes; the first flight/pickup/delivery use joypad input.
No test-only code or cheats are compiled into the cartridge.
"""
from pathlib import Path
sym={}
for l in Path('rom/skyhaul.noi').read_text().splitlines():
 p=l.split()
 if p and p[0]=='DEF':sym[p[1].lstrip('_')]=int(p[2],16)
lines=['symbols rom/skyhaul.noi']
def emit(s): lines.extend(s.strip().splitlines())
def poke(n,v,w='w1'):lines.append(f'poke {n} {v} {w}')
def field(n,off,v,w='w1'):poke(hex(sym[n]+off),v,w)
def human(i,x,y,state=1,weight=1,cool=0):
 a=i*9
 for off,val,w in [(0,x*16,'w2'),(2,y*16,'w2'),(4,0,'w2'),(6,state,'w1'),(7,weight,'w1'),(8,cool,'w1')]:field('humans',a+off,val,w)
def fixture_stage(n):
 emit('hold none')
 poke('round_no',n-1);poke('bonus_mode',1);poke('state',4);poke('state_ticks',1,'w2')
 emit('waituntil state == 1 60 w1\nwaituntil state == 2 180 w1\nrun 14')
 poke('invuln',250)
 emit(f'expect round_no == {n} w1\nexpectvdp display 1')
def park():
 for n,v in [('dx',24*16),('dy',64*16),('dcool',255),('px',128*16),('py',100*16),('pvx',0),('pvy',0)]:poke(n,v,'w2')
 poke('laser_life',0);poke('dcharge',0)

emit('''echo Boot, hardware palette and title
run 160
expect state == 0 w1
expectvdp display 1
expectcolors 6
screenshot shots/title.ppm
hold 1
run 6
hold none
waituntil state == 2 180 w1
run 14
expect lives == 3 w1
expect human_count == 8 w1
expectcolors 8
screenshot shots/play.ppm
echo Ordinary controller flight and automatic pickup
''')
poke('invuln',250)
# Start x128; a human at x128 moves right slowly. Fly right+down slightly then down.
emit('hold down\nwaituntil py >= 2512 150 s16\nhold none\nrun 4')
# The middle walker has drifted left. Sweep ground until we hook one.
emit('hold left\nwaituntil chain_count >= 1 120 w1\nhold none\nexpect haul_weight >= 1 w1\nscreenshot shots/haul.ppm')
# Directed teleport only for delivery; carrying must survive the journey state.
poke('px',128*16,'w2');poke('py',46*16,'w2');poke('pvx',0,'w2');poke('pvy',0,'w2')
emit('waituntil delivered_total >= 1 30 w1\nexpect score >= 100 w2\nexpect chain_count == 0 w1\nexpect left_count < 8 w1')
emit('echo Button 2 pause freezes physics\nhold 2\nrun 6\nhold none\nrun 6\nexpect paused == 1 w1')
poke('px',100*16,'w2')
emit('hold right\nrun 20\nexpect px == 1600 w2\nhold none\nhold 2\nrun 6\nhold none\nrun 6\nexpect paused == 0 w1')
# Controlled two-body haul at x128; projectile intersects links, not player.
emit('echo Hero laser severs a loaded chain')
park();human(0,128,118);human(1,128,127)
field('chain',0,0);field('chain',1,1);poke('chain_count',2);poke('haul_weight',2)
poke('laser_x',118*16,'w2');poke('laser_y',115*16,'w2');poke('laser_dir',1);poke('laser_life',15)
emit('waituntil cuts_total >= 1 20 w1\nexpect chain_count < 2 w1')
emit('echo Defender rescues falling captives')
poke('chain_count',0);poke('haul_weight',0);poke('laser_life',0);poke('rescues_total',0)
human(0,40,100,state=2);poke('dx',40*16,'w2');poke('dy',100*16,'w2')
emit('waituntil rescues_total >= 1 30 w1')
# each stage from normal state machine transition
fixture_stage(2);emit('expect has_rescuer == 1 w1')
# Round 2 clear enters timed bonus
poke('left_count',0)
emit('waituntil state == 4 30 w1\nwaituntil state == 1 180 w1\nexpect bonus_mode == 1 w1\nwaituntil state == 5 180 w1\nrun 20\nexpect has_rescuer == 0 w1\nexpect turret_count == 0 w1\nscreenshot shots/bonus.ppm')
poke('bonus_ticks',1,'w2')
emit('waituntil state == 4 30 w1\nwaituntil round_no == 3 200 w1\nwaituntil state == 2 180 w1\nrun 14\nexpect heavy_every == 4 w1')
# heavy pickup fixture, exact weight squared payout
emit('echo Heavy counts twice; payout is 100 times weight squared')
poke('invuln',250);poke('chain_count',0);poke('haul_weight',0);poke('score',0,'w2')

for i in range(1,16):human(i,16,172,state=3)
human(0,128,164,state=0,weight=2);poke('px',128*16,'w2');poke('py',156*16,'w2');poke('pvx',0,'w2');poke('pvy',0,'w2')
emit('waituntil haul_weight >= 2 30 w1')
poke('px',128*16,'w2');poke('py',46*16,'w2')
emit('waituntil chain_count == 0 30 w1\nexpect score == 400 w2')
emit('echo Extra ship at 10000 points')
poke('score',9900,'w2');poke('next_extend',10000,'w2');poke('lives',3)
human(0,128,64,weight=1);field('chain',0,0);poke('chain_count',1);poke('haul_weight',1)
poke('px',128*16,'w2');poke('py',46*16,'w2')
emit('waituntil lives == 4 30 w1\nexpect score == 10000 w2')
fixture_stage(4);emit('expect has_bomber == 1 w1')
# bomber mine cutting
park();human(0,128,118);field('chain',0,0);poke('chain_count',1);poke('haul_weight',1);poke('cuts_total',0)
field('mines',0,128*16,'w2');field('mines',2,118*16,'w2');field('mines',4,18,'w2')
emit('waituntil cuts_total >= 1 20 w1\nexpect chain_count == 0 w1')
fixture_stage(5);emit('expect turret_count == 3 w1\nexpect heavy_every == 5 w1')
park();human(0,128,118);human(1,128,127);field('chain',0,0);field('chain',1,1);poke('chain_count',2);poke('haul_weight',2)
poke('cuts_total',0);poke('invuln',0);poke('lives',3)
# turret 1 is centered: sizeof Turret == 6
field('turrets',6+1,1)
emit('waituntil cuts_total >= 1 20 w1\nexpect chain_count == 1 w1\nexpect lives == 3 w1\nscreenshot shots/turret.ppm')
emit('echo Shutter denies a delivery while shut')
poke('round_ticks',110,'w2');poke('px',128*16,'w2');poke('py',46*16,'w2');poke('invuln',250)
emit('run 4\nexpect hatch_open == 0 w1\nexpect chain_count == 1 w1')
poke('round_ticks',144,'w2')
emit('waituntil chain_count == 0 20 w1\nexpect hatch_open == 1 w1')
fixture_stage(6);emit('expect ace == 1 w1\nexpect turret_count == 0 w1\nexpect has_bomber == 0 w1')
# HOT fuse
poke('round_ticks',2550,'w2');emit('run 4\nexpect hot == 1 w1')
fixture_stage(7);emit('expect turret_count == 3 w1\nexpect has_bomber == 1 w1\nexpect planet == 3 w1\nscreenshot shots/void.ppm')
fixture_stage(8);emit('expect ace == 1 w1\nexpect has_rescuer == 1 w1\nexpect has_bomber == 1 w1\nexpect turret_count == 2 w1')
# Completion through real clear transition
poke('left_count',0);emit('waituntil state == 4 30 w1\nwaituntil state == 7 200 w1\nrun 20\nexpectvdp display 1\nexpectcolors 4\nscreenshot shots/complete.ppm')
# Separate last-life collision path.
fixture_stage(1);park();poke('invuln',0);poke('lives',1);poke('dx',128*16,'w2');poke('dy',100*16,'w2')
emit('waituntil state == 3 30 w1\nexpect lives == 0 w1\nwaituntil state == 6 150 w1\nrun 20\nexpectvdp display 1\nscreenshot shots/game-over.ppm\nrun 100\nhold 1\nrun 6\nhold none\nrun 20\nexpect state == 0 w1')
Path('tests/playtest.txt').write_text('\n'.join(lines)+'\n')
print('Generated',len(lines),'test commands')
