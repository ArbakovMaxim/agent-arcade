#!/usr/bin/env python3
from pathlib import Path
from base64 import b64encode
html=Path('web/template.html').read_text()
html=html.replace('/* EMBED_EMULATOR */',Path('web/emulator.js').read_text())
html=html.replace('EMBED_ROM_BASE64',b64encode(Path('rom/skyhaul.sms').read_bytes()).decode())
Path('Skyhaul.html').write_text(html)
print('Self-contained actual-ROM preview: Skyhaul.html')
