// Miracle source -> standalone browser core. esbuild is a build-only dependency.
import fs from 'node:fs';
import { generate } from '../vendor/miracle/src/z80/z80_generator.mjs';
const dir='vendor/miracle/src/z80/';
let source=fs.readFileSync(dir+'z80_ops.js','utf8');
const configs=[['opcodes_base.dat',null],['opcodes_ed.dat',null],['opcodes_cb.dat',null],['opcodes_ddfd.dat','ix'],['opcodes_ddfd.dat','iy'],['opcodes_ddfdcb.dat',null]];
for(const [file,reg] of configs)source=source.replace(`/* @z80-generate ${file}${reg?' '+reg:''} */`,generate(dir+file,reg));
fs.writeFileSync(dir+'z80_ops.generated.js',source);
let sms=fs.readFileSync('vendor/miracle/src/sms.js','utf8').replace('./z80/z80_ops','./z80/z80_ops.generated');
fs.writeFileSync('vendor/miracle/src/sms.generated.js',sms);
