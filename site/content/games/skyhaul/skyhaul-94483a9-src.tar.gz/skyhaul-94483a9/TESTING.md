# Verification record

Build/test date: **2026-09-26**. This report describes emulator testing, not physical-hardware certification.

## Cartridge

| Check | Result |
|---|---|
| Compiler | SDCC 4.5.0, Z80 target |
| Compilation / link | Pass; final build has no warnings or undefined symbols |
| ROM | 32,768 bytes, no bank switching |
| SEGA signature | `TMR SEGA` at 0x7FF0 |
| Checksum | `ihx2sms` found header and updated checksum; independently checked against a Python byte sum |
| Tile data | 256 4bpp tiles, 8,192 bytes |
| Statically allocated work RAM | 628 bytes including SMSlib; excludes stack |
| Screen | Native 256×192 Mode 4 |
| SHA-256 | `86760df5366cb36986097ce5ac1825d4c2cb7e3798fafcff291e5cd7402462e9` |

A clean extraction of the shipped source ZIP was rebuilt independently. It produced a **byte-identical ROM** and passed the complete integration script.

## Headless ROM integration test

Run `make test`. Current run: **96 successful assertions/waits, zero failures**. Full output: `test.log`.

- Boot reaches title; VDP display on; title has six distinct colours.
- Controller start reaches play; eight initial humans and three lives.
- A real D-pad descent hooks a captive without writing player or captive positions. This scenario holds invulnerability high to isolate the pickup rule.
- Directed hatch fixture delivers the captive and raises the score.
- Button 2 freezes and resumes movement.
- A staged hero laser cuts a two-body chain.
- A staged falling captive is rescued by the Defender.
- All eight round configurations load through the normal round-transition function.
- Round 2 clear enters a bonus; forced timer expiry exits it and advances to round 3.
- A single heavy produces an exact **400-point** delivery.
- A delivery that crosses 10,000 produces an extra ship.
- An armed mine severs the chain.
- A turret beam removes the bottom captive while leaving the upper captive and all three lives intact.
- A closed shutter refuses a delivery; opening it accepts the same haul.
- HOT activates when the round allowance is exhausted.
- Round 8 clear reaches the mission-complete screen.
- Final-life collision reaches dying, game over, and restart.

**Fixture distinction:** many tests deliberately write exported game RAM to create rare collisions, force clear conditions or shorten timers. This is not a claim that an unassisted full campaign was played. The ROM contains no test-only menu, invincibility switch, or shortcut code.

## Second emulator and browser

The actual cartridge also boots and runs in **Miracle** in Chromium via the self-contained preview.

- Title and gameplay visually inspected.
- Browser validation: controller start, ordinary flight and pickup, pause, reset, 390-pixel mobile layout, and an `allow-scripts`-only iframe.
- **Zero browser JavaScript errors** in that validation run.
- A separate controller-only flight, with **no RAM pokes**, picked up one captive, returned to the hatch and scored **100**, with all **three lives** remaining. See `tools/natural_flight.cjs`.
- Audio support routes the actual ROM's SN76489 register writes through the emulator. No music or audio is fetched from a network. Listening quality is not certified by the headless tests.

An initial preview experiment with jsSMS produced corrupted text in its CPU emulation while the ROM rendered correctly in the supplied harness. The shipped preview uses Miracle instead. jsSMS is not distributed in the final package.

## Performance / limits

`tools/make_stress.py` regenerates the stress fixture from current symbols; run:

```sh
python3 tools/make_stress.py
build/smstest rom/skyhaul.sms tests/stress.txt
```

Current `stress.log`:

- Initial round, ordinary load: **60 updates in 120 emulated NTSC frames** — 30 Hz.
- Artificial round-7 load starting with all **14 captives**, including heavies, plus bomber, turrets and Defender: **36 updates in 120 frames**, averaging 18 Hz over the sample. Enemies cut the chain down to four captives during this sample. This is a stress trajectory, not a worst-case upper bound.
- Stress screenshot retains an active display and 12 distinct colours.

The renderer conservatively budgets sprites by eight-pixel scanline bands. Crowded rows can flicker through intentional multiplexing. Logic/drawing can exceed the two-VBlank target with a large haul or late-stage hazards; in that case the game slows rather than dropping simulation updates. PAL has not been timing-compensated.

**Not tested:** physical SMS, Power Base Converter, PAL accuracy, Emulicious timing, a complete human eight-round run, original-vs-port trajectory equivalence. No claim of cycle accuracy or perfect gameplay parity is made.
