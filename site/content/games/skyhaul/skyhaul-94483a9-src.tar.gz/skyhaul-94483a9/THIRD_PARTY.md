# Sources, revisions and licenses

## Original game

- ABA Games, **Skyhaul**, from `abagames/agentic-gamedev-games`, `docs/skyhaul`.
- Repository revision inspected: `1f672fd4388503f907419fadc014a9a262ff3700`.
- Skyhaul introduction commit: `625e277f20889dffe076decef1134bb2af205567`.
- https://github.com/abagames/agentic-gamedev-games/tree/main/docs/skyhaul
- MIT; original notice retained in the root `LICENSE`. The game is reimplemented in C; its browser source is not needed at runtime.

## Requested development guide

- Haroldo de Oliveira Pinheiro, **Sega Master System skill for Claude**.
- Revision: `94f11e5373f80359e20f2363cab47ab6e3c80f37`.
- https://github.com/haroldo-ok/sega-master-system-skill-for-claude
- Used for the development workflow, build references and supplied `smstest` harness. Harness source and its attribution are in `vendor/smstest/`; its Z80 core is by superzazu, MIT.

## Console support library and conversion tool

- sverx, **devkitSMS**.
- Revision: `b172c7433ff690136fee47504a5fd427f62f2d16`.
- https://github.com/sverx/devkitSMS
- SMSlib source and license: `vendor/smslib/` (public domain / Unlicense).
- Startup: `vendor/crt0_sms.s`, GPL with explicit SDCC linking exception; full license in `vendor/CRT0-COPYING.txt`.
- `vendor/ihx2sms.c`: converter bundled by the skill, public-domain source.
- SMSlib and startup are built locally, not linked against mismatched precompiled objects. PSG effects are written directly by the game; PSGlib is not linked.

## Optional browser emulator

- Matt Godbolt and contributors, **Miracle**.
- Revision: `655089d243dbef1ccaf9758e3ff2b3899873b83b`.
- https://github.com/mattgodbolt/Miracle
- GPLv3. Source, original README and license in `vendor/miracle/`.
- Adaptations in this distribution: `SMS.FRAMES_PER_SECOND` 50 → 60; `SMS.SCAN_LINES_PER_FRAME` 313 → 262; corresponding VDP display-start and counter offset adjustments; PSG clock changed to the NTSC frequency. These are preview-specific changes and do not alter the cartridge.
- `tools/build_emulator.mjs` expands the original opcode definitions. `web/emulator-entry.js` exports the core for the self-contained UI. The minified core is generated with esbuild. The browser wrapper and its bundle are supplied under GPLv3. Embedded ROM bytes are a separate, emulated MIT-licensed work.
- No third-party commercial game ROMs, BIOS images, fonts, or remotely loaded assets are included.

All new cartridge pixel art and its generator are included as source. Documentation is supplied with the port.
