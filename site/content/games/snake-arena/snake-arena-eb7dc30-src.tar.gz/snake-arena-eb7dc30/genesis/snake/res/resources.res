# Snake resources
